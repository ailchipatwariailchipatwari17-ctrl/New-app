import React from 'react';
import { VaultProvider, useVault } from './context/VaultContext';
import { Calculator } from './components/Calculator';
import { VaultDashboard } from './components/VaultDashboard';
import { StealthLauncher } from './components/Launcher/StealthLauncher';
import { ScreenScannerModal } from './components/Launcher/ScreenScannerModal';
import { SetupPinModal, RecoveryModal, FakeCrashModal } from './components/SetupPinModal';

const AppContent: React.FC = () => {
  const { isUnlocked, appViewMode } = useVault();

  // Determine current active main interface
  const renderMainInterface = () => {
    if (appViewMode === 'launcher') {
      return <StealthLauncher />;
    }
    if (isUnlocked) {
      return <VaultDashboard />;
    }
    return <Calculator />;
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans selection:bg-purple-500 selection:text-white">
      {/* 
        Condition 1: Stealth Clone Launcher (0.0001% फर्क वाला असली फोन क्लोन)
        Condition 2: Fake Interface (काम करने वाला कैलकुलेटर)
        Condition 3: Secret Vault (जब सीक्रेट पिन डायल करके = दबाया जाए)
      */}
      {renderMainInterface()}

      {/* Global Modals */}
      <ScreenScannerModal />
      <SetupPinModal />
      <RecoveryModal />
      <FakeCrashModal />
    </div>
  );
};

export default function App() {
  return (
    <VaultProvider>
      <AppContent />
    </VaultProvider>
  );
}
