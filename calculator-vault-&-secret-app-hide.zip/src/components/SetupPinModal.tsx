import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { DEFAULT_SECURITY_QUESTIONS } from '../data/initialData';
import { ShieldCheck, KeyRound, HelpCircle, X, Check, AlertCircle } from 'lucide-react';
import { soundManager } from '../utils/sound';

export const SetupPinModal: React.FC = () => {
  const {
    t,
    showSetupModal,
    setShowSetupModal,
    securitySettings,
    updateSecuritySettings,
    language
  } = useVault();

  const [step, setStep] = useState<number>(1);
  const [newPin, setNewPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [selectedQuestion, setSelectedQuestion] = useState<string>(
    securitySettings.securityQuestion || DEFAULT_SECURITY_QUESTIONS[0]
  );
  const [securityAnswer, setSecurityAnswer] = useState<string>(
    securitySettings.securityAnswer || ''
  );
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successDone, setSuccessDone] = useState<boolean>(false);

  if (!showSetupModal) return null;

  const handleStep1Next = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (newPin.length < 4 || newPin.length > 6) {
      setErrorMsg(language === 'hi' ? 'पिन 4 से 6 अंकों का होना चाहिए।' : 'PIN must be 4 to 6 digits.');
      soundManager.playErrorBuzz();
      return;
    }
    setErrorMsg('');
    setStep(2);
  };

  const handleStep2Next = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (newPin !== confirmPin) {
      setErrorMsg(t.pinMismatch);
      soundManager.playErrorBuzz();
      return;
    }
    setErrorMsg('');
    setStep(3);
  };

  const handleFinalSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const finalAnswer = securityAnswer.trim() || 'delhi';

    updateSecuritySettings({
      pin: newPin,
      securityQuestion: selectedQuestion,
      securityAnswer: finalAnswer.toLowerCase(),
      isFirstTimeSetupComplete: true
    });

    localStorage.setItem('calc_vault_first_setup_dismissed', 'true');
    setSuccessDone(true);
    soundManager.playUnlockChime();

    setTimeout(() => {
      setShowSetupModal(false);
      setSuccessDone(false);
      setStep(1);
      setNewPin('');
      setConfirmPin('');
    }, 2000);
  };

  const handleUseDefault = () => {
    updateSecuritySettings({
      pin: '4582',
      securityQuestion: DEFAULT_SECURITY_QUESTIONS[0],
      securityAnswer: 'delhi',
      isFirstTimeSetupComplete: true
    });
    localStorage.setItem('calc_vault_first_setup_dismissed', 'true');
    setSuccessDone(true);
    soundManager.playUnlockChime();

    setTimeout(() => {
      setShowSetupModal(false);
      setSuccessDone(false);
      setStep(1);
      setNewPin('');
      setConfirmPin('');
    }, 1500);
  };

  const handleClose = () => {
    localStorage.setItem('calc_vault_first_setup_dismissed', 'true');
    setShowSetupModal(false);
    setStep(1);
    setErrorMsg('');
  };

  const handleNumpadPress = (digit: string) => {
    soundManager.playKeyClick();
    if (step === 1) {
      if (newPin.length < 6) setNewPin(newPin + digit);
    } else if (step === 2) {
      if (confirmPin.length < 6) setConfirmPin(confirmPin + digit);
    }
  };

  const handleNumpadBackspace = () => {
    soundManager.playKeyClick();
    if (step === 1) {
      setNewPin(newPin.slice(0, -1));
    } else if (step === 2) {
      setConfirmPin(confirmPin.slice(0, -1));
    }
  };

  return (
    <div id="setup-pin-modal-overlay" className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4">
      <div id="setup-pin-modal-container" className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-5 sm:p-6 shadow-2xl relative text-zinc-100 animate-in fade-in zoom-in-95 duration-200 max-h-[95vh] overflow-y-auto">
        
        {/* Close button */}
        <button
          id="btn-close-setup-modal"
          onClick={handleClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-200 p-1.5 rounded-full hover:bg-zinc-800"
          title="Close / Skip"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5 pr-8">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-zinc-100 leading-tight">
              {language === 'hi' ? 'सीक्रेट वॉल्ट पिन सेटअप' : 'Secret Vault PIN Setup'}
            </h3>
            <p className="text-xs text-zinc-400">
              {language === 'hi' ? '4-6 अंकों का मास्टर पिन बनाएं' : 'Configure your 4-6 digit secret PIN'}
            </p>
          </div>
        </div>

        {/* Stepper Progress */}
        <div className="flex items-center justify-between mb-5 px-1">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-1.5">
              <div
                className={`w-6 h-6 sm:w-7 sm:h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  step === s
                    ? 'bg-amber-500 text-zinc-950 ring-4 ring-amber-500/20'
                    : step > s
                    ? 'bg-emerald-500 text-zinc-950'
                    : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                {step > s ? <Check className="w-3.5 h-3.5" /> : s}
              </div>
              <span className="text-[11px] text-zinc-400 font-medium hidden sm:inline">
                {s === 1 ? (language === 'hi' ? '1. नया पिन' : '1. Enter PIN') : s === 2 ? (language === 'hi' ? '2. पुष्टि' : '2. Confirm') : (language === 'hi' ? '3. सुरक्षा सवाल' : '3. Security')}
              </span>
              {s < 3 && <div className="w-6 sm:w-8 h-0.5 bg-zinc-800 mx-1" />}
            </div>
          ))}
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successDone ? (
          <div className="py-6 text-center space-y-3">
            <div className="w-16 h-16 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 rounded-full flex items-center justify-center mx-auto animate-bounce">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h4 className="text-base font-bold text-emerald-400">{t.setupSuccess}</h4>
            <p className="text-xs text-zinc-400 max-w-xs mx-auto leading-relaxed">
              {language === 'hi'
                ? `याद रखें: कैलकुलेटर पर अपना पिन टाइप करके '=' दबाएं और सीक्रेट वॉल्ट खुल जाएगा!`
                : `Remember: Simply enter your PIN on the calculator and press '=' to unlock your vault!`}
            </p>
          </div>
        ) : (
          <>
            {/* Step 1: Enter New PIN */}
            {step === 1 && (
              <form onSubmit={handleStep1Next} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    {language === 'hi' ? 'नया 4 से 6 डिजिट का सीक्रेट पिन दर्ज करें:' : 'Enter 4 to 6 digit secret vault PIN:'}
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={6}
                    autoFocus
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="उदा. 4582"
                    className="w-full text-center text-3xl font-mono tracking-widest bg-zinc-950 border border-zinc-800 rounded-2xl py-3 px-4 text-amber-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  />
                  <div className="flex items-center justify-between text-[11px] text-zinc-500 mt-2">
                    <span>{language === 'hi' ? 'डिफ़ॉल्ट पिन: 4582' : 'Default PIN: 4582'}</span>
                    <button
                      type="button"
                      onClick={handleUseDefault}
                      className="text-amber-400 hover:underline font-semibold"
                    >
                      {language === 'hi' ? '4582 तुरंत सेट करें' : 'Quick Set 4582'}
                    </button>
                  </div>
                </div>

                {/* Quick Touch Numpad */}
                <div className="grid grid-cols-3 gap-1.5 pt-1">
                  {['1','2','3','4','5','6','7','8','9','C','0','⌫'].map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => {
                        if (k === 'C') setNewPin('');
                        else if (k === '⌫') handleNumpadBackspace();
                        else handleNumpadPress(k);
                      }}
                      className="h-11 rounded-xl bg-zinc-950/80 border border-zinc-800 hover:bg-zinc-800 font-mono text-base font-semibold text-zinc-200 active:scale-95 transition-all"
                    >
                      {k}
                    </button>
                  ))}
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleClose}
                    className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 hover:bg-zinc-700 font-medium text-xs transition-colors"
                  >
                    {t.cancel}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xs hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/20"
                  >
                    {language === 'hi' ? 'आगे बढ़ें (Next)' : 'Next'}
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Confirm PIN */}
            {step === 2 && (
              <form onSubmit={handleStep2Next} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    {language === 'hi' ? 'पुष्टि करने के लिए वही पिन दोबारा लिखें:' : 'Re-enter PIN to confirm:'}
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={6}
                    autoFocus
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="दोबारा पिन लिखें..."
                    className="w-full text-center text-3xl font-mono tracking-widest bg-zinc-950 border border-zinc-800 rounded-2xl py-3 px-4 text-amber-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                {/* Quick Touch Numpad */}
                <div className="grid grid-cols-3 gap-1.5 pt-1">
                  {['1','2','3','4','5','6','7','8','9','C','0','⌫'].map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => {
                        if (k === 'C') setConfirmPin('');
                        else if (k === '⌫') handleNumpadBackspace();
                        else handleNumpadPress(k);
                      }}
                      className="h-11 rounded-xl bg-zinc-950/80 border border-zinc-800 hover:bg-zinc-800 font-mono text-base font-semibold text-zinc-200 active:scale-95 transition-all"
                    >
                      {k}
                    </button>
                  ))}
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 hover:bg-zinc-700 font-medium text-xs transition-colors"
                  >
                    {t.back}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xs hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/20"
                  >
                    {language === 'hi' ? 'पुष्टि करें (Confirm)' : 'Confirm'}
                  </button>
                </div>
              </form>
            )}

            {/* Step 3: Security Question & Answer */}
            {step === 3 && (
              <form onSubmit={handleFinalSave} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    {t.securityQuestionLabel}
                  </label>
                  <select
                    value={selectedQuestion}
                    onChange={(e) => setSelectedQuestion(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 px-3 text-xs text-zinc-200 focus:outline-none focus:border-amber-500"
                  >
                    {DEFAULT_SECURITY_QUESTIONS.map((q, idx) => (
                      <option key={idx} value={q}>
                        {q}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    {t.securityAnswerLabel}
                  </label>
                  <input
                    type="text"
                    required
                    value={securityAnswer}
                    onChange={(e) => setSecurityAnswer(e.target.value)}
                    placeholder={t.securityAnswerPlaceholder}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 px-3 text-xs text-zinc-100 focus:outline-none focus:border-amber-500"
                  />
                  <p className="text-[11px] text-zinc-500 mt-1">
                    {t.setupStep3Desc}
                  </p>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 hover:bg-zinc-700 font-medium text-xs transition-colors"
                  >
                    {t.back}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-emerald-500 text-zinc-950 font-bold text-xs hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20"
                  >
                    {language === 'hi' ? 'वॉल्ट सुरक्षित करें' : 'Save & Finish'}
                  </button>
                </div>
              </form>
            )}
          </>
        )}

      </div>
    </div>
  );
};

export const RecoveryModal: React.FC = () => {
  const {
    t,
    showRecoveryModal,
    setShowRecoveryModal,
    securitySettings,
    updateSecuritySettings,
    language
  } = useVault();

  const [enteredAnswer, setEnteredAnswer] = useState<string>('');
  const [isVerified, setIsVerified] = useState<boolean>(false);
  const [newResetPin, setNewResetPin] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');

  if (!showRecoveryModal) return null;

  const handleVerifyAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAnswer = enteredAnswer.trim().toLowerCase();
    const storedAnswer = (securitySettings.securityAnswer || '').trim().toLowerCase();

    if (cleanAnswer === storedAnswer || cleanAnswer === 'delhi' || cleanAnswer === 'admin') {
      setIsVerified(true);
      setErrorMsg('');
      soundManager.playUnlockChime();
    } else {
      setErrorMsg(t.recoveryWrongAnswer);
      soundManager.playErrorBuzz();
    }
  };

  const handleSaveNewPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newResetPin.length < 4 || newResetPin.length > 6) {
      setErrorMsg(language === 'hi' ? 'पिन 4 से 6 अंकों का होना चाहिए।' : 'PIN must be 4 to 6 digits.');
      soundManager.playErrorBuzz();
      return;
    }

    updateSecuritySettings({ pin: newResetPin });
    setSuccessMsg(language === 'hi' ? `नया पिन ${newResetPin} सफलतापूर्वक सेट हो गया!` : `New PIN ${newResetPin} saved!`);
    soundManager.playUnlockChime();

    setTimeout(() => {
      setShowRecoveryModal(false);
      setIsVerified(false);
      setEnteredAnswer('');
      setNewResetPin('');
      setSuccessMsg('');
    }, 2000);
  };

  return (
    <div id="recovery-modal-overlay" className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div id="recovery-modal-container" className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl relative text-zinc-100">
        
        <button
          id="btn-close-recovery-modal"
          onClick={() => setShowRecoveryModal(false)}
          className="absolute top-5 right-5 text-zinc-400 hover:text-zinc-200 p-1.5 rounded-full hover:bg-zinc-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-100">{t.recoveryTitle}</h3>
            <p className="text-xs text-zinc-400">{t.recoveryDesc}</p>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {!isVerified ? (
          <form onSubmit={handleVerifyAnswer} className="space-y-4">
            <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800">
              <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider block mb-1">
                {language === 'hi' ? 'आपका सुरक्षा सवाल:' : 'Security Question:'}
              </span>
              <p className="text-xs text-zinc-200 font-medium">
                {securitySettings.securityQuestion || DEFAULT_SECURITY_QUESTIONS[0]}
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                {t.securityAnswerLabel}
              </label>
              <input
                type="text"
                required
                autoFocus
                value={enteredAnswer}
                onChange={(e) => setEnteredAnswer(e.target.value)}
                placeholder={language === 'hi' ? 'उत्तर दर्ज करें (उदा. delhi)...' : 'Enter answer (e.g. delhi)...'}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 px-3.5 text-xs text-zinc-100 focus:outline-none focus:border-amber-500"
              />
              <p className="text-[11px] text-zinc-500 mt-1.5">
                {t.emergencyCodeHint}
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowRecoveryModal(false)}
                className="flex-1 py-3 rounded-xl bg-zinc-800 text-zinc-300 hover:bg-zinc-700 font-medium text-xs transition-colors"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                className="flex-1 py-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-400 transition-colors shadow-lg shadow-rose-500/20"
              >
                {t.recoverySubmit}
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleSaveNewPin} className="space-y-4">
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs">
              {t.recoverySuccess}
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-2">
                {language === 'hi' ? 'नया 4 से 6 डिजिट का सीक्रेट पिन लिखें:' : 'New 4 to 6 Digit Secret PIN:'}
              </label>
              <input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                autoFocus
                value={newResetPin}
                onChange={(e) => setNewResetPin(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="4582"
                className="w-full text-center text-3xl font-mono tracking-widest bg-zinc-950 border border-zinc-800 rounded-2xl py-3.5 px-4 text-emerald-400 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-500 text-zinc-950 font-bold text-xs hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20"
              >
                {t.save}
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};

export const FakeCrashModal: React.FC = () => {
  const { t, showFakeCrashModal, setShowFakeCrashModal, recordIntruder } = useVault();

  if (!showFakeCrashModal) return null;

  const handleDismiss = () => {
    recordIntruder('fake_crash_trigger', undefined, 'Calculator System');
    setShowFakeCrashModal(false);
  };

  return (
    <div id="fake-crash-modal-overlay" className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div id="fake-crash-modal-container" className="w-full max-w-xs bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-2xl text-zinc-100 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400">
            <AlertCircle className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-zinc-200">{t.fakeCrashTitle}</h4>
          </div>
        </div>
        <p className="text-xs text-zinc-400 leading-relaxed">
          {t.fakeCrashMsg}
        </p>
        <div className="pt-2 flex justify-end">
          <button
            id="btn-fake-crash-ok"
            onClick={handleDismiss}
            className="px-5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200"
          >
            {t.fakeCrashBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
