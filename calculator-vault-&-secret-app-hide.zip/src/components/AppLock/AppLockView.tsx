import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { AppItem, LockType } from '../../types';
import { AppIcon } from '../Launcher/AppIcon';
import {
  Lock,
  Unlock,
  Shield,
  Fingerprint,
  Grid,
  KeyRound,
  Search,
  Check,
  X,
  Play,
  AlertCircle
} from 'lucide-react';
import { PatternLock } from './PatternLock';
import { soundManager } from '../../utils/sound';

export const AppLockView: React.FC = () => {
  const {
    t,
    apps,
    toggleAppLock,
    setAllAppsLocked,
    securitySettings,
    updateSecuritySettings,
    recordIntruder,
    language
  } = useVault();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'apps' | 'settings'>('apps');
  const [testingApp, setTestingApp] = useState<AppItem | null>(null);
  const [isAppUnlocked, setIsAppUnlocked] = useState<boolean>(false);
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [lockError, setLockError] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [showPatternConfigModal, setShowPatternConfigModal] = useState<boolean>(false);
  const [tempPattern, setTempPattern] = useState<number[]>([]);
  const [patternConfigStep, setPatternConfigStep] = useState<1 | 2>(1);

  const lockedApps = apps.filter((a) => a.isLocked);

  const filteredApps = apps.filter((a) =>
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleTestApp = (app: AppItem) => {
    setTestingApp(app);
    setEnteredPin('');
    setLockError(null);
    setFailedAttempts(0);
    if (!app.isLocked) {
      setIsAppUnlocked(true);
    } else {
      setIsAppUnlocked(false);
    }
  };

  const handlePatternComplete = (pattern: number[]) => {
    const targetPattern = securitySettings.appLockPattern || [0, 1, 2, 5, 8];
    const isMatch =
      pattern.length === targetPattern.length &&
      pattern.every((val, index) => val === targetPattern[index]);

    if (isMatch) {
      soundManager.playUnlockChime();
      setIsAppUnlocked(true);
      setLockError(null);
    } else {
      soundManager.playErrorBuzz();
      setLockError(t.wrongPattern);
      const newAttempts = failedAttempts + 1;
      setFailedAttempts(newAttempts);
      if (newAttempts >= 2) {
        recordIntruder('wrong_pattern', `Pattern[${pattern.join('-')}]`, testingApp?.name);
      }
    }
  };

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const correctPin = securitySettings.appLockPin || '1234';
    if (enteredPin === correctPin || enteredPin === securitySettings.pin) {
      soundManager.playUnlockChime();
      setIsAppUnlocked(true);
      setLockError(null);
    } else {
      soundManager.playErrorBuzz();
      setLockError(t.wrongAppPin);
      const newAttempts = failedAttempts + 1;
      setFailedAttempts(newAttempts);
      if (newAttempts >= 2) {
        recordIntruder('wrong_pin', enteredPin, testingApp?.name);
      }
      setEnteredPin('');
    }
  };

  const handleBiometricTouch = () => {
    soundManager.playUnlockChime();
    setIsAppUnlocked(true);
  };

  // Pattern configuration handlers
  const handleConfigPatternDraw = (pattern: number[]) => {
    if (pattern.length < 4) {
      setLockError(t.setNewPattern);
      return;
    }

    if (patternConfigStep === 1) {
      setTempPattern(pattern);
      setPatternConfigStep(2);
      setLockError(null);
    } else {
      const isMatch =
        pattern.length === tempPattern.length &&
        pattern.every((val, idx) => val === tempPattern[idx]);

      if (isMatch) {
        updateSecuritySettings({ appLockPattern: pattern });
        soundManager.playUnlockChime();
        setShowPatternConfigModal(false);
        setPatternConfigStep(1);
        setTempPattern([]);
      } else {
        setLockError(t.wrongPattern);
      }
    }
  };

  return (
    <div id="app-lock-view-container" className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      
      {/* Header & Lock Count */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-zinc-100 flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
              <Lock className="w-4 h-4" />
            </span>
            {t.appLockTitle}
          </h2>
          <p className="text-xs text-zinc-400 mt-1">{t.appLockSubtitle}</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" />
            <span>{lockedApps.length} {t.lockedAppsCount}</span>
          </div>

          <button
            id="btn-lock-all-apps"
            onClick={() => setAllAppsLocked(lockedApps.length < apps.length)}
            className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-zinc-300 text-xs font-semibold transition-colors"
          >
            {lockedApps.length < apps.length ? (language === 'hi' ? 'सभी लॉक करें' : 'Lock All') : (language === 'hi' ? 'सभी अनलॉक' : 'Unlock All')}
          </button>
        </div>
      </div>

      {/* Lock Method Selector Bar */}
      <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-xs font-semibold text-zinc-200 block">{t.lockTypeSelector}:</span>
          <span className="text-[11px] text-zinc-400">
            {securitySettings.appLockType === 'pattern'
              ? 'Pattern Lock (Default Z-shape: 0-1-2-5-8)'
              : securitySettings.appLockType === 'pin'
              ? `PIN Lock (Current PIN: ${securitySettings.appLockPin})`
              : 'Biometric Touch Simulation'}
          </span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {[
            { id: 'pattern', label: t.lockTypePattern, icon: Grid },
            { id: 'pin', label: t.lockTypePin, icon: KeyRound },
            { id: 'biometric', label: t.lockTypeBiometric, icon: Fingerprint }
          ].map((item) => {
            const Icon = item.icon;
            const isSel = securitySettings.appLockType === item.id;
            return (
              <button
                key={item.id}
                onClick={() => updateSecuritySettings({ appLockType: item.id as LockType })}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  isSel
                    ? 'bg-emerald-500 text-zinc-950 shadow-md shadow-emerald-500/20'
                    : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}

          {securitySettings.appLockType === 'pattern' && (
            <button
              onClick={() => {
                setPatternConfigStep(1);
                setTempPattern([]);
                setShowPatternConfigModal(true);
              }}
              className="px-2.5 py-1.5 rounded-xl text-xs font-medium bg-zinc-800 text-zinc-300 hover:text-white"
            >
              {t.changePattern}
            </button>
          )}
        </div>
      </div>

      {/* Search Apps */}
      <div className="relative">
        <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={t.searchApps}
          className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-2.5 pl-10 pr-4 text-xs text-zinc-100 focus:outline-none focus:border-emerald-500 shadow-inner"
        />
      </div>

      {/* Apps List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredApps.map((app) => {
          return (
            <div
              key={app.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                app.isLocked
                  ? 'bg-zinc-900/90 border-emerald-500/40 shadow-sm shadow-emerald-500/5'
                  : 'bg-zinc-950/60 border-zinc-800/80 hover:border-zinc-700'
              }`}
            >
              <div
                onClick={() => handleTestApp(app)}
                className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                title={t.testLockBtn}
              >
                <AppIcon
                  appName={app.name}
                  packageName={app.packageName}
                  iconName={app.iconName}
                  size="compact"
                  shape="squircle"
                  showBadge={false}
                  customIconUrl={app.customIconUrl}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-zinc-100 truncate">{app.name}</span>
                    {app.isLocked && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-semibold uppercase">
                        Locked
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-zinc-400 block truncate">{app.category}</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                {/* Launch Test Button */}
                <button
                  onClick={() => handleTestApp(app)}
                  className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 text-xs"
                  title={t.testLockBtn}
                >
                  <Play className="w-3.5 h-3.5" />
                </button>

                {/* Lock Toggle Switch */}
                <button
                  onClick={() => toggleAppLock(app.id)}
                  className={`p-2 rounded-xl transition-colors ${
                    app.isLocked
                      ? 'bg-emerald-500 text-zinc-950'
                      : 'bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-zinc-300'
                  }`}
                  title={app.isLocked ? t.unlock : t.lock}
                >
                  {app.isLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Simulated App Launch / App Lock Screen Modal */}
      {testingApp && (
        <div id="test-app-lock-modal" className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-[36px] overflow-hidden shadow-2xl flex flex-col min-h-[580px] max-h-[92vh] relative text-zinc-100 ring-1 ring-white/10">
            
            {/* Top Phone Bar */}
            <div className="flex items-center justify-between p-4 bg-zinc-900/90 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-zinc-300">{testingApp.name}</span>
              </div>
              <button
                onClick={() => setTestingApp(null)}
                className="p-1 text-zinc-400 hover:text-zinc-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* If Unlocked: Show Simulated App Content */}
            {isAppUnlocked ? (
              <div className="flex-1 flex flex-col p-4 bg-zinc-900/60 overflow-y-auto space-y-4">
                <div className="flex items-center gap-3 p-3 rounded-2xl bg-zinc-900 border border-zinc-800">
                  <AppIcon
                    appName={testingApp.name}
                    packageName={testingApp.packageName}
                    iconName={testingApp.iconName}
                    size="compact"
                    shape="squircle"
                    showBadge={false}
                    customIconUrl={testingApp.customIconUrl}
                  />
                  <div>
                    <h4 className="text-sm font-bold text-zinc-100">{testingApp.name}</h4>
                    <p className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      {t.appUnlocked}
                    </p>
                  </div>
                </div>

                {/* Simulated Content based on App Type */}
                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
                  <div className="text-xs font-semibold text-zinc-300 border-b border-zinc-800 pb-2">
                    {language === 'hi' ? 'लाइव प्रोटेक्टेड ऐप एनवायरनमेंट' : 'Protected App Environment'}
                  </div>

                  {testingApp.mockScreenType === 'chat' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
                        <div className="font-bold text-emerald-400">Priya Sharma</div>
                        <p className="text-zinc-400 mt-0.5">"Did you send the document?"</p>
                      </div>
                      <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
                        <div className="font-bold text-sky-400">Office Group</div>
                        <p className="text-zinc-400 mt-0.5">"Meeting starts at 4 PM today."</p>
                      </div>
                    </div>
                  )}

                  {testingApp.mockScreenType === 'bank' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-3 rounded-xl bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-700/50">
                        <span className="text-[10px] text-zinc-400">Total Balance</span>
                        <div className="text-xl font-bold text-white font-mono mt-0.5">₹ 1,48,250.00</div>
                      </div>
                    </div>
                  )}

                  {testingApp.mockScreenType === 'feed' && (
                    <div className="space-y-2 text-xs">
                      <div className="aspect-video rounded-xl bg-zinc-900 overflow-hidden relative">
                        <img
                          src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80"
                          alt="Feed"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  )}

                  {testingApp.mockScreenType === 'gallery' && (
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="aspect-square rounded-xl bg-zinc-900 overflow-hidden">
                        <img
                          src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80"
                          alt="Gallery"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="aspect-square rounded-xl bg-zinc-900 overflow-hidden">
                        <img
                          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80"
                          alt="Gallery"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  )}

                  {['browser', 'settings', 'default'].includes(testingApp.mockScreenType) && (
                    <div className="p-3 rounded-xl bg-zinc-900 text-xs text-zinc-400">
                      {testingApp.mockDescription}
                    </div>
                  )}
                </div>

                <button
                  onClick={() => setIsAppUnlocked(false)}
                  className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-300 flex items-center justify-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>{language === 'hi' ? 'दोबारा लॉक करें' : 'Lock Again'}</span>
                </button>
              </div>
            ) : (
              /* If Locked: Realistic Pattern / PIN / Biometric Screen */
              <div className="flex-1 flex flex-col items-center justify-between p-6 bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950">
                
                {/* App Header */}
                <div className="text-center space-y-2 pt-2">
                  <div className="mx-auto flex items-center justify-center">
                    <AppIcon
                      appName={testingApp.name}
                      packageName={testingApp.packageName}
                      iconName={testingApp.iconName}
                      size="large"
                      shape="squircle"
                      showBadge={false}
                      customIconUrl={testingApp.customIconUrl}
                    />
                  </div>
                  <h4 className="text-base font-bold text-zinc-100">{testingApp.name}</h4>
                  <p className="text-xs text-emerald-400 font-medium">
                    {securitySettings.appLockType === 'pattern'
                      ? t.drawPatternToUnlock
                      : securitySettings.appLockType === 'pin'
                      ? t.enterPinToUnlock
                      : t.touchFingerprint}
                  </p>
                </div>

                {lockError && (
                  <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-1.5 animate-bounce">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{lockError}</span>
                  </div>
                )}

                {/* Mode 1: Pattern Lock */}
                {securitySettings.appLockType === 'pattern' && (
                  <div className="my-auto">
                    <PatternLock onPatternComplete={handlePatternComplete} error={!!lockError} />
                  </div>
                )}

                {/* Mode 2: PIN Lock */}
                {securitySettings.appLockType === 'pin' && (
                  <div className="w-full space-y-4 my-auto">
                    <div className="flex justify-center gap-3">
                      {[0, 1, 2, 3].map((i) => (
                        <div
                          key={i}
                          className={`w-4 h-4 rounded-full border border-zinc-700 transition-all ${
                            enteredPin.length > i
                              ? 'bg-emerald-400 ring-2 ring-emerald-400/30'
                              : 'bg-zinc-800'
                          }`}
                        />
                      ))}
                    </div>

                    <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto pt-4">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => (
                        <button
                          key={k}
                          onClick={() => {
                            if (k === 'C') {
                              setEnteredPin('');
                            } else if (k === '⌫') {
                              setEnteredPin((p) => p.slice(0, -1));
                            } else {
                              if (enteredPin.length < 4) {
                                const nextPin = enteredPin + k;
                                setEnteredPin(nextPin);
                                if (nextPin.length === 4) {
                                  setTimeout(() => {
                                    const correctPin = securitySettings.appLockPin || '1234';
                                    if (nextPin === correctPin || nextPin === securitySettings.pin) {
                                      soundManager.playUnlockChime();
                                      setIsAppUnlocked(true);
                                      setLockError(null);
                                    } else {
                                      soundManager.playErrorBuzz();
                                      setLockError(t.wrongAppPin);
                                      setEnteredPin('');
                                    }
                                  }, 100);
                                }
                              }
                            }
                          }}
                          className="h-12 rounded-2xl bg-zinc-900 hover:bg-zinc-800 active:scale-95 text-zinc-100 font-bold text-lg flex items-center justify-center border border-zinc-800/80"
                        >
                          {k}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Mode 3: Biometric Touch */}
                {securitySettings.appLockType === 'biometric' && (
                  <div className="my-auto text-center space-y-4">
                    <button
                      onClick={handleBiometricTouch}
                      className="w-24 h-24 rounded-full bg-emerald-500/10 border-2 border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto hover:bg-emerald-500/20 active:scale-95 transition-all shadow-lg shadow-emerald-500/10"
                    >
                      <Fingerprint className="w-12 h-12 animate-pulse" />
                    </button>
                    <p className="text-[11px] text-zinc-400">{t.touchFingerprint}</p>
                  </div>
                )}

                {/* Footer Hint */}
                <div className="text-[10px] text-zinc-500 text-center">
                  Protected by Calculator AppLock Engine
                </div>

              </div>
            )}

          </div>
        </div>
      )}

      {/* Pattern Config Modal */}
      {showPatternConfigModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl max-w-sm w-full space-y-4 text-center">
            <h4 className="text-sm font-bold text-zinc-100">
              {patternConfigStep === 1 ? t.setNewPattern : t.confirmPattern}
            </h4>
            
            {lockError && (
              <p className="text-xs text-rose-400">{lockError}</p>
            )}

            <PatternLock onPatternComplete={handleConfigPatternDraw} />

            <button
              onClick={() => {
                setShowPatternConfigModal(false);
                setLockError(null);
              }}
              className="w-full py-2.5 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
