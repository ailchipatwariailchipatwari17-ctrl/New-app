import React, { useRef, useState, useEffect } from 'react';

interface PatternLockProps {
  onPatternComplete: (pattern: number[]) => void;
  error?: boolean;
  disabled?: boolean;
}

export const PatternLock: React.FC<PatternLockProps> = ({
  onPatternComplete,
  error = false,
  disabled = false
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedPoints, setSelectedPoints] = useState<number[]>([]);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [currentTouchPos, setCurrentTouchPos] = useState<{ x: number; y: number } | null>(null);

  // 3x3 Grid point positions (0 to 8)
  const dots = [0, 1, 2, 3, 4, 5, 6, 7, 8];

  const getPointCoordinates = (index: number, width: number, height: number) => {
    const row = Math.floor(index / 3);
    const col = index % 3;
    const paddingX = width * 0.18;
    const paddingY = height * 0.18;
    const stepX = (width - paddingX * 2) / 2;
    const stepY = (height - paddingY * 2) / 2;

    return {
      x: paddingX + col * stepX,
      y: paddingY + row * stepY
    };
  };

  const getNearestDot = (x: number, y: number, width: number, height: number): number | null => {
    const threshold = width * 0.12;
    for (let i = 0; i < 9; i++) {
      const dotCoord = getPointCoordinates(i, width, height);
      const dist = Math.hypot(dotCoord.x - x, dotCoord.y - y);
      if (dist < threshold) {
        return i;
      }
    }
    return null;
  };

  const handleStart = (clientX: number, clientY: number) => {
    if (disabled || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    const dot = getNearestDot(x, y, rect.width, rect.height);
    if (dot !== null) {
      setSelectedPoints([dot]);
      setIsDrawing(true);
      setCurrentTouchPos({ x, y });
    }
  };

  const handleMove = (clientX: number, clientY: number) => {
    if (!isDrawing || disabled || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    setCurrentTouchPos({ x, y });

    const dot = getNearestDot(x, y, rect.width, rect.height);
    if (dot !== null && !selectedPoints.includes(dot)) {
      setSelectedPoints((prev) => [...prev, dot]);
    }
  };

  const handleEnd = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    setCurrentTouchPos(null);
    if (selectedPoints.length > 0) {
      onPatternComplete(selectedPoints);
    }
  };

  // Touch handlers
  const onTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    if (e.touches.length > 0) {
      handleStart(e.touches[0].clientX, e.touches[0].clientY);
    }
  };

  const onTouchMove = (e: React.TouchEvent) => {
    e.preventDefault();
    if (e.touches.length > 0) {
      handleMove(e.touches[0].clientX, e.touches[0].clientY);
    }
  };

  // Mouse handlers
  const onMouseDown = (e: React.MouseEvent) => {
    handleStart(e.clientX, e.clientY);
  };

  const onMouseMove = (e: React.MouseEvent) => {
    handleMove(e.clientX, e.clientY);
  };

  useEffect(() => {
    const handleMouseUpGlobal = () => {
      if (isDrawing) {
        handleEnd();
      }
    };
    window.addEventListener('mouseup', handleMouseUpGlobal);
    return () => window.removeEventListener('mouseup', handleMouseUpGlobal);
  }, [isDrawing, selectedPoints]);

  return (
    <div
      ref={containerRef}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={handleEnd}
      className="relative w-64 h-64 sm:w-72 sm:h-72 mx-auto select-none touch-none cursor-pointer"
    >
      {/* SVG Connecting Lines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        {selectedPoints.map((pointIndex, i) => {
          if (i === 0 || !containerRef.current) return null;
          const prevIndex = selectedPoints[i - 1];
          const rect = containerRef.current.getBoundingClientRect();
          const p1 = getPointCoordinates(prevIndex, rect.width, rect.height);
          const p2 = getPointCoordinates(pointIndex, rect.width, rect.height);

          return (
            <line
              key={i}
              x1={p1.x}
              y1={p1.y}
              x2={p2.x}
              y2={p2.y}
              stroke={error ? '#f43f5e' : '#10b981'}
              strokeWidth="4"
              strokeLinecap="round"
              className="transition-colors"
            />
          );
        })}

        {/* Line to current touch/cursor */}
        {isDrawing && currentTouchPos && selectedPoints.length > 0 && containerRef.current && (
          <line
            x1={getPointCoordinates(selectedPoints[selectedPoints.length - 1], containerRef.current.clientWidth, containerRef.current.clientHeight).x}
            y1={getPointCoordinates(selectedPoints[selectedPoints.length - 1], containerRef.current.clientWidth, containerRef.current.clientHeight).y}
            x2={currentTouchPos.x}
            y2={currentTouchPos.y}
            stroke={error ? '#f43f5e' : '#34d399'}
            strokeWidth="3"
            strokeDasharray="4 4"
            strokeLinecap="round"
          />
        )}
      </svg>

      {/* 3x3 Dots */}
      <div className="w-full h-full grid grid-cols-3 grid-rows-3 p-6">
        {dots.map((dot) => {
          const isSelected = selectedPoints.includes(dot);
          return (
            <div key={dot} className="flex items-center justify-center">
              <div
                className={`relative flex items-center justify-center rounded-full transition-all ${
                  isSelected
                    ? error
                      ? 'w-10 h-10 bg-rose-500/20 ring-2 ring-rose-500 scale-110'
                      : 'w-10 h-10 bg-emerald-500/20 ring-2 ring-emerald-500 scale-110'
                    : 'w-6 h-6 bg-zinc-800 border border-zinc-700 hover:bg-zinc-700'
                }`}
              >
                <div
                  className={`rounded-full ${
                    isSelected
                      ? error
                        ? 'w-3.5 h-3.5 bg-rose-500'
                        : 'w-3.5 h-3.5 bg-emerald-400'
                      : 'w-2 h-2 bg-zinc-400'
                  }`}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
