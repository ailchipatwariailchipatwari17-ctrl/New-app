import React, { useRef, useState, useEffect } from 'react';
import { Camera, X, RefreshCw, Check, AlertCircle } from 'lucide-react';
import { soundManager } from '../../utils/sound';
import { MediaItem } from '../../types';

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (item: MediaItem) => void;
  albumId: string;
}

export const CameraModal: React.FC<CameraModalProps> = ({
  isOpen,
  onClose,
  onCapture,
  albumId
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedUrl, setCapturedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');

  useEffect(() => {
    if (isOpen && !capturedUrl) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode, capturedUrl]);

  const startCamera = async () => {
    setError(null);
    try {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      setStream(newStream);
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
    } catch (err: unknown) {
      console.warn('Camera access denied or unavailable:', err);
      setError('Camera access not granted or unavailable. You can also import photos directly.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((t) => t.stop());
      setStream(null);
    }
  };

  const takeSnapshot = () => {
    soundManager.playShutterSound();
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        setCapturedUrl(dataUrl);
        stopCamera();
      }
    }
  };

  const handleSaveCapture = () => {
    if (!capturedUrl) return;
    const newItem: MediaItem = {
      id: `secret-cam-${Date.now()}`,
      type: 'image',
      name: `Secret_Capture_${new Date().toISOString().slice(0, 10)}.jpg`,
      url: capturedUrl,
      size: Math.round(capturedUrl.length * 0.75),
      dateAdded: Date.now(),
      albumId: albumId || 'album-personal',
      favorite: true
    };
    onCapture(newItem);
    setCapturedUrl(null);
    onClose();
  };

  const handleRetake = () => {
    setCapturedUrl(null);
  };

  const toggleFacing = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  if (!isOpen) return null;

  return (
    <div id="camera-modal-overlay" className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-3 sm:p-4">
      <div id="camera-modal-container" className="w-full max-w-lg bg-zinc-950 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col relative text-zinc-100">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-zinc-900/80 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-semibold">Secret Spy Camera</span>
          </div>
          <button
            id="btn-close-camera"
            onClick={() => {
              stopCamera();
              setCapturedUrl(null);
              onClose();
            }}
            className="p-1 text-zinc-400 hover:text-zinc-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder area */}
        <div className="relative aspect-[4/3] bg-black flex items-center justify-center overflow-hidden">
          {error ? (
            <div className="p-6 text-center text-xs text-rose-400 space-y-2">
              <AlertCircle className="w-8 h-8 mx-auto text-rose-500" />
              <p>{error}</p>
            </div>
          ) : capturedUrl ? (
            <img
              src={capturedUrl}
              alt="Secret Capture"
              className="w-full h-full object-contain"
            />
          ) : (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          )}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Action Controls Footer */}
        <div className="p-4 bg-zinc-900 flex items-center justify-around">
          {capturedUrl ? (
            <>
              <button
                id="btn-retake-photo"
                onClick={handleRetake}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Retake
              </button>
              <button
                id="btn-save-secret-photo"
                onClick={handleSaveCapture}
                className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-500/20"
              >
                <Check className="w-4 h-4" />
                Save into Secret Vault
              </button>
            </>
          ) : (
            <>
              <button
                id="btn-switch-camera-facing"
                onClick={toggleFacing}
                className="p-3 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                title="Switch Camera"
              >
                <RefreshCw className="w-5 h-5" />
              </button>

              <button
                id="btn-snap-shutter"
                onClick={takeSnapshot}
                disabled={!!error}
                className="w-16 h-16 rounded-full bg-white ring-4 ring-white/30 active:scale-90 transition-all flex items-center justify-center disabled:opacity-40"
              >
                <div className="w-12 h-12 rounded-full border-2 border-zinc-900" />
              </button>

              <div className="w-10" />
            </>
          )}
        </div>

      </div>
    </div>
  );
};
