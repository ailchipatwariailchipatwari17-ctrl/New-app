import React, { useState } from 'react';
import { MediaItem } from '../../types';
import {
  X,
  Trash2,
  Download,
  Heart,
  RotateCw,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  Maximize2
} from 'lucide-react';
import { useVault } from '../../context/VaultContext';

interface MediaViewerProps {
  items: MediaItem[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (index: number) => void;
}

export const MediaViewer: React.FC<MediaViewerProps> = ({
  items,
  currentIndex,
  isOpen,
  onClose,
  onNavigate
}) => {
  const { t, removeMediaItem, toggleMediaFavorite, language } = useVault();
  const [rotation, setRotation] = useState<number>(0);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [showConfirmDelete, setShowConfirmDelete] = useState<boolean>(false);

  if (!isOpen || items.length === 0 || currentIndex < 0 || currentIndex >= items.length) {
    return null;
  }

  const currentItem = items[currentIndex];

  const handleNext = () => {
    setRotation(0);
    setZoomLevel(1);
    onNavigate((currentIndex + 1) % items.length);
  };

  const handlePrev = () => {
    setRotation(0);
    setZoomLevel(1);
    onNavigate((currentIndex - 1 + items.length) % items.length);
  };

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const toggleZoom = () => {
    setZoomLevel((prev) => (prev === 1 ? 1.75 : 1));
  };

  const handleUnhideAndDownload = () => {
    const link = document.createElement('a');
    link.href = currentItem.url;
    link.download = currentItem.name || `vault_unhidden_${Date.now()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = async () => {
    await removeMediaItem(currentItem.id);
    setShowConfirmDelete(false);
    if (items.length <= 1) {
      onClose();
    } else {
      handleNext();
    }
  };

  return (
    <div id="media-viewer-overlay" className="fixed inset-0 bg-black/95 z-50 flex flex-col justify-between select-none">
      
      {/* Top Action Bar */}
      <div className="p-4 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent text-zinc-100 z-10">
        <div className="flex items-center gap-3">
          <button
            id="btn-close-viewer"
            onClick={onClose}
            className="p-2 rounded-full bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300"
          >
            <X className="w-5 h-5" />
          </button>
          <div>
            <div className="text-xs font-semibold text-zinc-200 truncate max-w-[180px] sm:max-w-md">
              {currentItem.name}
            </div>
            <div className="text-[10px] text-zinc-400">
              {currentIndex + 1} / {items.length} • {new Date(currentItem.dateAdded).toLocaleDateString()}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Favorite */}
          <button
            id="btn-toggle-fav-viewer"
            onClick={() => toggleMediaFavorite(currentItem.id)}
            className={`p-2 rounded-full ${currentItem.favorite ? 'bg-rose-500/20 text-rose-400' : 'bg-zinc-900/80 text-zinc-300 hover:bg-zinc-800'}`}
          >
            <Heart className={`w-4 h-4 ${currentItem.favorite ? 'fill-rose-400' : ''}`} />
          </button>

          {/* Rotate Image */}
          {currentItem.type === 'image' && (
            <button
              id="btn-rotate-viewer"
              onClick={handleRotate}
              className="p-2 rounded-full bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300"
              title="Rotate"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          )}

          {/* Zoom */}
          {currentItem.type === 'image' && (
            <button
              id="btn-zoom-viewer"
              onClick={toggleZoom}
              className="p-2 rounded-full bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300"
              title="Zoom"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          )}

          {/* Unhide / Download */}
          <button
            id="btn-unhide-download-viewer"
            onClick={handleUnhideAndDownload}
            className="p-2 rounded-full bg-zinc-900/80 hover:bg-emerald-500 hover:text-zinc-950 text-zinc-300 transition-colors"
            title={t.unhide}
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Delete */}
          <button
            id="btn-delete-viewer"
            onClick={() => setShowConfirmDelete(true)}
            className="p-2 rounded-full bg-zinc-900/80 hover:bg-rose-500/30 text-rose-400"
            title={t.delete}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main View Area */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden p-2">
        
        {/* Prev Arrow */}
        {items.length > 1 && (
          <button
            id="btn-prev-media"
            onClick={handlePrev}
            className="absolute left-4 p-3 rounded-full bg-zinc-900/60 hover:bg-zinc-800 text-zinc-300 z-10 backdrop-blur"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Media Content */}
        {currentItem.type === 'image' ? (
          <img
            src={currentItem.url}
            alt={currentItem.name}
            style={{
              transform: `rotate(${rotation}deg) scale(${zoomLevel})`,
              transition: 'transform 0.2s ease-out'
            }}
            className="max-h-[82vh] max-w-[94vw] object-contain cursor-zoom-in"
            onClick={toggleZoom}
          />
        ) : (
          <div className="max-w-3xl w-full flex flex-col items-center">
            <video
              src={currentItem.url}
              controls
              autoPlay
              playsInline
              className="max-h-[75vh] w-full rounded-2xl bg-black shadow-2xl"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
          </div>
        )}

        {/* Next Arrow */}
        {items.length > 1 && (
          <button
            id="btn-next-media"
            onClick={handleNext}
            className="absolute right-4 p-3 rounded-full bg-zinc-900/60 hover:bg-zinc-800 text-zinc-300 z-10 backdrop-blur"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showConfirmDelete && (
        <div className="absolute inset-0 bg-black/80 z-20 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl max-w-sm w-full text-center space-y-4">
            <Trash2 className="w-10 h-10 text-rose-400 mx-auto" />
            <h4 className="text-sm font-bold text-zinc-100">{t.deleteMediaConfirm}</h4>
            <div className="flex gap-2">
              <button
                onClick={() => setShowConfirmDelete(false)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-500 text-xs font-semibold text-white"
              >
                {t.delete}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Info Bar */}
      <div className="p-3 text-center bg-gradient-to-t from-black/80 to-transparent text-[11px] text-zinc-400">
        {language === 'hi' ? 'यह फाइल पूरी तरह से सुरक्षित और आपके मुख्य फोन से छिपी हुई है' : 'This item is encrypted and completely hidden from the phone gallery'}
      </div>

    </div>
  );
};
