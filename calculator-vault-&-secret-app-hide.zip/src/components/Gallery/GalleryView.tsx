import React, { useRef, useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { MediaItem } from '../../types';
import {
  Image,
  Video,
  Plus,
  Camera,
  Upload,
  FolderPlus,
  Heart,
  Play,
  Check,
  Folder,
  Layers,
  Sparkles
} from 'lucide-react';
import { CameraModal } from './CameraModal';
import { MediaViewer } from './MediaViewer';

export const GalleryView: React.FC = () => {
  const {
    t,
    media,
    albums,
    addMediaItem,
    addAlbum,
    language
  } = useVault();

  const [selectedAlbum, setSelectedAlbum] = useState<string>('all');
  const [mediaTypeFilter, setMediaTypeFilter] = useState<'all' | 'image' | 'video' | 'favorite'>('all');
  const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);
  const [viewerIndex, setViewerIndex] = useState<number>(-1);
  const [showNewAlbumModal, setShowNewAlbumModal] = useState<boolean>(false);
  const [newAlbumName, setNewAlbumName] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter media
  const filteredMedia = media.filter((item) => {
    // Album filter
    if (selectedAlbum !== 'all' && item.albumId !== selectedAlbum) {
      return false;
    }
    // Type filter
    if (mediaTypeFilter === 'image' && item.type !== 'image') return false;
    if (mediaTypeFilter === 'video' && item.type !== 'video') return false;
    if (mediaTypeFilter === 'favorite' && !item.favorite) return false;
    return true;
  });

  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const isVideo = file.type.startsWith('video/');
      const reader = new FileReader();

      reader.onload = async (e) => {
        const url = e.target?.result as string;
        if (url) {
          const newItem: MediaItem = {
            id: `media-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            type: isVideo ? 'video' : 'image',
            name: file.name,
            url,
            size: file.size,
            dateAdded: Date.now(),
            albumId: selectedAlbum !== 'all' ? selectedAlbum : 'album-personal',
            favorite: false
          };
          await addMediaItem(newItem);
        }
      };

      reader.readAsDataURL(file);
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      handleFileUpload(e.dataTransfer.files);
    }
  };

  const handleCreateAlbum = (e: React.FormEvent) => {
    e.preventDefault();
    if (newAlbumName.trim()) {
      addAlbum(newAlbumName.trim());
      setNewAlbumName('');
      setShowNewAlbumModal(false);
    }
  };

  return (
    <div id="gallery-view-container" className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-zinc-100 flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 flex items-center justify-center">
              <Image className="w-4 h-4" />
            </span>
            {t.galleryTitle}
          </h2>
          <p className="text-xs text-zinc-400 mt-1">{t.gallerySubtitle}</p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Secret Camera */}
          <button
            id="btn-open-secret-camera"
            onClick={() => setIsCameraOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Camera className="w-4 h-4 text-emerald-400" />
            <span>{t.takeSecretPhoto}</span>
          </button>

          {/* Import Files */}
          <button
            id="btn-import-media-files"
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-lg shadow-purple-600/25"
          >
            <Upload className="w-4 h-4" />
            <span>{t.importFiles}</span>
          </button>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,video/*"
            onChange={(e) => handleFileUpload(e.target.files)}
            className="hidden"
          />
        </div>
      </div>

      {/* Album Selector and Filters */}
      <div className="flex flex-col gap-3">
        {/* Albums Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedAlbum('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all flex items-center gap-1.5 ${
              selectedAlbum === 'all'
                ? 'bg-zinc-100 text-zinc-950 shadow-md'
                : 'bg-zinc-900/80 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{t.allMedia}</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-zinc-700/40">{media.length}</span>
          </button>

          {albums.map((album) => {
            const count = media.filter((m) => m.albumId === album.id).length;
            const isSel = selectedAlbum === album.id;
            return (
              <button
                key={album.id}
                onClick={() => setSelectedAlbum(album.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all flex items-center gap-1.5 ${
                  isSel
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                    : 'bg-zinc-900/80 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Folder className="w-3.5 h-3.5" />
                <span>{album.name}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-zinc-800/80">{count}</span>
              </button>
            );
          })}

          <button
            onClick={() => setShowNewAlbumModal(true)}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold shrink-0 bg-zinc-900 border border-dashed border-zinc-700 text-zinc-400 hover:text-zinc-200 hover:border-zinc-500 flex items-center gap-1"
          >
            <FolderPlus className="w-3.5 h-3.5 text-purple-400" />
            <span>{t.newAlbum}</span>
          </button>
        </div>

        {/* Media Type Sub-filter */}
        <div className="flex items-center gap-2">
          {[
            { id: 'all', label: t.allMedia },
            { id: 'image', label: t.photosOnly, icon: Image },
            { id: 'video', label: t.videosOnly, icon: Video },
            { id: 'favorite', label: 'Favorites', icon: Heart }
          ].map((filter) => (
            <button
              key={filter.id}
              onClick={() => setMediaTypeFilter(filter.id as any)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                mediaTypeFilter === filter.id
                  ? 'bg-zinc-800 text-zinc-100 font-semibold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Drag & Drop Import Dropzone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-3xl p-6 text-center cursor-pointer transition-all ${
          isDragging
            ? 'border-purple-500 bg-purple-500/10 scale-[0.99]'
            : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/40'
        }`}
      >
        <div className="flex flex-col items-center justify-center gap-2">
          <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Upload className="w-5 h-5" />
          </div>
          <p className="text-xs font-medium text-zinc-300">{t.dropZoneText}</p>
          <span className="text-[11px] text-zinc-500">JPG, PNG, GIF, MP4, WebM (Stored locally in IndexedDB)</span>
        </div>
      </div>

      {/* Media Grid */}
      {filteredMedia.length === 0 ? (
        <div className="p-12 text-center border border-zinc-900 rounded-3xl bg-zinc-950/60">
          <Image className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
          <h4 className="text-sm font-semibold text-zinc-400">{t.noMedia}</h4>
          <p className="text-xs text-zinc-600 mt-1">
            {language === 'hi' ? 'ऊपर दिए गए "फोटो/वीडियो जोड़ें" बटन से फाइलें इंपोर्ट करें' : 'Click "Import Photos / Videos" to hide your first secret file'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {filteredMedia.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => setViewerIndex(idx)}
              className="group relative aspect-square rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800/80 cursor-pointer shadow-md hover:shadow-xl hover:border-zinc-700 transition-all"
            >
              {item.type === 'image' ? (
                <img
                  src={item.url}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
              ) : (
                <div className="w-full h-full relative bg-zinc-950 flex items-center justify-center">
                  {item.thumbnailUrl ? (
                    <img
                      src={item.thumbnailUrl}
                      alt={item.name}
                      className="w-full h-full object-cover opacity-80"
                    />
                  ) : (
                    <video
                      src={item.url}
                      className="w-full h-full object-cover opacity-70"
                    />
                  )}
                  <div className="absolute w-10 h-10 rounded-full bg-black/60 backdrop-blur border border-white/20 flex items-center justify-center text-white">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>
              )}

              {/* Badges / Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 opacity-0 group-hover:opacity-100 transition-opacity p-2.5 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/70 text-zinc-300 font-mono">
                    {(item.size / (1024 * 1024)).toFixed(1)} MB
                  </span>
                  {item.favorite && (
                    <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                  )}
                </div>

                <div>
                  <p className="text-[11px] font-semibold text-white truncate">{item.name}</p>
                  <p className="text-[10px] text-zinc-400">
                    {new Date(item.dateAdded).toLocaleDateString()}
                  </p>
                </div>
              </div>

              {/* Type pill */}
              <div className="absolute top-2 left-2 group-hover:opacity-0 transition-opacity">
                <span className="px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur text-[10px] text-zinc-300 font-medium flex items-center gap-1">
                  {item.type === 'video' ? <Video className="w-3 h-3 text-amber-400" /> : <Image className="w-3 h-3 text-purple-400" />}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Album Modal */}
      {showNewAlbumModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl max-w-sm w-full space-y-4">
            <h4 className="text-sm font-bold text-zinc-100">{t.newAlbum}</h4>
            <form onSubmit={handleCreateAlbum} className="space-y-4">
              <input
                type="text"
                required
                autoFocus
                value={newAlbumName}
                onChange={(e) => setNewAlbumName(e.target.value)}
                placeholder={language === 'hi' ? 'एल्बम का नाम लिखें...' : 'Album name...'}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 px-3 text-xs text-zinc-100 focus:outline-none focus:border-purple-500"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewAlbumModal(false)}
                  className="flex-1 py-2 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-purple-600 text-xs font-bold text-white hover:bg-purple-500"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Camera Capture Modal */}
      <CameraModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(item) => addMediaItem(item)}
        albumId={selectedAlbum !== 'all' ? selectedAlbum : 'album-personal'}
      />

      {/* Fullscreen Media Viewer */}
      <MediaViewer
        items={filteredMedia}
        currentIndex={viewerIndex}
        isOpen={viewerIndex >= 0}
        onClose={() => setViewerIndex(-1)}
        onNavigate={(idx) => setViewerIndex(idx)}
      />

    </div>
  );
};
