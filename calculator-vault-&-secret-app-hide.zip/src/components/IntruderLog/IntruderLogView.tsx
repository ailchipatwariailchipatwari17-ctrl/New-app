import React from 'react';
import { useVault } from '../../context/VaultContext';
import { ShieldAlert, Trash2, Clock, AlertTriangle, UserX, ShieldCheck } from 'lucide-react';

export const IntruderLogView: React.FC = () => {
  const { t, intruderRecords, clearIntruderLogs, language } = useVault();

  return (
    <div id="intruder-log-container" className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-zinc-100 flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </span>
            {t.intruderTitle}
          </h2>
          <p className="text-xs text-zinc-400 mt-1">{t.intruderSubtitle}</p>
        </div>

        {intruderRecords.length > 0 && (
          <button
            id="btn-clear-intruder-logs"
            onClick={clearIntruderLogs}
            className="px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-rose-500/40 text-rose-400 text-xs font-semibold flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Trash2 className="w-4 h-4" />
            <span>{t.clearIntruderLogs}</span>
          </button>
        )}
      </div>

      {/* Intruder List */}
      {intruderRecords.length === 0 ? (
        <div className="p-12 text-center border border-zinc-900 rounded-3xl bg-zinc-950/60 space-y-3">
          <div className="w-14 h-14 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h4 className="text-sm font-semibold text-zinc-200">{t.noIntruders}</h4>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto">
            {language === 'hi'
              ? 'जब कोई कैलकुलेटर या ऐप लॉक में 2 बार गलत पासवर्ड या पैटर्न डालेगा, तो उसका समय और विवरण यहाँ दर्ज होगा।'
              : 'Unauthorized attempts with wrong PIN or pattern will be recorded here automatically.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {intruderRecords.map((record) => (
            <div
              key={record.id}
              className="p-4 rounded-2xl bg-zinc-900/90 border border-rose-500/30 flex items-start justify-between gap-4 shadow-md"
            >
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                  <UserX className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-rose-400 uppercase tracking-wide">
                      {record.reason === 'wrong_pin'
                        ? 'Wrong PIN Attempt'
                        : record.reason === 'wrong_pattern'
                        ? 'Wrong Pattern Attempt'
                        : 'Unauthorized Trigger'}
                    </span>
                    {record.appName && (
                      <span className="text-[10px] px-2 py-0.2 rounded-full bg-zinc-800 text-zinc-300 font-mono">
                        {record.appName}
                      </span>
                    )}
                  </div>

                  {record.attemptedPin && (
                    <p className="text-xs text-zinc-300 font-mono">
                      {t.intruderPinEntered}: <span className="text-amber-400 font-bold">{record.attemptedPin}</span>
                    </p>
                  )}

                  <div className="text-[11px] text-zinc-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(record.timestamp).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
