import React, { useState, useEffect } from 'react';
import { SecretNote, NoteCategory } from '../../types';
import {
  X,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Sparkles,
  Key,
  Shield,
  FileText
} from 'lucide-react';
import { useVault } from '../../context/VaultContext';

interface NoteEditorModalProps {
  note: SecretNote | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (note: SecretNote) => void;
}

export const NoteEditorModal: React.FC<NoteEditorModalProps> = ({
  note,
  isOpen,
  onClose,
  onSave
}) => {
  const { t, language } = useVault();

  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [category, setCategory] = useState<NoteCategory>('passwords');
  const [color, setColor] = useState<string>('#1e293b');
  const [sensitiveFields, setSensitiveFields] = useState<{ label: string; value: string; isHidden: boolean }[]>([]);

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
      setCategory(note.category);
      setColor(note.color || '#1e293b');
      setSensitiveFields(note.sensitiveFields || []);
    } else {
      setTitle('');
      setContent('');
      setCategory('passwords');
      setColor('#1e293b');
      setSensitiveFields([]);
    }
  }, [note, isOpen]);

  if (!isOpen) return null;

  const handleAddField = () => {
    setSensitiveFields((prev) => [...prev, { label: 'Password', value: '', isHidden: true }]);
  };

  const handleUpdateField = (index: number, key: 'label' | 'value' | 'isHidden', val: any) => {
    setSensitiveFields((prev) =>
      prev.map((f, i) => (i === index ? { ...f, [key]: val } : f))
    );
  };

  const handleRemoveField = (index: number) => {
    setSensitiveFields((prev) => prev.filter((_, i) => i !== index));
  };

  const handleGeneratePassword = (index: number) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+';
    let pass = '';
    for (let i = 0; i < 16; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    handleUpdateField(index, 'value', pass);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const updated: SecretNote = {
      id: note?.id || `note-${Date.now()}`,
      title: title.trim(),
      content: content.trim(),
      category,
      color,
      isPinned: note?.isPinned || false,
      isFavorite: note?.isFavorite || false,
      createdAt: note?.createdAt || Date.now(),
      updatedAt: Date.now(),
      sensitiveFields
    };

    onSave(updated);
    onClose();
  };

  return (
    <div id="note-editor-modal-overlay" className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div id="note-editor-modal-container" className="w-full max-w-xl bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl relative text-zinc-100 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-zinc-100">
                {note ? t.edit : t.createNote}
              </h3>
              <p className="text-[11px] text-zinc-400">
                {language === 'hi' ? 'गोपनीय जानकारी व पासवर्ड सुरक्षित करें' : 'Store passwords and confidential records'}
              </p>
            </div>
          </div>
          <button
            id="btn-close-note-editor"
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-zinc-200 rounded-full hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
          
          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
              {language === 'hi' ? 'नोट का शीर्षक' : 'Note Title'}
            </label>
            <input
              type="text"
              required
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={t.noteTitlePlaceholder}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 px-3 text-xs text-zinc-100 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
              {language === 'hi' ? 'श्रेणी (Category)' : 'Category'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'passwords', label: t.categoryPasswords },
                { id: 'bank', label: t.categoryBank },
                { id: 'personal', label: t.categoryPersonal },
                { id: 'crypto', label: t.categoryCrypto },
                { id: 'work', label: t.categoryWork },
                { id: 'general', label: t.categoryGeneral }
              ].map((cat) => (
                <button
                  type="button"
                  key={cat.id}
                  onClick={() => setCategory(cat.id as NoteCategory)}
                  className={`p-2 rounded-xl text-left text-xs font-medium border transition-colors ${
                    category === cat.id
                      ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sensitive Password/PIN Fields */}
          <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                {t.addSensitiveField}
              </span>
              <button
                type="button"
                onClick={handleAddField}
                className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-[11px] font-medium text-zinc-200 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add Field</span>
              </button>
            </div>

            {sensitiveFields.map((field, idx) => (
              <div key={idx} className="flex items-center gap-2 bg-zinc-900/80 p-2 rounded-xl border border-zinc-800">
                <input
                  type="text"
                  value={field.label}
                  onChange={(e) => handleUpdateField(idx, 'label', e.target.value)}
                  placeholder="Label (e.g. UPI PIN)"
                  className="w-1/3 bg-zinc-950 border border-zinc-800 rounded-lg px-2 py-1.5 text-xs text-zinc-200"
                />
                
                <div className="relative flex-1">
                  <input
                    type={field.isHidden ? 'password' : 'text'}
                    value={field.value}
                    onChange={(e) => handleUpdateField(idx, 'value', e.target.value)}
                    placeholder="Value / Password..."
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2 py-1.5 text-xs font-mono text-amber-400 pr-14"
                  />
                  <div className="absolute right-1 top-1 flex items-center">
                    <button
                      type="button"
                      onClick={() => handleUpdateField(idx, 'isHidden', !field.isHidden)}
                      className="p-1 text-zinc-400 hover:text-zinc-200"
                      title={field.isHidden ? t.showSecret : t.hideSecret}
                    >
                      {field.isHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleGeneratePassword(idx)}
                      className="p-1 text-amber-400 hover:text-amber-300"
                      title={t.generatePassword}
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleRemoveField(idx)}
                  className="p-1 text-rose-400 hover:text-rose-300"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Main Content Area */}
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
              {language === 'hi' ? 'विवरण या डायरी' : 'Note Content'}
            </label>
            <textarea
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={t.noteContentPlaceholder}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 px-3 text-xs text-zinc-100 focus:outline-none focus:border-blue-500 font-sans leading-relaxed"
            />
          </div>

          {/* Action Footer */}
          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-300"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white shadow-lg shadow-blue-600/20"
            >
              {t.save}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
