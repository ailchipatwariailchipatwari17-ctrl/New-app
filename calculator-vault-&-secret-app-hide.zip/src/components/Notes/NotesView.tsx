import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { SecretNote, NoteCategory } from '../../types';
import {
  FileText,
  Plus,
  Search,
  Pin,
  Heart,
  Key,
  Copy,
  Check,
  Eye,
  EyeOff,
  Trash2,
  Edit,
  Shield,
  CreditCard,
  BookOpen,
  Briefcase,
  Bitcoin
} from 'lucide-react';
import { NoteEditorModal } from './NoteEditorModal';

export const NotesView: React.FC = () => {
  const {
    t,
    notes,
    addOrUpdateNote,
    deleteNote,
    toggleNotePin,
    toggleNoteFavorite,
    language
  } = useVault();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [editingNote, setEditingNote] = useState<SecretNote | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false);
  const [revealedSecrets, setRevealedSecrets] = useState<{ [key: string]: boolean }>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const toggleReveal = (key: string) => {
    setRevealedSecrets((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const filteredNotes = notes.filter((n) => {
    if (activeCategory !== 'all' && n.category !== activeCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = n.title.toLowerCase().includes(q);
      const matchContent = n.content.toLowerCase().includes(q);
      const matchFields = (n.sensitiveFields || []).some(
        (f) => f.label.toLowerCase().includes(q) || f.value.toLowerCase().includes(q)
      );
      return matchTitle || matchContent || matchFields;
    }
    return true;
  }).sort((a, b) => {
    // Pinned notes first
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return b.updatedAt - a.updatedAt;
  });

  const categories = [
    { id: 'all', label: t.categoryAll, icon: FileText },
    { id: 'passwords', label: t.categoryPasswords, icon: Key },
    { id: 'bank', label: t.categoryBank, icon: CreditCard },
    { id: 'personal', label: t.categoryPersonal, icon: BookOpen },
    { id: 'crypto', label: t.categoryCrypto, icon: Bitcoin },
    { id: 'work', label: t.categoryWork, icon: Briefcase }
  ];

  return (
    <div id="notes-view-container" className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-zinc-100 flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center">
              <Key className="w-4 h-4" />
            </span>
            {t.notesTitle}
          </h2>
          <p className="text-xs text-zinc-400 mt-1">{t.notesSubtitle}</p>
        </div>

        <button
          id="btn-create-secret-note"
          onClick={() => {
            setEditingNote(null);
            setIsEditorOpen(true);
          }}
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-lg shadow-blue-600/25 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t.createNote}</span>
        </button>
      </div>

      {/* Search Bar & Category Pills */}
      <div className="flex flex-col gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchNotes}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-2.5 pl-10 pr-4 text-xs text-zinc-100 focus:outline-none focus:border-blue-500 shadow-inner"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSel = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all flex items-center gap-1.5 ${
                  isSel
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                    : 'bg-zinc-900/80 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Notes Grid */}
      {filteredNotes.length === 0 ? (
        <div className="p-12 text-center border border-zinc-900 rounded-3xl bg-zinc-950/60">
          <FileText className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
          <h4 className="text-sm font-semibold text-zinc-400">{t.noNotes}</h4>
          <p className="text-xs text-zinc-600 mt-1">
            {language === 'hi' ? 'नया पासवर्ड या नोट जोड़ने के लिए ऊपर दिए बटन पर क्लिक करें' : 'Click "Create New Note" to store passwords and confidential thoughts'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-4.5 flex flex-col justify-between shadow-md hover:border-zinc-700 transition-all space-y-3 relative group"
            >
              {/* Note Header */}
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/20">
                      {note.category}
                    </span>
                    {note.isPinned && (
                      <Pin className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => toggleNoteFavorite(note.id)}
                      className={`p-1 rounded-md ${note.isFavorite ? 'text-rose-400' : 'text-zinc-500 hover:text-zinc-300'}`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${note.isFavorite ? 'fill-rose-400' : ''}`} />
                    </button>
                    <button
                      onClick={() => toggleNotePin(note.id)}
                      className={`p-1 rounded-md ${note.isPinned ? 'text-amber-400' : 'text-zinc-500 hover:text-zinc-300'}`}
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        setEditingNote(note);
                        setIsEditorOpen(true);
                      }}
                      className="p-1 rounded-md text-zinc-500 hover:text-zinc-300"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteNote(note.id)}
                      className="p-1 rounded-md text-zinc-500 hover:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-zinc-100 mt-2 line-clamp-1">{note.title}</h3>
                {note.content && (
                  <p className="text-xs text-zinc-400 mt-1 line-clamp-3 whitespace-pre-wrap leading-relaxed">
                    {note.content}
                  </p>
                )}
              </div>

              {/* Sensitive Key-Value Fields */}
              {note.sensitiveFields && note.sensitiveFields.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-zinc-800/80">
                  {note.sensitiveFields.map((field, fIdx) => {
                    const secretKey = `${note.id}-${fIdx}`;
                    const isRevealed = revealedSecrets[secretKey] ?? !field.isHidden;
                    const isCopied = copiedKey === secretKey;

                    return (
                      <div
                        key={fIdx}
                        className="p-2 rounded-xl bg-zinc-950 border border-zinc-800/80 flex items-center justify-between gap-2"
                      >
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] text-zinc-500 block truncate">{field.label}</span>
                          <span className="text-xs font-mono font-medium text-amber-400 truncate block">
                            {isRevealed ? field.value : '••••••••••••'}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => toggleReveal(secretKey)}
                            className="p-1 text-zinc-400 hover:text-zinc-200"
                            title={isRevealed ? t.hideSecret : t.showSecret}
                          >
                            {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            onClick={() => handleCopy(field.value, secretKey)}
                            className={`p-1 transition-colors ${isCopied ? 'text-emerald-400' : 'text-zinc-400 hover:text-zinc-200'}`}
                            title={t.copy}
                          >
                            {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Footer Timestamp */}
              <div className="pt-2 text-[10px] text-zinc-500 flex justify-between items-center">
                <span>Updated {new Date(note.updatedAt).toLocaleDateString()}</span>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Note Editor Modal */}
      <NoteEditorModal
        note={editingNote}
        isOpen={isEditorOpen}
        onClose={() => {
          setIsEditorOpen(false);
          setEditingNote(null);
        }}
        onSave={(saved) => addOrUpdateNote(saved)}
      />

    </div>
  );
};
