import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { DEFAULT_SECURITY_QUESTIONS } from '../../data/initialData';
import {
  Settings,
  KeyRound,
  Shield,
  Volume2,
  Sparkles,
  Languages,
  Trash2,
  Check,
  AlertCircle,
  CloudSun,
  Coins,
  FileSpreadsheet,
  QrCode,
  Calculator as CalcIcon,
  HelpCircle,
  EyeOff,
  Monitor,
  Smartphone,
  Laptop
} from 'lucide-react';
import { soundManager } from '../../utils/sound';

export const SettingsView: React.FC = () => {
  const {
    t,
    securitySettings,
    updateSecuritySettings,
    resetAllData,
    language,
    setLanguage,
    setDeviceMode,
    effectiveDeviceMode,
    isDecoyMode
  } = useVault();

  const [newMasterPin, setNewMasterPin] = useState<string>('');
  const [newDecoyPin, setNewDecoyPin] = useState<string>(securitySettings.decoyPin || '');
  const [newSecurityQuestion, setNewSecurityQuestion] = useState<string>(
    securitySettings.securityQuestion || DEFAULT_SECURITY_QUESTIONS[0]
  );
  const [newSecurityAnswer, setNewSecurityAnswer] = useState<string>(
    securitySettings.securityAnswer || ''
  );
  const [toast, setToast] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  const showToast = (msg: string) => {
    setToast(msg);
    soundManager.playUnlockChime();
    setTimeout(() => setToast(null), 2500);
  };

  const handleUpdateMasterPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMasterPin.length < 4 || newMasterPin.length > 6) {
      alert(language === 'hi' ? 'पिन 4 से 6 अंकों का होना चाहिए।' : 'PIN must be 4 to 6 digits.');
      return;
    }
    updateSecuritySettings({ pin: newMasterPin });
    showToast(language === 'hi' ? `मास्टर पिन ${newMasterPin} सेट हो गया!` : `Master PIN updated to ${newMasterPin}!`);
    setNewMasterPin('');
  };

  const handleUpdateDecoyPin = (e: React.FormEvent) => {
    e.preventDefault();
    updateSecuritySettings({ decoyPin: newDecoyPin });
    showToast(language === 'hi' ? 'सेकेंडरी पिन अपडेट हो गया!' : 'Secondary PIN saved!');
  };

  const handleUpdateSecQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSecurityAnswer.trim()) return;
    updateSecuritySettings({
      securityQuestion: newSecurityQuestion,
      securityAnswer: newSecurityAnswer.trim().toLowerCase()
    });
    showToast(language === 'hi' ? 'सुरक्षा सवाल व उत्तर सुरक्षित हुआ!' : 'Security Question updated!');
  };

  const disguiseOptions = [
    { id: 'calculator', name: 'Calculator (Standard)', icon: CalcIcon },
    { id: 'weather', name: 'Weather Live (28°C)', icon: CloudSun },
    { id: 'converter', name: 'Currency (USD/INR)', icon: Coins },
    { id: 'notes', name: 'Quick Notes & Memo', icon: FileSpreadsheet },
    { id: 'scanner', name: 'Doc & QR Scanner', icon: QrCode }
  ];

  return (
    <div id="settings-view-container" className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6">
      
      {/* Toast */}
      {toast && (
        <div className="fixed top-6 right-6 z-50 p-3.5 rounded-2xl bg-emerald-500 text-zinc-950 font-bold text-xs shadow-2xl flex items-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4" />
          <span>{toast}</span>
        </div>
      )}

      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-zinc-100 flex items-center gap-2">
          <span className="w-8 h-8 rounded-xl bg-zinc-800 text-zinc-300 flex items-center justify-center">
            <Settings className="w-4 h-4" />
          </span>
          {t.settingsTitle}
        </h2>
        <p className="text-xs text-zinc-400 mt-1">
          {language === 'hi' ? 'पिन, सुरक्षा पासकोड, ऐप रूप और प्राइवेसी विकल्प' : 'Master PIN, Security Codes, Icon Disguise & Privacy'}
        </p>
      </div>

      {/* Section 1: Security & PIN Management */}
      <div className="p-5 rounded-3xl bg-zinc-900/90 border border-zinc-800 space-y-4">
        <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-amber-400" />
          <span>{t.securityHeading}</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Change Master PIN */}
          <form onSubmit={handleUpdateMasterPin} className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
            <label className="block text-xs font-semibold text-zinc-300">
              {t.changePin} (Current: <span className="font-mono text-amber-400">{isDecoyMode ? '••••' : securitySettings.pin}</span>)
            </label>
            <div className="flex gap-2">
              <input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                value={newMasterPin}
                onChange={(e) => setNewMasterPin(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="नया 4-6 अंक का पिन..."
                className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-amber-400 font-mono focus:outline-none focus:border-amber-500"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-amber-500 text-zinc-950 text-xs font-bold hover:bg-amber-400"
              >
                {t.save}
              </button>
            </div>
          </form>

          {/* Secondary / Decoy PIN (hidden in decoy mode to maintain complete stealth) */}
          {!isDecoyMode && (
            <form onSubmit={handleUpdateDecoyPin} className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-300">
                  {t.setupDecoyPin}
                </label>
                <p className="text-[11px] text-zinc-500 mt-0.5">{t.decoyPinDesc}</p>
              </div>
              <div className="flex gap-2">
                <input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={6}
                  value={newDecoyPin}
                  onChange={(e) => setNewDecoyPin(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="उदा. 0000"
                  className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-rose-400 font-mono focus:outline-none focus:border-rose-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-rose-500 text-white text-xs font-bold hover:bg-rose-400"
                >
                  {t.save}
                </button>
              </div>
            </form>
          )}

        </div>

        {/* Change Security Question */}
        <form onSubmit={handleUpdateSecQuestion} className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold text-zinc-200">{t.changeSecQuestion}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">{t.securityQuestionLabel}</label>
              <select
                value={newSecurityQuestion}
                onChange={(e) => setNewSecurityQuestion(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-2.5 text-xs text-zinc-200"
              >
                {DEFAULT_SECURITY_QUESTIONS.map((q, idx) => (
                  <option key={idx} value={q}>
                    {q}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">{t.securityAnswerLabel}</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  value={newSecurityAnswer}
                  onChange={(e) => setNewSecurityAnswer(e.target.value)}
                  placeholder="Secret answer..."
                  className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-zinc-200"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-500 text-zinc-950 text-xs font-bold hover:bg-emerald-400"
                >
                  {t.save}
                </button>
              </div>
            </div>
          </div>
        </form>

      </div>

      {/* Section 2: Icon Disguise */}
      <div className="p-5 rounded-3xl bg-zinc-900/90 border border-zinc-800 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>{t.disguiseHeading}</span>
          </h3>
          <p className="text-xs text-zinc-400 mt-1">{t.disguiseDesc}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {disguiseOptions.map((opt) => {
            const Icon = opt.icon;
            const isSel = securitySettings.disguiseIcon === opt.id;
            return (
              <div
                key={opt.id}
                onClick={() => {
                  updateSecuritySettings({ disguiseIcon: opt.id as any });
                  showToast(language === 'hi' ? 'ऐप का रूप बदल दिया गया!' : 'App Disguise Updated!');
                }}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-3 ${
                  isSel
                    ? 'bg-purple-950/30 border-purple-500 shadow-md shadow-purple-500/10'
                    : 'bg-zinc-950 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-xl ${isSel ? 'bg-purple-600 text-white' : 'bg-zinc-800 text-zinc-400'} flex items-center justify-center`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-zinc-200">{opt.name}</span>
                </div>
                {isSel && <Check className="w-4 h-4 text-purple-400" />}
              </div>
            );
          })}
        </div>
      </div>

      {/* Section 3: Sounds & Safety Preferences */}
      <div className="p-5 rounded-3xl bg-zinc-900/90 border border-zinc-800 space-y-4">
        <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-sky-400" />
          <span>{t.soundHapticsHeading}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          
          {/* Sound Toggle */}
          <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-zinc-200 block">{t.enableClickSound}</span>
              <span className="text-[10px] text-zinc-500">Keypad audio chimes</span>
            </div>
            <button
              onClick={() => updateSecuritySettings({ soundEnabled: !securitySettings.soundEnabled })}
              className={`w-11 h-6 rounded-full transition-colors relative ${securitySettings.soundEnabled ? 'bg-emerald-500' : 'bg-zinc-800'}`}
            >
              <div className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${securitySettings.soundEnabled ? 'right-1' : 'left-1'}`} />
            </button>
          </div>

          {/* Fake Crash Toggle */}
          <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-zinc-200 block">{t.enableFakeCrashToggle}</span>
              <span className="text-[10px] text-zinc-500">Shows "App Stopped" error dialog</span>
            </div>
            <button
              onClick={() => updateSecuritySettings({ enableFakeCrash: !securitySettings.enableFakeCrash })}
              className={`w-11 h-6 rounded-full transition-colors relative ${securitySettings.enableFakeCrash ? 'bg-emerald-500' : 'bg-zinc-800'}`}
            >
              <div className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${securitySettings.enableFakeCrash ? 'right-1' : 'left-1'}`} />
            </button>
          </div>

          {/* Language Toggle */}
          <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Languages className="w-4 h-4 text-amber-400" />
              <div>
                <span className="text-xs font-semibold text-zinc-200 block">{t.languageHeading}</span>
                <span className="text-[10px] text-zinc-500">हिन्दी / English</span>
              </div>
            </div>
            <button
              onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
              className="px-3 py-1 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-amber-400"
            >
              {language === 'hi' ? 'हिन्दी (Active)' : 'English (Active)'}
            </button>
          </div>

          {/* Device Adaptability Mode */}
          <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:col-span-2">
            <div className="flex items-center gap-2.5">
              <Monitor className="w-4 h-4 text-cyan-400" />
              <div>
                <span className="text-xs font-semibold text-zinc-200 block">
                  {language === 'hi' ? 'डिवाइस मोड (Mobile & PC Adaptability)' : 'Device Adaptability Mode'}
                </span>
                <span className="text-[10px] text-zinc-500">
                  {language === 'hi' 
                    ? `वर्तमान: ${effectiveDeviceMode === 'pc' ? 'कंप्यूटर / PC मोड' : 'स्मार्टफोन / Mobile मोड'} (Auto Detect)` 
                    : `Active: ${effectiveDeviceMode === 'pc' ? 'PC Desktop' : 'Mobile Phone'} (Auto Responsive)`}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 bg-zinc-900 p-1 rounded-xl border border-zinc-800">
              <button
                onClick={() => {
                  setDeviceMode('auto');
                  showToast(language === 'hi' ? 'ऑटो मोड सक्रिय (स्मार्टफोन/PC डिटेक्शन)' : 'Auto device detection enabled');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  securitySettings.deviceMode === 'auto'
                    ? 'bg-cyan-500 text-zinc-950 shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Auto
              </button>
              <button
                onClick={() => {
                  setDeviceMode('mobile');
                  showToast(language === 'hi' ? 'मोबाइल मोड लागू किया गया' : 'Mobile mode activated');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                  securitySettings.deviceMode === 'mobile'
                    ? 'bg-cyan-500 text-zinc-950 shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3 h-3" />
                Mobile
              </button>
              <button
                onClick={() => {
                  setDeviceMode('pc');
                  showToast(language === 'hi' ? 'PC मोड लागू किया गया' : 'PC mode activated');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                  securitySettings.deviceMode === 'pc'
                    ? 'bg-cyan-500 text-zinc-950 shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Laptop className="w-3 h-3" />
                PC
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Section 4: Data Reset */}
      <div className="p-5 rounded-3xl bg-rose-950/20 border border-rose-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-rose-400 flex items-center gap-2">
            <Trash2 className="w-4 h-4" />
            <span>{t.backupHeading}</span>
          </h4>
          <p className="text-xs text-zinc-400 mt-1">
            {language === 'hi' ? 'सभी छिपी हुई फाइलों, पासवर्ड और सेटिंग्स को रीसेट करें' : 'Clear all cached media, notes, and configurations'}
          </p>
        </div>

        <button
          onClick={() => setShowResetConfirm(true)}
          className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors shadow-md shadow-rose-600/20 self-start sm:self-auto"
        >
          {t.resetAllData}
        </button>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl max-w-sm w-full space-y-4 text-center">
            <AlertCircle className="w-12 h-12 text-rose-500 mx-auto" />
            <h4 className="text-sm font-bold text-zinc-100">{t.resetAllData}</h4>
            <p className="text-xs text-zinc-400">{t.resetConfirm}</p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300"
              >
                {t.cancel}
              </button>
              <button
                onClick={async () => {
                  await resetAllData();
                  setShowResetConfirm(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-xs font-bold text-white"
              >
                {t.delete}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
