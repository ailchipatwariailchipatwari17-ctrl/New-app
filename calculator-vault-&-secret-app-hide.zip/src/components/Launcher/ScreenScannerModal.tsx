import React, { useState, useEffect } from 'react';
import { useVault } from '../../context/VaultContext';
import { OSType, IconShape, GridSize } from '../../types';
import { WALLPAPER_PRESETS } from '../../data/initialData';
import { AppIcon } from './AppIcon';
import {
  Scan,
  Smartphone,
  CheckCircle2,
  Sparkles,
  Upload,
  Image as ImageIcon,
  Sliders,
  ShieldCheck,
  Zap,
  Radio,
  Eye,
  X,
  Maximize2,
  Lock,
  Flame,
  Layers,
  Check,
  Bell
} from 'lucide-react';
import { soundManager } from '../../utils/sound';

export const ScreenScannerModal: React.FC = () => {
  const {
    isScannerModalOpen,
    setIsScannerModalOpen,
    launcherConfig,
    updateLauncherConfig,
    setAppViewMode,
    toggleFullscreen,
    language,
    securitySettings
  } = useVault();

  const [scanStep, setScanStep] = useState<'scanning' | 'results' | 'customize'>('scanning');
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [detectedSpecs, setDetectedSpecs] = useState<{
    resolution: string;
    dpr: number;
    colorDepth: number;
    orientation: string;
    osSuggestion: OSType;
  } | null>(null);

  // Form states
  const [selectedOS, setSelectedOS] = useState<OSType>(launcherConfig.osType);
  const [selectedWallpaper, setSelectedWallpaper] = useState<string>(launcherConfig.wallpaperPreset);
  const [customWallpaper, setCustomWallpaper] = useState<string>(launcherConfig.customWallpaperUrl || '');
  const [carrier, setCarrier] = useState<string>(launcherConfig.carrierName);
  const [battery, setBattery] = useState<number>(launcherConfig.batteryLevel);
  const [iconShape, setIconShape] = useState<IconShape>(launcherConfig.iconShape);
  const [iconSize, setIconSize] = useState<'compact' | 'normal' | 'large'>(launcherConfig.iconSize || 'normal');
  const [showNotificationBadges, setShowNotificationBadges] = useState<boolean>(launcherConfig.showNotificationBadges ?? true);
  const [gridSize, setGridSize] = useState<GridSize>(launcherConfig.gridSize);
  const [showGoogle, setShowGoogle] = useState<boolean>(launcherConfig.showGoogleSearch);
  const [showWeather, setShowWeather] = useState<boolean>(launcherConfig.showWeatherWidget);

  useEffect(() => {
    if (isScannerModalOpen) {
      setScanStep('scanning');
      setScanProgress(0);

      // Perform simulated deep screen scan
      const interval = setInterval(() => {
        setScanProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 20;
        });
      }, 150);

      const timer = setTimeout(() => {
        // Detect actual screen dimensions
        const width = window.screen.width;
        const height = window.screen.height;
        const dpr = window.devicePixelRatio || 1;
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        const isAndroid = /Android/.test(navigator.userAgent);

        const osSuggestion: OSType = isIOS ? 'ios' : isAndroid ? 'oneui' : 'pixel';

        setDetectedSpecs({
          resolution: `${Math.round(width * dpr)} x ${Math.round(height * dpr)} px`,
          dpr: Math.round(dpr * 100) / 100,
          colorDepth: window.screen.colorDepth || 24,
          orientation: window.screen.orientation ? window.screen.orientation.type : 'portrait-primary',
          osSuggestion
        });

        setSelectedOS(osSuggestion);
        setScanStep('results');
        soundManager.playUnlockChime();
      }, 1100);

      return () => {
        clearInterval(interval);
        clearTimeout(timer);
      };
    }
  }, [isScannerModalOpen]);

  if (!isScannerModalOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          setCustomWallpaper(reader.result as string);
          setSelectedWallpaper('custom');
          soundManager.playClick();
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyLauncher = () => {
    updateLauncherConfig({
      osType: selectedOS,
      wallpaperPreset: selectedWallpaper,
      customWallpaperUrl: customWallpaper,
      carrierName: carrier,
      batteryLevel: battery,
      iconShape,
      iconSize,
      showNotificationBadges,
      gridSize,
      showGoogleSearch: showGoogle,
      showWeatherWidget: showWeather,
      secretDialCode: `*#${securitySettings.pin}#`
    });

    setIsScannerModalOpen(false);
    setAppViewMode('launcher');
    soundManager.playUnlockChime();

    // Request fullscreen for true 1:1 realism
    try {
      toggleFullscreen();
    } catch {}
  };

  const osPresets: { id: OSType; name: string; brand: string; iconColor: string }[] = [
    { id: 'oneui', name: 'Samsung OneUI 6.1', brand: 'Galaxy S24 Ultra', iconColor: 'from-blue-600 to-indigo-700' },
    { id: 'ios', name: 'Apple iOS 18 (Dynamic Island)', brand: 'iPhone 16 Pro', iconColor: 'from-zinc-700 to-zinc-900' },
    { id: 'pixel', name: 'Google Pixel Material You', brand: 'Pixel 9 Pro', iconColor: 'from-emerald-600 to-teal-700' },
    { id: 'oxygen', name: 'OnePlus OxygenOS 14', brand: 'OnePlus 12', iconColor: 'from-red-600 to-rose-700' },
    { id: 'hyperos', name: 'Xiaomi HyperOS', brand: 'Xiaomi 14', iconColor: 'from-amber-600 to-orange-700' },
    { id: 'nothing', name: 'Nothing OS Minimal', brand: 'Phone (2)', iconColor: 'from-neutral-900 to-black' },
  ];

  return (
    <div id="screen-scanner-modal-overlay" className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div id="screen-scanner-card" className="w-full max-w-xl bg-zinc-950 border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden text-zinc-100 relative">
        
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Scan className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                {language === 'hi' ? 'फ़ोन स्क्रीन स्कैनर और 1:1 क्लोन' : 'Screen Scanner & 1:1 Clone Engine'}
              </h3>
              <p className="text-xs text-zinc-400">
                {language === 'hi' ? '0.0001% भी फ़र्क नहीं, 100% असली फोन जैसी स्क्रीन' : 'Zero-difference stealth launcher mirror'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsScannerModalOpen(false)}
            className="p-2 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Laser Scanning Display */}
        {scanStep === 'scanning' && (
          <div className="p-8 sm:p-12 text-center space-y-6 flex flex-col items-center justify-center min-h-[340px]">
            <div className="relative w-28 h-48 rounded-2xl border-2 border-purple-500/60 bg-purple-950/20 flex flex-col items-center justify-center overflow-hidden shadow-2xl shadow-purple-500/10">
              {/* Laser Scanning Line */}
              <div
                className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#38bdf8] transition-all duration-200"
                style={{ top: `${scanProgress}%` }}
              />
              <Smartphone className="w-10 h-10 text-purple-400/80 mb-2" />
              <span className="text-[11px] font-mono text-purple-300">
                {scanProgress}%
              </span>
            </div>

            <div className="space-y-1">
              <p className="text-sm font-semibold text-zinc-200">
                {language === 'hi' ? 'स्क्रीन रेजोल्यूशन और डिस्प्ले ग्रिड स्कैन हो रहा है...' : 'Scanning screen resolution, PPI & geometry...'}
              </p>
              <p className="text-xs text-zinc-500 font-mono">
                Analyzing Viewport: {window.innerWidth}x{window.innerHeight} | DPR: {window.devicePixelRatio || 1}
              </p>
            </div>

            {/* Progress bar */}
            <div className="w-full max-w-xs h-2 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
              <div
                className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 transition-all duration-200"
                style={{ width: `${scanProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Step 2 & 3: Results & Customization */}
        {scanStep !== 'scanning' && (
          <div className="p-4 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
            
            {/* Scan Success Badge */}
            <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <span className="font-semibold text-emerald-300 block">
                  {language === 'hi' ? 'स्क्रीन स्कैन पूर्ण! 1:1 सटीक क्लोन तैयार' : 'Screen Scanned Successfully! 1:1 Clone Ready'}
                </span>
                <p className="text-zinc-400">
                  {language === 'hi'
                    ? `रेजोल्यूशन: ${detectedSpecs?.resolution || 'HD+'} | स्टेटस बार, वॉलपेपर और ग्रिड स्वचालित रूप से मैच कर दिए गए हैं।`
                    : `Resolution: ${detectedSpecs?.resolution || 'HD+'} | Status bar, grid and styling auto-configured.`}
                </p>
              </div>
            </div>

            {/* 1. OS & Device Skin Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                {language === 'hi' ? '1. फ़ोन मॉडल / OS स्टाइल चुनें:' : '1. Select Phone Model / OS Style:'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {osPresets.map((os) => {
                  const isSelected = selectedOS === os.id;
                  return (
                    <button
                      key={os.id}
                      onClick={() => {
                        setSelectedOS(os.id);
                        soundManager.playClick();
                      }}
                      className={`p-3 rounded-2xl border text-left transition-all relative ${
                        isSelected
                          ? 'border-purple-500 bg-purple-950/40 shadow-lg shadow-purple-500/10'
                          : 'border-zinc-800 bg-zinc-900/50 hover:border-zinc-700'
                      }`}
                    >
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-purple-500 text-white flex items-center justify-center">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </div>
                      )}
                      <span className="text-xs font-bold text-white block">{os.name}</span>
                      <span className="text-[10px] text-zinc-400 block mt-0.5">{os.brand}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Wallpaper Selection (Preset or Real Phone Wallpaper Upload) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-blue-400" />
                  {language === 'hi' ? '2. वॉलपेपर (असली फ़ोन का वॉलपेपर या 4K प्रीसेट):' : '2. Wallpaper (Upload Real Wallpaper or Preset):'}
                </label>
              </div>

              {/* Presets Grid */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {WALLPAPER_PRESETS.map((wp) => {
                  const isSelected = selectedWallpaper === wp.id;
                  return (
                    <button
                      key={wp.id}
                      onClick={() => {
                        setSelectedWallpaper(wp.id);
                        setCustomWallpaper('');
                        soundManager.playClick();
                      }}
                      className={`relative aspect-[9/16] rounded-xl overflow-hidden border-2 transition-all group ${
                        isSelected ? 'border-purple-500 ring-2 ring-purple-500/50 scale-95' : 'border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <img src={wp.url} alt={wp.name} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-1">
                        <span className="text-[9px] font-medium text-white truncate">{wp.name.split(' ')[0]}</span>
                      </div>
                      {isSelected && (
                        <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-purple-500 text-white flex items-center justify-center">
                          <Check className="w-2.5 h-2.5" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Upload Custom Real Phone Screenshot / Wallpaper */}
              <div className="mt-2">
                <label className="flex items-center justify-center gap-2 p-3 rounded-2xl border-2 border-dashed border-zinc-800 hover:border-purple-500/50 bg-zinc-900/30 cursor-pointer transition-colors text-xs text-zinc-300">
                  <Upload className="w-4 h-4 text-purple-400" />
                  <span>
                    {language === 'hi' ? 'अपने असली फ़ोन का स्क्रीनशॉट/वॉलपेपर अपलोड करें' : 'Upload Screenshot of your Real Phone Screen'}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                {customWallpaper && (
                  <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {language === 'hi' ? 'कस्टम वॉलपेपर लोड हो गया!' : 'Custom wallpaper loaded!'}
                  </p>
                )}
              </div>
            </div>

            {/* 3. Authentic 1:1 App Icon Sizing, Shapes & Live Preview */}
            <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-purple-400" />
                  <span className="text-xs font-bold text-white">
                    {language === 'hi' ? 'ऐप आइकॉन साइज व फोटो (1:1 असली फोन जैसा टू-सेम):' : 'App Icon Size & Logo (1:1 Authentic Fidelity):'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowNotificationBadges((prev) => !prev)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold border transition-colors flex items-center gap-1 ${
                    showNotificationBadges
                      ? 'bg-red-500/20 text-red-300 border-red-500/40'
                      : 'bg-zinc-800 text-zinc-500 border-zinc-700'
                  }`}
                >
                  <Bell className="w-3 h-3" />
                  {showNotificationBadges ? (language === 'hi' ? 'नोटिफिकेशन बैज: ON' : 'Badges: ON') : (language === 'hi' ? 'नोटिफिकेशन बैज: OFF' : 'Badges: OFF')}
                </button>
              </div>

              {/* Icon Size Picker */}
              <div className="space-y-1.5">
                <label className="text-[11px] text-zinc-400 font-medium">
                  {language === 'hi' ? 'आइकॉन साइज चुनें:' : 'Select Icon Size:'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['compact', 'normal', 'large'] as const).map((sz) => {
                    const isSelected = iconSize === sz;
                    const labels = {
                      compact: language === 'hi' ? 'छोटा (48px Compact)' : 'Compact (48px)',
                      normal: language === 'hi' ? 'सामान्य (58px 1:1 Phone)' : 'Normal (58px 1:1)',
                      large: language === 'hi' ? 'बड़ा (66px Large)' : 'Large (66px)'
                    };
                    return (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => {
                          setIconSize(sz);
                          soundManager.playClick();
                        }}
                        className={`py-2 px-2.5 rounded-xl text-xs font-semibold border transition-all ${
                          isSelected
                            ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                            : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
                        }`}
                      >
                        {labels[sz]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Icon Shape Picker */}
              <div className="space-y-1.5">
                <label className="text-[11px] text-zinc-400 font-medium">
                  {language === 'hi' ? 'आइकॉन का आकार (Shape):' : 'Icon Shape Style:'}
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['squircle', 'rounded', 'circle', 'teardrop'] as const).map((sh) => {
                    const isSelected = iconShape === sh;
                    const shapeLabels = {
                      squircle: 'Squircle (OneUI/iOS)',
                      rounded: 'Rounded (OxygenOS)',
                      circle: 'Circle (Pixel)',
                      teardrop: 'Teardrop (MIUI)'
                    };
                    return (
                      <button
                        key={sh}
                        type="button"
                        onClick={() => {
                          setIconShape(sh);
                          soundManager.playClick();
                        }}
                        className={`py-1.5 px-2 rounded-xl text-[11px] capitalize font-medium border text-center transition-all ${
                          isSelected
                            ? 'bg-cyan-950 text-cyan-300 border-cyan-500 shadow'
                            : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                        }`}
                      >
                        {sh}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Live Real-Time Icon Preview */}
              <div className="p-3 rounded-xl bg-zinc-950/80 border border-zinc-800/80 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-zinc-400 font-mono">
                  <span>{language === 'hi' ? 'लाइव आइकॉन प्रीव्यू (Live Real Preview):' : 'Live Real Preview:'}</span>
                  <span className="text-emerald-400 font-bold">100% Identical 1:1</span>
                </div>
                <div className="flex items-center justify-around py-2">
                  <div className="flex flex-col items-center gap-1">
                    <AppIcon
                      appName="WhatsApp"
                      packageName="com.whatsapp"
                      size={iconSize}
                      shape={iconShape}
                      badgeCount={5}
                      showBadge={showNotificationBadges}
                    />
                    <span className="text-[10px] text-zinc-300 font-medium">WhatsApp</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <AppIcon
                      appName="Instagram"
                      packageName="com.instagram.android"
                      size={iconSize}
                      shape={iconShape}
                      badgeCount={2}
                      showBadge={showNotificationBadges}
                    />
                    <span className="text-[10px] text-zinc-300 font-medium">Instagram</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <AppIcon
                      appName="YouTube"
                      packageName="com.google.android.youtube"
                      size={iconSize}
                      shape={iconShape}
                      showBadge={false}
                    />
                    <span className="text-[10px] text-zinc-300 font-medium">YouTube</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <AppIcon
                      appName="Google Pay"
                      packageName="com.google.android.apps.nbu.paisa.user"
                      size={iconSize}
                      shape={iconShape}
                      showBadge={false}
                    />
                    <span className="text-[10px] text-zinc-300 font-medium">GPay</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 4. Status Bar Fine Tuning (Carrier, Battery) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/80">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-cyan-400" />
                  {language === 'hi' ? 'सिम / नेटवर्क नाम (Carrier):' : 'SIM / Network Carrier Name:'}
                </label>
                <div className="flex gap-1.5">
                  {['Jio 5G', 'Airtel 5G', 'Vi 5G', 'Vodafone'].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCarrier(c)}
                      className={`px-2 py-1 text-[11px] font-medium rounded-lg border ${
                        carrier === c ? 'bg-cyan-950 border-cyan-500 text-cyan-300' : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-300 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    {language === 'hi' ? 'बैटरी प्रतिशत (%):' : 'Battery Level (%):'}
                  </span>
                  <span className="text-xs font-bold text-amber-400">{battery}%</span>
                </label>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={battery}
                  onChange={(e) => setBattery(Number(e.target.value))}
                  className="w-full accent-amber-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* 4. 100% Security & Secret Triggers Summary */}
            <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-500/30 space-y-2">
              <div className="flex items-center gap-2 text-purple-300 font-bold text-xs">
                <ShieldCheck className="w-4 h-4 text-purple-400" />
                <span>{language === 'hi' ? '100% सुरक्षा व सीक्रेट रास्ते (Secret Access Routes):' : '100% Stealth & Master Access Routes:'}</span>
              </div>
              <ul className="text-xs text-zinc-300 space-y-1 pl-4 list-disc marker:text-purple-400">
                <li>
                  <strong className="text-white">छिपी ऐप्स 100% गायब:</strong> WhatsApp, Instagram, गैलरी, बैंक ऐप्स होम स्क्रीन और ऐप ड्रॉअर में 0.0001% भी नहीं दिखेंगी।
                </li>
                <li>
                  <strong className="text-white">कैलकुलेटर ऐप:</strong> स्क्रीन पर मौजूद कैलकुलेटर खोलने पर सामान्य कैलकुलेटर दिखेगा। पिन + = दबाने पर वॉल्ट खुलेगा।
                </li>
                <li>
                  <strong className="text-white">फ़ोन डायलर कोड:</strong> डायलर खोलकर <code className="bg-purple-900/60 px-1 py-0.5 rounded text-amber-300">*#{securitySettings.pin}#</code> डायल करके कॉल दबाने पर तुरंत वॉल्ट अनलॉक होगा!
                </li>
                <li>
                  <strong className="text-white">स्टेटस बार क्लॉक:</strong> ऊपर बाएं कोने में समय (Clock) पर लगातार 3 बार टैप करने से भी मास्टर सीक्रेट अनलॉक खुल जाएगा।
                </li>
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={handleApplyLauncher}
                className="flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm shadow-xl shadow-purple-600/30 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <Maximize2 className="w-4 h-4" />
                <span>
                  {language === 'hi' ? '🚀 1:1 स्टील्थ क्लोन लॉन्चर लागू करें (Full Screen)' : '🚀 Apply 1:1 Stealth Clone Launcher'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setIsScannerModalOpen(false)}
                className="py-3 px-5 rounded-2xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white text-xs font-semibold border border-zinc-800 transition-colors"
              >
                {language === 'hi' ? 'रद्द करें' : 'Cancel'}
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
