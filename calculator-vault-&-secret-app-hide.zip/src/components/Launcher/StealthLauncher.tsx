import React, { useState, useEffect, useRef } from 'react';
import { useVault } from '../../context/VaultContext';
import { AppItem } from '../../types';
import { WALLPAPER_PRESETS } from '../../data/initialData';
import { soundManager } from '../../utils/sound';
import { AppIcon } from './AppIcon';
import {
  Wifi,
  Signal,
  Battery,
  BatteryCharging,
  Search,
  Mic,
  Camera as CameraIcon,
  Phone,
  MessageSquare,
  Compass,
  Settings as SettingsIcon,
  CloudSun,
  Maximize2,
  Minimize2,
  Scan,
  Shield,
  ChevronUp,
  X,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Bluetooth,
  Flame,
  Radio,
  Lock,
  Calculator as CalcIcon,
  Coins,
  FileSpreadsheet,
  QrCode,
  Smartphone,
  Delete,
  Send,
  AlertTriangle,
  RotateCcw,
  Check,
  ChevronDown,
  Sliders,
  Bell
} from 'lucide-react';

export const StealthLauncher: React.FC = () => {
  const {
    apps,
    launcherConfig,
    updateLauncherConfig,
    setAppViewMode,
    securitySettings,
    unlockVault,
    setIsScannerModalOpen,
    language,
    toggleFullscreen,
    toggleAppHide,
    toggleAppLock
  } = useVault();

  // Clock & Date state
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');
  const [clockTapCount, setClockTapCount] = useState<number>(0);
  const [showClockSecretModal, setShowClockSecretModal] = useState<boolean>(false);
  const [secretPinInput, setSecretPinInput] = useState<string>('');

  // Drawer states
  const [isAppDrawerOpen, setIsAppDrawerOpen] = useState<boolean>(false);
  const [isNotificationShadeOpen, setIsNotificationShadeOpen] = useState<boolean>(false);
  const [drawerSearch, setDrawerSearch] = useState<string>('');

  // Control Center toggles
  const [isWifiOn, setIsWifiOn] = useState<boolean>(true);
  const [isBluetoothOn, setIsBluetoothOn] = useState<boolean>(true);
  const [isTorchOn, setIsTorchOn] = useState<boolean>(false);
  const [isDataOn, setIsDataOn] = useState<boolean>(true);
  const [isSilentOn, setIsSilentOn] = useState<boolean>(false);
  const [screenBrightness, setScreenBrightness] = useState<number>(85);

  // Dynamic Island expand
  const [isIslandExpanded, setIsIslandExpanded] = useState<boolean>(false);

  // Active Simulated App
  const [activeSimApp, setActiveSimApp] = useState<{
    type: 'phone' | 'messages' | 'camera' | 'browser' | 'settings' | 'calc_disguise' | 'fake_crash' | 'app_locked';
    app?: AppItem;
  } | null>(null);

  // Phone Dialer state
  const [dialerNumber, setDialerNumber] = useState<string>('');

  // Flash effect for camera
  const [cameraFlash, setCameraFlash] = useState<boolean>(false);

  // Top stealth bar visible
  const [showStealthControls, setShowStealthControls] = useState<boolean>(false);

  // Update clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);

      const daysHi = ['रवि', 'सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि'];
      const monthsHi = ['जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];
      const daysEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

      if (language === 'hi') {
        setCurrentDate(`${daysHi[now.getDay()]}, ${now.getDate()} ${monthsHi[now.getMonth()]}`);
      } else {
        setCurrentDate(`${daysEn[now.getDay()]}, ${monthsEn[now.getMonth()]} ${now.getDate()}`);
      }
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [language]);

  // Current wallpaper URL
  const currentWallpaper =
    launcherConfig.wallpaperPreset === 'custom' && launcherConfig.customWallpaperUrl
      ? launcherConfig.customWallpaperUrl
      : WALLPAPER_PRESETS.find((w) => w.id === launcherConfig.wallpaperPreset)?.url ||
        WALLPAPER_PRESETS[0].url;

  // Visible apps (hidden apps are 100% removed!)
  const visibleApps = apps.filter((a) => !a.isHidden);
  const hiddenApps = apps.filter((a) => a.isHidden);

  // Disguise config for the Calculator app
  const getDisguiseConfig = () => {
    switch (securitySettings.disguiseIcon) {
      case 'weather':
        return { name: 'Weather', icon: CloudSun, bg: 'bg-sky-500', color: 'text-white' };
      case 'converter':
        return { name: 'Currency', icon: Coins, bg: 'bg-emerald-600', color: 'text-white' };
      case 'notes':
        return { name: 'Notes', icon: FileSpreadsheet, bg: 'bg-amber-500', color: 'text-white' };
      case 'scanner':
        return { name: 'Scanner', icon: QrCode, bg: 'bg-indigo-600', color: 'text-white' };
      default:
        return { name: 'Calculator', icon: CalcIcon, bg: 'bg-zinc-800', color: 'text-orange-400' };
    }
  };

  const disguise = getDisguiseConfig();
  const DisguiseIcon = disguise.icon;

  // Handle triple tap on clock
  const handleClockTap = () => {
    soundManager.playClick();
    const nextCount = clockTapCount + 1;
    setClockTapCount(nextCount);

    if (nextCount >= 3) {
      setClockTapCount(0);
      setShowClockSecretModal(true);
      soundManager.playUnlockChime();
    }

    // Reset counter if not tapped within 1.5s
    setTimeout(() => {
      setClockTapCount(0);
    }, 1500);
  };

  // Secret PIN Submit from Clock Modal
  const handleSecretPinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (unlockVault(secretPinInput)) {
      setShowClockSecretModal(false);
      setAppViewMode('vault');
    } else {
      alert(language === 'hi' ? 'गलत सीक्रेट पिन!' : 'Incorrect Secret PIN!');
      setSecretPinInput('');
    }
  };

  // Handle app clicking on the launcher
  const handleAppClick = (app: AppItem) => {
    soundManager.playClick();

    // If app is locked and fake crash is enabled
    if (app.isLocked) {
      if (securitySettings.enableFakeCrash) {
        setActiveSimApp({ type: 'fake_crash', app });
        return;
      }
      setActiveSimApp({ type: 'app_locked', app });
      return;
    }

    // Otherwise launch simulated app interface
    if (app.packageName.includes('chrome') || app.name.toLowerCase().includes('browser')) {
      setActiveSimApp({ type: 'browser', app });
    } else if (app.packageName.includes('camera') || app.name.toLowerCase().includes('camera')) {
      setActiveSimApp({ type: 'camera', app });
    } else if (app.packageName.includes('settings') || app.name.toLowerCase().includes('settings')) {
      setActiveSimApp({ type: 'settings', app });
    } else if (app.packageName.includes('whatsapp') || app.packageName.includes('telegram') || app.packageName.includes('snapchat')) {
      setActiveSimApp({ type: 'messages', app });
    } else {
      setActiveSimApp({ type: 'browser', app });
    }
  };

  // Handle Phone Dialer Input
  const handleDialerDigit = (digit: string) => {
    soundManager.playKeyTone();
    setDialerNumber((prev) => prev + digit);
  };

  const handleDialerCall = () => {
    soundManager.playClick();
    const clean = dialerNumber.trim();

    // Check secret dialer code (e.g. *#4582# or *#PIN#)
    if (
      clean === launcherConfig.secretDialCode ||
      clean === `*#${securitySettings.pin}#` ||
      clean === `*#${securitySettings.pin}` ||
      clean === `#*${securitySettings.pin}#` ||
      clean === `${securitySettings.pin}=`
    ) {
      soundManager.playUnlockChime();
      unlockVault(securitySettings.pin);
      setActiveSimApp(null);
      setAppViewMode('vault');
      return;
    }

    // Normal simulated call
    alert(language === 'hi' ? `कॉल किया जा रहा है: ${clean}...` : `Dialing: ${clean}...`);
  };

  // Camera Shutter Click
  const handleCameraCapture = () => {
    setCameraFlash(true);
    soundManager.playCameraShutter();
    setTimeout(() => setCameraFlash(false), 200);
  };

  // Filtered Apps in Drawer
  const filteredDrawerApps = visibleApps.filter((a) =>
    a.name.toLowerCase().includes(drawerSearch.toLowerCase())
  );

  return (
    <div
      id="stealth-launcher-root"
      className="relative w-full min-h-screen bg-black text-white select-none overflow-hidden font-sans flex flex-col justify-between"
      style={{
        backgroundImage: `url(${currentWallpaper})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        filter: `brightness(${screenBrightness}%)`
      }}
    >
      {/* Screen Torch Simulation Overlay */}
      {isTorchOn && (
        <div className="fixed inset-0 bg-white/95 z-50 flex items-center justify-center pointer-events-auto">
          <div className="text-center text-zinc-900 space-y-4 p-6 bg-white rounded-3xl shadow-2xl">
            <Sun className="w-16 h-16 text-amber-500 mx-auto animate-spin" />
            <h3 className="font-bold text-xl">
              {language === 'hi' ? 'फ्लैशलाइट / टॉर्च चालू है' : 'Flashlight / Torch ON'}
            </h3>
            <button
              onClick={() => setIsTorchOn(false)}
              className="px-6 py-2.5 rounded-full bg-zinc-900 text-white font-bold text-sm shadow-lg"
            >
              {language === 'hi' ? 'बंद करें (Turn OFF)' : 'Turn OFF'}
            </button>
          </div>
        </div>
      )}

      {/* Discrete Stealth Overlay Controls Button */}
      <div className="absolute top-1 left-1/2 -translate-x-1/2 z-40">
        <button
          onClick={() => setShowStealthControls((prev) => !prev)}
          className="h-1.5 w-16 bg-white/20 hover:bg-white/60 rounded-full transition-all cursor-pointer"
          title="Stealth Quick Controls"
        />
      </div>

      {/* Discrete Stealth Bar Dropdown */}
      {showStealthControls && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-40 bg-black/90 backdrop-blur-2xl border border-white/20 rounded-2xl p-2.5 shadow-2xl flex items-center gap-2 animate-in fade-in">
          <button
            onClick={() => setAppViewMode('calculator')}
            className="px-2.5 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold flex items-center gap-1.5 text-zinc-200"
          >
            <CalcIcon className="w-3.5 h-3.5 text-orange-400" />
            <span>{language === 'hi' ? 'कैलकुलेटर' : 'Calculator'}</span>
          </button>
          <button
            onClick={() => setIsScannerModalOpen(true)}
            className="px-2.5 py-1.5 rounded-xl bg-purple-950 border border-purple-500/40 text-xs font-semibold flex items-center gap-1.5 text-purple-300"
          >
            <Scan className="w-3.5 h-3.5 text-purple-400" />
            <span>{language === 'hi' ? 'स्क्रीन स्कैनर' : 'Scan Screen'}</span>
          </button>
          <button
            onClick={toggleFullscreen}
            className="px-2.5 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold flex items-center gap-1.5 text-zinc-200"
          >
            <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>{language === 'hi' ? 'फुलस्क्रीन' : 'Fullscreen'}</span>
          </button>
          <button
            onClick={() => setShowStealthControls(false)}
            className="p-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 1. Ultra 1:1 System Status Bar */}
      <header
        id="system-status-bar"
        onClick={() => setIsNotificationShadeOpen(true)}
        className="w-full pt-1.5 px-6 pb-1 flex items-center justify-between text-white text-xs font-semibold z-30 cursor-pointer drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]"
      >
        {/* Left: Real-time clock & Secret Hotspot */}
        <div
          onClick={(e) => {
            e.stopPropagation();
            handleClockTap();
          }}
          className="flex items-center gap-2 cursor-pointer active:scale-95 transition-transform"
          title="Triple-tap for secret master unlock"
        >
          <span className="font-bold tracking-tight text-sm">{currentTime || '09:41'}</span>
          <span className="text-[10px] font-normal opacity-80">{launcherConfig.carrierName}</span>
        </div>

        {/* Center: Dynamic Island (iOS) / Punch Hole Camera (OneUI) */}
        {launcherConfig.osType === 'ios' ? (
          <div
            onClick={(e) => {
              e.stopPropagation();
              setIsIslandExpanded((prev) => !prev);
            }}
            className={`transition-all duration-300 bg-black text-white rounded-full flex items-center justify-between px-3 cursor-pointer shadow-lg border border-zinc-800/80 ${
              isIslandExpanded ? 'w-56 h-10 py-1' : 'w-24 h-6'
            }`}
          >
            {isIslandExpanded ? (
              <div className="flex items-center justify-between w-full text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  <span className="text-zinc-200">Spotify • Playing</span>
                </div>
                <div className="w-2.5 h-2.5 rounded-full bg-zinc-900 border border-zinc-700" />
              </div>
            ) : (
              <div className="w-full flex items-center justify-between">
                <div className="w-2 h-2 rounded-full bg-zinc-900 border border-zinc-800" />
                <div className="w-2 h-2 rounded-full bg-amber-500/80" />
              </div>
            )}
          </div>
        ) : (
          <div className="w-3.5 h-3.5 rounded-full bg-black border border-zinc-900 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-zinc-900" />
          </div>
        )}

        {/* Right: Network, 5G, Wi-Fi & Battery */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-[10px] font-bold tracking-tighter bg-white/20 px-1 rounded">5G</span>
          <Signal className="w-3.5 h-3.5 drop-shadow" />
          {isWifiOn && <Wifi className="w-3.5 h-3.5 drop-shadow" />}
          <div className="flex items-center gap-0.5">
            <span className="text-[11px] font-medium">{launcherConfig.batteryLevel}%</span>
            {launcherConfig.isCharging ? (
              <BatteryCharging className="w-4 h-4 text-emerald-400 fill-emerald-400/30" />
            ) : (
              <Battery className="w-4 h-4 fill-white/80" />
            )}
          </div>
        </div>
      </header>

      {/* 2. Main Home Screen Area with Widgets & Apps */}
      <main className="flex-1 flex flex-col justify-between px-4 sm:px-8 py-3 z-10 max-w-lg mx-auto w-full">
        
        {/* Top Widgets: Clock, Date & Weather */}
        <div className="space-y-4 pt-2">
          
          {/* Big System Clock Widget */}
          <div className="text-center drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
            <h1 className="text-5xl sm:text-6xl font-light tracking-tight text-white font-mono">
              {currentTime || '09:41'}
            </h1>
            <p className="text-sm font-medium text-zinc-200 mt-1">
              {currentDate || 'Tuesday, Sep 1'}
            </p>
          </div>

          {/* Dynamic Weather Widget */}
          {launcherConfig.showWeatherWidget && (
            <div className="p-3 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-between text-xs shadow-lg">
              <div className="flex items-center gap-2.5">
                <CloudSun className="w-7 h-7 text-amber-400" />
                <div>
                  <span className="font-bold text-white text-sm">31°C</span>
                  <span className="text-[11px] text-zinc-300 block">
                    {language === 'hi' ? 'धूप और साफ़ आसमान • नई दिल्ली' : 'Sunny & Clear • New Delhi'}
                  </span>
                </div>
              </div>
              <div className="text-right text-[11px] text-zinc-300">
                <span>AQI 68 • नमी 42%</span>
              </div>
            </div>
          )}

          {/* Google Search Bar Pill */}
          {launcherConfig.showGoogleSearch && (
            <div
              onClick={() => setActiveSimApp({ type: 'browser' })}
              className="p-2.5 px-4 rounded-full bg-white/90 backdrop-blur-lg text-zinc-800 shadow-xl flex items-center justify-between cursor-pointer hover:bg-white transition-all active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <span className="font-bold text-base bg-gradient-to-r from-blue-600 via-red-500 to-amber-500 bg-clip-text text-transparent">
                  G
                </span>
                <span className="text-xs text-zinc-500">
                  {language === 'hi' ? 'खोजें या URL टाइप करें...' : 'Search or type URL...'}
                </span>
              </div>
              <div className="flex items-center gap-2.5 text-zinc-600">
                <Mic className="w-4 h-4 text-blue-600" />
                <CameraIcon className="w-4 h-4 text-amber-600" />
              </div>
            </div>
          )}
        </div>

        {/* 3. Home Screen Apps Grid (Only Visible Apps - Hidden Apps 100% Vanished!) */}
        <div className="grid grid-cols-4 gap-y-5 gap-x-2 py-4 my-auto">
          
          {/* Disguised Calculator Vault App */}
          <div
            onClick={() => setAppViewMode('calculator')}
            className="flex flex-col items-center gap-1.5 cursor-pointer group"
          >
            <AppIcon
              appName={disguise.name}
              disguiseType={securitySettings.disguiseIcon}
              size={launcherConfig.iconSize}
              shape={launcherConfig.iconShape}
            />
            <span className="text-[11px] font-medium text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] truncate max-w-[68px] text-center">
              {disguise.name}
            </span>
          </div>

          {/* Normal Phone Apps */}
          {visibleApps.map((app) => {
            return (
              <div
                key={app.id}
                onClick={() => handleAppClick(app)}
                className="flex flex-col items-center gap-1.5 cursor-pointer group relative"
              >
                <AppIcon
                  appName={app.name}
                  packageName={app.packageName}
                  iconName={app.iconName}
                  size={launcherConfig.iconSize}
                  shape={launcherConfig.iconShape}
                  badgeCount={app.badgeCount}
                  showBadge={launcherConfig.showNotificationBadges}
                  customIconUrl={app.customIconUrl}
                />
                <span className="text-[11px] font-medium text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] truncate max-w-[68px] text-center">
                  {app.name}
                </span>
              </div>
            );
          })}
        </div>

        {/* 4. Bottom App Drawer Arrow & Gesture Indicator */}
        <div
          onClick={() => setIsAppDrawerOpen(true)}
          className="flex flex-col items-center justify-center gap-0.5 py-1 text-white/70 hover:text-white cursor-pointer transition-colors"
        >
          <ChevronUp className="w-4 h-4 animate-bounce" />
          <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-300">
            {language === 'hi' ? 'ऐप्स (App Drawer)' : 'Apps'}
          </span>
        </div>

        {/* 5. Bottom System Dock (Phone, Messages, Chrome, Camera) */}
        <div className="p-3 rounded-3xl bg-white/15 backdrop-blur-2xl border border-white/20 grid grid-cols-4 gap-2 shadow-2xl">
          
          {/* Phone / Dialer */}
          <div
            onClick={() => setActiveSimApp({ type: 'phone' })}
            className="flex flex-col items-center justify-center cursor-pointer group"
          >
            <AppIcon
              appName="Phone"
              packageName="com.android.dialer"
              iconName="Phone"
              size={launcherConfig.iconSize}
              shape={launcherConfig.iconShape}
              showBadge={false}
            />
          </div>

          {/* Messages */}
          <div
            onClick={() => setActiveSimApp({ type: 'messages' })}
            className="flex flex-col items-center justify-center cursor-pointer group"
          >
            <AppIcon
              appName="Messages"
              packageName="com.google.android.apps.messaging"
              iconName="MessageSquare"
              size={launcherConfig.iconSize}
              shape={launcherConfig.iconShape}
              badgeCount={3}
              showBadge={launcherConfig.showNotificationBadges}
            />
          </div>

          {/* Browser / Chrome */}
          <div
            onClick={() => setActiveSimApp({ type: 'browser' })}
            className="flex flex-col items-center justify-center cursor-pointer group"
          >
            <AppIcon
              appName="Chrome"
              packageName="com.android.chrome"
              iconName="Compass"
              size={launcherConfig.iconSize}
              shape={launcherConfig.iconShape}
              showBadge={false}
            />
          </div>

          {/* Camera */}
          <div
            onClick={() => setActiveSimApp({ type: 'camera' })}
            className="flex flex-col items-center justify-center cursor-pointer group"
          >
            <AppIcon
              appName="Camera"
              packageName="com.android.camera"
              iconName="Camera"
              size={launcherConfig.iconSize}
              shape={launcherConfig.iconShape}
              showBadge={false}
            />
          </div>

        </div>

      </main>

      {/* Bottom Home Bar Indicator */}
      <footer className="h-4 flex items-center justify-center z-20 pb-1">
        <div
          onClick={() => setIsAppDrawerOpen((prev) => !prev)}
          className="w-32 h-1 bg-white/70 hover:bg-white rounded-full cursor-pointer transition-all"
        />
      </footer>

      {/* ========================================================================= */}
      {/* FULL APP DRAWER MODAL (SWIPE UP) - 100% EXCLUDES HIDDEN VAULT APPS */}
      {/* ========================================================================= */}
      {isAppDrawerOpen && (
        <div
          id="app-drawer-overlay"
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-3xl flex flex-col justify-between p-4 sm:p-6 animate-in slide-in-from-bottom duration-300"
        >
          {/* Drawer Top Header & Search */}
          <div className="space-y-3 max-w-lg mx-auto w-full">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest">
                {language === 'hi' ? 'सभी ऐप्स (App Drawer)' : 'All Applications'}
              </span>
              <button
                onClick={() => setIsAppDrawerOpen(false)}
                className="p-1.5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={language === 'hi' ? 'ऐप खोजें...' : 'Search apps...'}
                value={drawerSearch}
                onChange={(e) => setDrawerSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 text-xs focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Drawer Apps Grid */}
          <div className="flex-1 overflow-y-auto py-6 max-w-lg mx-auto w-full">
            <div className="grid grid-cols-4 gap-y-6 gap-x-3">
              
              {/* Disguised Calculator */}
              <div
                onClick={() => {
                  setIsAppDrawerOpen(false);
                  setAppViewMode('calculator');
                }}
                className="flex flex-col items-center gap-1.5 cursor-pointer group"
              >
                <AppIcon
                  appName={disguise.name}
                  disguiseType={securitySettings.disguiseIcon}
                  size={launcherConfig.iconSize}
                  shape={launcherConfig.iconShape}
                />
                <span className="text-[11px] font-medium text-zinc-200 truncate max-w-[68px] text-center">
                  {disguise.name}
                </span>
              </div>

              {/* All visible apps */}
              {filteredDrawerApps.map((app) => (
                <div
                  key={app.id}
                  onClick={() => {
                    setIsAppDrawerOpen(false);
                    handleAppClick(app);
                  }}
                  className="flex flex-col items-center gap-1.5 cursor-pointer group"
                >
                  <AppIcon
                    appName={app.name}
                    packageName={app.packageName}
                    iconName={app.iconName}
                    size={launcherConfig.iconSize}
                    shape={launcherConfig.iconShape}
                    badgeCount={app.badgeCount}
                    showBadge={launcherConfig.showNotificationBadges}
                    customIconUrl={app.customIconUrl}
                  />
                  <span className="text-[11px] font-medium text-zinc-200 truncate max-w-[68px] text-center">
                    {app.name}
                  </span>
                </div>
              ))}
            </div>

            {filteredDrawerApps.length === 0 && (
              <div className="text-center py-12 text-zinc-500 text-xs">
                {language === 'hi' ? 'कोई ऐप नहीं मिला' : 'No apps found'}
              </div>
            )}
          </div>

          {/* Drawer Bottom Close Gesture */}
          <div className="text-center">
            <button
              onClick={() => setIsAppDrawerOpen(false)}
              className="py-2 px-6 rounded-full bg-zinc-900 hover:bg-zinc-800 text-xs text-zinc-400 font-semibold border border-zinc-800 inline-flex items-center gap-1.5"
            >
              <ChevronDown className="w-4 h-4" />
              <span>{language === 'hi' ? 'बंद करें' : 'Close Drawer'}</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* QUICK SETTINGS & NOTIFICATION SHADE (SWIPE DOWN) */}
      {/* ========================================================================= */}
      {isNotificationShadeOpen && (
        <div
          id="notification-shade-overlay"
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-3xl flex flex-col p-4 sm:p-6 animate-in slide-in-from-top duration-300"
        >
          <div className="max-w-lg mx-auto w-full space-y-5">
            
            {/* Header with Time & Battery */}
            <div className="flex items-center justify-between text-white border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold font-mono">{currentTime}</span>
                <span className="text-xs text-zinc-400">{currentDate}</span>
              </div>
              <button
                onClick={() => setIsNotificationShadeOpen(false)}
                className="p-1.5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Toggle Tiles */}
            <div className="grid grid-cols-4 gap-3">
              
              {/* Wi-Fi Toggle */}
              <button
                onClick={() => setIsWifiOn((prev) => !prev)}
                className={`p-3 rounded-2xl flex flex-col items-center gap-1.5 transition-all ${
                  isWifiOn ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                }`}
              >
                <Wifi className="w-5 h-5" />
                <span className="text-[10px] font-bold">Wi-Fi</span>
              </button>

              {/* Bluetooth Toggle */}
              <button
                onClick={() => setIsBluetoothOn((prev) => !prev)}
                className={`p-3 rounded-2xl flex flex-col items-center gap-1.5 transition-all ${
                  isBluetoothOn ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                }`}
              >
                <Bluetooth className="w-5 h-5" />
                <span className="text-[10px] font-bold">Bluetooth</span>
              </button>

              {/* Torch / Flashlight */}
              <button
                onClick={() => setIsTorchOn((prev) => !prev)}
                className={`p-3 rounded-2xl flex flex-col items-center gap-1.5 transition-all ${
                  isTorchOn ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/30' : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                }`}
              >
                <Sun className="w-5 h-5" />
                <span className="text-[10px] font-bold">Torch</span>
              </button>

              {/* Mobile Data 5G */}
              <button
                onClick={() => setIsDataOn((prev) => !prev)}
                className={`p-3 rounded-2xl flex flex-col items-center gap-1.5 transition-all ${
                  isDataOn ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/30' : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                }`}
              >
                <Radio className="w-5 h-5" />
                <span className="text-[10px] font-bold">5G Data</span>
              </button>

            </div>

            {/* Brightness Slider */}
            <div className="p-3.5 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center gap-3">
              <Sun className="w-4 h-4 text-zinc-400" />
              <input
                type="range"
                min="20"
                max="100"
                value={screenBrightness}
                onChange={(e) => setScreenBrightness(Number(e.target.value))}
                className="flex-1 accent-white h-2 bg-zinc-800 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono text-zinc-300 w-8 text-right">{screenBrightness}%</span>
            </div>

            {/* Quick Icon Calibration Bar (1:1 Phone Fidelity) */}
            <div className="p-3.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-zinc-300 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-purple-400" />
                  {language === 'hi' ? 'ऐप आइकॉन साइज व शेप (1:1 मैच):' : 'App Icon Size & Shape (1:1 Match):'}
                </span>
                <button
                  onClick={() =>
                    updateLauncherConfig({
                      showNotificationBadges: !launcherConfig.showNotificationBadges
                    })
                  }
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                    launcherConfig.showNotificationBadges
                      ? 'bg-red-500/20 text-red-300 border-red-500/40'
                      : 'bg-zinc-800 text-zinc-500 border-zinc-700'
                  }`}
                >
                  <Bell className="w-2.5 h-2.5 inline mr-1" />
                  {launcherConfig.showNotificationBadges ? 'Badges ON' : 'Badges OFF'}
                </button>
              </div>

              {/* Icon Size Selector */}
              <div className="grid grid-cols-3 gap-2">
                {(['compact', 'normal', 'large'] as const).map((sz) => {
                  const isSelected = launcherConfig.iconSize === sz;
                  const labelMap = {
                    compact: language === 'hi' ? 'छोटा (Compact)' : 'Compact',
                    normal: language === 'hi' ? 'सामान्य 1:1 (Normal)' : 'Normal (1:1)',
                    large: language === 'hi' ? 'बड़ा (Large)' : 'Large'
                  };
                  return (
                    <button
                      key={sz}
                      onClick={() => updateLauncherConfig({ iconSize: sz })}
                      className={`py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all ${
                        isSelected
                          ? 'bg-purple-600 text-white border-purple-500 shadow-md'
                          : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
                      }`}
                    >
                      {labelMap[sz]}
                    </button>
                  );
                })}
              </div>

              {/* Icon Shape Selector */}
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {(['squircle', 'rounded', 'circle', 'teardrop'] as const).map((sh) => {
                  const isSelected = launcherConfig.iconShape === sh;
                  return (
                    <button
                      key={sh}
                      onClick={() => updateLauncherConfig({ iconShape: sh })}
                      className={`py-1 px-1.5 rounded-lg text-[10px] capitalize font-medium border text-center transition-all ${
                        isSelected
                          ? 'bg-cyan-950 text-cyan-300 border-cyan-500'
                          : 'bg-zinc-950 text-zinc-500 border-zinc-800 hover:text-zinc-300'
                      }`}
                    >
                      {sh}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Notifications List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span className="font-bold uppercase tracking-wider">
                  {language === 'hi' ? 'हाल की सूचनाएं (Notifications)' : 'Recent Notifications'}
                </span>
                <span className="text-[10px] text-zinc-500">
                  {language === 'hi' ? 'सभी हटाएं' : 'Clear all'}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-emerald-400" />
                    Google Play Protect
                  </span>
                  <span className="text-[10px] text-zinc-500">10m ago</span>
                </div>
                <p className="text-xs text-zinc-400">
                  {language === 'hi' ? 'सिस्टम सुरक्षित है। कोई हानिकारक ऐप नहीं मिला।' : 'All apps scanned. Device is protected.'}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-cyan-400" />
                    {launcherConfig.carrierName}
                  </span>
                  <span className="text-[10px] text-zinc-500">1h ago</span>
                </div>
                <p className="text-xs text-zinc-400">
                  {language === 'hi' ? '5G True Unlimited Data सक्रिय है।' : '5G Unlimited High-Speed Data is active.'}
                </p>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECRET MASTER CLOCK MODAL (OPENED BY 3-TAPS ON TIME) */}
      {/* ========================================================================= */}
      {showClockSecretModal && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-zinc-950 border border-purple-500/40 rounded-3xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-950 border border-purple-500/40 text-purple-400 flex items-center justify-center mx-auto shadow-lg shadow-purple-500/20">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">
                {language === 'hi' ? 'सीक्रेट मास्टर वॉल्ट अनलॉक' : 'Secret Master Vault Unlock'}
              </h3>
              <p className="text-xs text-zinc-400 mt-1">
                {language === 'hi' ? 'वॉल्ट खोलने के लिए अपना गुप्त पिन दर्ज करें:' : 'Enter your secret PIN to access the vault:'}
              </p>
            </div>

            <form onSubmit={handleSecretPinSubmit} className="space-y-4">
              <input
                type="password"
                maxLength={8}
                placeholder="PIN"
                value={secretPinInput}
                onChange={(e) => setSecretPinInput(e.target.value)}
                autoFocus
                className="w-full py-3 text-center text-2xl font-mono tracking-widest rounded-2xl bg-zinc-900 border border-zinc-800 text-white focus:outline-none focus:border-purple-500"
              />

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-colors"
                >
                  {language === 'hi' ? 'अनलॉक करें' : 'Unlock'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowClockSecretModal(false)}
                  className="py-3 px-4 rounded-2xl bg-zinc-900 text-zinc-400 hover:text-white text-xs font-semibold"
                >
                  {language === 'hi' ? 'रद्द करें' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SIMULATED APPS (PHONE DIALER, MESSAGES, CAMERA, BROWSER, FAKE CRASH) */}
      {/* ========================================================================= */}

      {/* 1. Phone Dialer App (Secret Code Unlocks Vault!) */}
      {activeSimApp?.type === 'phone' && (
        <div className="fixed inset-0 z-50 bg-zinc-950 text-white flex flex-col justify-between p-4 sm:p-6 animate-in slide-in-from-bottom">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <span className="font-bold text-sm text-zinc-300">
              {language === 'hi' ? 'फ़ोन / डायलर (Phone)' : 'Phone Dialer'}
            </span>
            <button
              onClick={() => setActiveSimApp(null)}
              className="p-1.5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Number Display */}
          <div className="py-6 text-center">
            <input
              type="text"
              readOnly
              value={dialerNumber}
              placeholder={language === 'hi' ? 'फ़ोन नंबर दर्ज करें...' : 'Enter phone number...'}
              className="w-full text-center text-3xl font-mono font-bold tracking-wider bg-transparent text-white focus:outline-none"
            />
            <p className="text-[11px] text-zinc-600 mt-2">
              {language === 'hi' ? 'कॉल करने के लिए कीपैड का उपयोग करें' : 'Use keypad to dial'}
            </p>
          </div>

          {/* Keypad Grid */}
          <div className="max-w-xs mx-auto w-full space-y-3">
            <div className="grid grid-cols-3 gap-3">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((d) => (
                <button
                  key={d}
                  onClick={() => handleDialerDigit(d)}
                  className="h-16 rounded-full bg-zinc-900 hover:bg-zinc-800 active:scale-95 text-2xl font-semibold text-zinc-200 border border-zinc-800 shadow-md transition-transform flex items-center justify-center"
                >
                  {d}
                </button>
              ))}
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between px-6 pt-2">
              <div className="w-12" />
              <button
                onClick={handleDialerCall}
                className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-xl shadow-emerald-500/30 active:scale-90 transition-transform"
              >
                <Phone className="w-7 h-7 fill-current" />
              </button>
              <button
                onClick={() => setDialerNumber((prev) => prev.slice(0, -1))}
                className="w-12 h-12 rounded-full text-zinc-400 hover:text-white flex items-center justify-center"
              >
                <Delete className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="text-center py-2">
            <button
              onClick={() => setActiveSimApp(null)}
              className="text-xs text-zinc-500 hover:text-zinc-300"
            >
              {language === 'hi' ? 'होम स्क्रीन पर लौटें' : 'Return to Home Screen'}
            </button>
          </div>
        </div>
      )}

      {/* 2. Messages App Simulation */}
      {activeSimApp?.type === 'messages' && (
        <div className="fixed inset-0 z-50 bg-zinc-950 text-white flex flex-col justify-between p-4 animate-in slide-in-from-bottom">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <span className="font-bold text-sm text-zinc-300">
              {activeSimApp.app?.name || 'Messages'}
            </span>
            <button
              onClick={() => setActiveSimApp(null)}
              className="p-1.5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-4 space-y-3 max-w-lg mx-auto w-full">
            <div className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-emerald-400">Jio Support</span>
                <span className="text-[10px] text-zinc-500">12:30 PM</span>
              </div>
              <p className="text-xs text-zinc-300">
                Your high-speed daily quota has been renewed successfully.
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-blue-400">Bank OTP Service</span>
                <span className="text-[10px] text-zinc-500">Yesterday</span>
              </div>
              <p className="text-xs text-zinc-300">
                849201 is your one-time verification password for login. Do not share with anyone.
              </p>
            </div>
          </div>

          <div className="p-2 border-t border-zinc-800 flex items-center gap-2 max-w-lg mx-auto w-full">
            <input
              type="text"
              placeholder={language === 'hi' ? 'मैसेज लिखें...' : 'Type a message...'}
              className="flex-1 py-2.5 px-4 rounded-full bg-zinc-900 border border-zinc-800 text-xs text-white focus:outline-none"
            />
            <button className="p-2.5 rounded-full bg-blue-600 text-white">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* 3. Camera App Simulation */}
      {activeSimApp?.type === 'camera' && (
        <div className="fixed inset-0 z-50 bg-black text-white flex flex-col justify-between p-4 animate-in fade-in">
          {cameraFlash && <div className="fixed inset-0 bg-white z-50" />}
          
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold">0.5x • 1x • 2x • 3x</span>
            <button
              onClick={() => setActiveSimApp(null)}
              className="p-2 rounded-full bg-black/60 text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Viewfinder simulation */}
          <div className="flex-1 my-4 rounded-3xl border border-white/20 relative overflow-hidden bg-zinc-900 flex items-center justify-center">
            <div className="w-48 h-48 border border-white/30 rounded-2xl flex items-center justify-center">
              <span className="text-xs text-white/50">4K 60FPS</span>
            </div>
          </div>

          {/* Shutter Controls */}
          <div className="flex items-center justify-between px-8 py-4">
            <div className="w-10 h-10 rounded-xl bg-zinc-800 border border-zinc-700" />
            <button
              onClick={handleCameraCapture}
              className="w-18 h-18 rounded-full border-4 border-white p-1 flex items-center justify-center active:scale-95 transition-transform"
            >
              <div className="w-full h-full rounded-full bg-white" />
            </button>
            <RotateCcw className="w-6 h-6 text-zinc-400 cursor-pointer" />
          </div>
        </div>
      )}

      {/* 4. Web Browser Simulation */}
      {activeSimApp?.type === 'browser' && (
        <div className="fixed inset-0 z-50 bg-zinc-950 text-white flex flex-col justify-between p-4 animate-in slide-in-from-bottom">
          <div className="flex items-center gap-2 border-b border-zinc-800 pb-3">
            <div className="flex-1 py-2 px-4 rounded-full bg-zinc-900 border border-zinc-800 flex items-center gap-2 text-xs text-zinc-300">
              <Lock className="w-3 h-3 text-emerald-400" />
              <span>https://www.google.com</span>
            </div>
            <button
              onClick={() => setActiveSimApp(null)}
              className="p-2 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 max-w-sm mx-auto">
            <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-500 via-red-500 to-amber-500 bg-clip-text text-transparent">
              Google
            </h2>
            <div className="w-full relative">
              <input
                type="text"
                placeholder={language === 'hi' ? 'वेब पर खोजें...' : 'Search Google or type a URL'}
                className="w-full py-3 px-5 rounded-full bg-zinc-900 border border-zinc-700 text-sm text-white focus:outline-none"
              />
            </div>
            <div className="flex gap-2 text-xs text-zinc-400">
              <span className="p-2 rounded-xl bg-zinc-900">Wikipedia</span>
              <span className="p-2 rounded-xl bg-zinc-900">News</span>
              <span className="p-2 rounded-xl bg-zinc-900">Weather</span>
            </div>
          </div>
        </div>
      )}

      {/* 5. Fake Crash Dialog for Locked App (Ultra Stealth) */}
      {activeSimApp?.type === 'fake_crash' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-zinc-900 border border-zinc-800 rounded-3xl p-5 shadow-2xl text-left space-y-3 animate-in zoom-in-95">
            <div className="flex items-center gap-2.5 text-rose-400 font-bold text-sm">
              <AlertTriangle className="w-5 h-5" />
              <span>
                {language === 'hi' ? 'ऐप बंद हो गया है' : 'Application Error'}
              </span>
            </div>
            <p className="text-xs text-zinc-300">
              {language === 'hi'
                ? `दुर्भाग्यवश, ${activeSimApp.app?.name || 'App'} ने काम करना बंद कर दिया है।`
                : `Unfortunately, ${activeSimApp.app?.name || 'App'} has stopped responding.`}
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveSimApp(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-300"
              >
                {language === 'hi' ? 'रिपोर्ट करें' : 'Report'}
              </button>
              <button
                onClick={() => setActiveSimApp(null)}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-bold text-white"
              >
                {language === 'hi' ? 'ठीक है (OK)' : 'OK'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Locked App PIN Entry Screen */}
      {activeSimApp?.type === 'app_locked' && (
        <div className="fixed inset-0 z-50 bg-zinc-950 text-white flex flex-col items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-xs bg-zinc-900 border border-zinc-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-zinc-800 flex items-center justify-center mx-auto text-amber-400">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                {activeSimApp.app?.name || 'App'} Locked
              </h3>
              <p className="text-xs text-zinc-400 mt-1">
                {language === 'hi' ? 'अनलॉक करने के लिए पिन दर्ज करें' : 'Enter PIN to unlock app'}
              </p>
            </div>

            <input
              type="password"
              maxLength={6}
              placeholder="PIN"
              onChange={(e) => {
                if (e.target.value === securitySettings.appLockPin || e.target.value === securitySettings.pin) {
                  soundManager.playUnlockChime();
                  setActiveSimApp({ type: 'browser', app: activeSimApp.app });
                }
              }}
              autoFocus
              className="w-full py-2.5 text-center text-xl font-mono rounded-2xl bg-zinc-950 border border-zinc-800 text-white focus:outline-none focus:border-purple-500"
            />

            <button
              onClick={() => setActiveSimApp(null)}
              className="text-xs text-zinc-500 hover:text-zinc-300"
            >
              {language === 'hi' ? 'रद्द करें' : 'Cancel'}
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
