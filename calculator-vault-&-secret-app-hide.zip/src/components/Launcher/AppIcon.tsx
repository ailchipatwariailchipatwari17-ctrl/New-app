import React from 'react';
import { IconShape } from '../../types';
import {
  CloudSun,
  Coins,
  FileSpreadsheet,
  QrCode,
  Lock,
  EyeOff
} from 'lucide-react';

interface AppIconProps {
  appName: string;
  packageName?: string;
  iconName?: string;
  size?: 'compact' | 'normal' | 'large' | number; // 'compact' = 48px, 'normal' = 58px, 'large' = 66px
  shape?: IconShape; // 'squircle' | 'rounded' | 'circle' | 'teardrop'
  badgeCount?: number;
  showBadge?: boolean;
  isLocked?: boolean;
  isHidden?: boolean;
  showIndicators?: boolean;
  className?: string;
  customIconUrl?: string;
  disguiseType?: 'calculator' | 'weather' | 'converter' | 'notes' | 'scanner';
}

export const AppIcon: React.FC<AppIconProps> = ({
  appName,
  packageName = '',
  iconName = '',
  size = 'normal',
  shape = 'squircle',
  badgeCount,
  showBadge = true,
  isLocked = false,
  isHidden = false,
  showIndicators = false,
  className = '',
  customIconUrl,
  disguiseType
}) => {
  // Determine pixel size
  let pixelSize = 58;
  if (typeof size === 'number') {
    pixelSize = size;
  } else if (size === 'compact') {
    pixelSize = 48;
  } else if (size === 'large') {
    pixelSize = 66;
  }

  // Determine border-radius shape
  const getShapeClass = () => {
    switch (shape) {
      case 'circle':
        return 'rounded-full';
      case 'rounded':
        return 'rounded-xl';
      case 'teardrop':
        return 'rounded-2xl rounded-tr-none';
      case 'squircle':
      default:
        return 'rounded-[22%]'; // Authentic iOS & OneUI squircle curvature
    }
  };

  const normName = (appName || '').toLowerCase();
  const pkg = (packageName || '').toLowerCase();

  // If custom uploaded icon is provided
  if (customIconUrl) {
    return (
      <div
        className={`relative flex items-center justify-center select-none shadow-md overflow-hidden ${getShapeClass()} ${className}`}
        style={{ width: `${pixelSize}px`, height: `${pixelSize}px` }}
      >
        <img
          src={customIconUrl}
          alt={appName}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        {renderBadgesAndIndicators()}
      </div>
    );
  }

  // Disguise Icon for Calculator Vault
  if (disguiseType) {
    return (
      <div
        className={`relative flex items-center justify-center select-none shadow-md overflow-hidden ${getShapeClass()} ${className}`}
        style={{ width: `${pixelSize}px`, height: `${pixelSize}px` }}
      >
        {renderDisguiseIcon(disguiseType, pixelSize)}
        {renderBadgesAndIndicators()}
      </div>
    );
  }

  // 1:1 Authentic Official App Logo Renderer
  const renderOfficialLogo = () => {
    // 1. WhatsApp
    if (normName.includes('whatsapp') || pkg.includes('whatsapp')) {
      return (
        <div className="w-full h-full bg-[#25D366] flex items-center justify-center shadow-inner relative overflow-hidden">
          {/* Subtle gradient sheen */}
          <div className="absolute inset-0 bg-gradient-to-b from-white/15 to-transparent pointer-events-none" />
          <svg className="w-[62%] h-[62%] fill-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.2)]" viewBox="0 0 24 24">
            <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm.01 1.67c4.54 0 8.24 3.7 8.24 8.24 0 2.2-.86 4.28-2.42 5.83a8.18 8.18 0 01-5.83 2.41c-1.46 0-2.88-.39-4.14-1.13l-.3-.18-3.08.81.82-3-.19-.31a8.17 8.17 0 01-1.25-4.43c0-4.54 3.7-8.24 8.24-8.24zm4.52 11.64c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.13-1.06-.39-2.02-1.25-.75-.67-1.26-1.5-1.4-1.75-.15-.25-.02-.39.11-.51.11-.11.25-.29.37-.44.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.44-.06-.13-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.43h-.48c-.17 0-.44.06-.67.31-.23.25-.88.86-.88 2.1s.9 2.44 1.02 2.61c.13.17 1.77 2.7 4.29 3.79.6.26 1.07.41 1.44.53.6.19 1.15.16 1.58.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.15-1.18-.07-.1-.23-.16-.48-.28z" />
          </svg>
        </div>
      );
    }

    // 2. Instagram
    if (normName.includes('instagram') || pkg.includes('instagram')) {
      return (
        <div className="w-full h-full bg-gradient-to-tr from-[#f09433] via-[#e6683c] via-[#dc2743] via-[#cc2366] to-[#bc1888] flex items-center justify-center shadow-inner relative overflow-hidden">
          <div className="absolute inset-0 bg-radial from-transparent to-black/10 pointer-events-none" />
          <svg className="w-[64%] h-[64%] text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="2" width="20" height="20" rx="5.5" ry="5.5" />
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" strokeWidth="2.8" />
          </svg>
        </div>
      );
    }

    // 3. YouTube
    if (normName.includes('youtube') || pkg.includes('youtube')) {
      return (
        <div className="w-full h-full bg-[#FF0000] flex items-center justify-center shadow-inner relative">
          <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
          <div className="w-[66%] h-[48%] bg-white rounded-xl flex items-center justify-center shadow-md">
            <svg className="w-[45%] h-[45%] fill-[#FF0000] translate-x-0.5" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>
      );
    }

    // 4. Chrome Browser
    if (normName.includes('chrome') || pkg.includes('chrome')) {
      return (
        <div className="w-full h-full bg-white flex items-center justify-center shadow-inner relative overflow-hidden">
          <svg className="w-[82%] h-[82%]" viewBox="0 0 192 192">
            <circle cx="96" cy="96" r="96" fill="#EA4335" />
            <path d="M96 0c26.5 0 50.5 10.7 67.9 28.1L120 100H28.7C34.3 43.4 81.3 0 96 0z" fill="#EA4335" />
            <path d="M192 96c0 37.8-21.8 70.4-53.7 86.4L96 96l44-77.9c31.9 16 52 48.6 52 77.9z" fill="#FBBC05" />
            <path d="M138.3 182.4C125.6 188.6 111.2 192 96 192 48.7 192 9.4 157.9 1.4 112L43 40l53 56-42.3 86.4z" fill="#34A853" />
            <circle cx="96" cy="96" r="42" fill="#FFFFFF" />
            <circle cx="96" cy="96" r="32" fill="#4285F4" />
          </svg>
        </div>
      );
    }

    // 5. Telegram
    if (normName.includes('telegram') || pkg.includes('telegram')) {
      return (
        <div className="w-full h-full bg-gradient-to-b from-[#2AABEE] to-[#229ED9] flex items-center justify-center shadow-inner relative">
          <svg className="w-[60%] h-[60%] fill-white -translate-x-0.5 translate-y-0.5 drop-shadow-[0_1px_2px_rgba(0,0,0,0.2)]" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z" />
          </svg>
        </div>
      );
    }

    // 6. Google Pay (GPay) / Paytm
    if (normName.includes('gpay') || normName.includes('google pay') || pkg.includes('nfc') || normName.includes('paytm')) {
      return (
        <div className="w-full h-full bg-white flex items-center justify-center shadow-inner relative border border-zinc-200/40">
          <svg className="w-[72%] h-[72%]" viewBox="0 0 48 48">
            <path fill="#4285F4" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
            <path fill="#34A853" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
            <path fill="#EA4335" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
          </svg>
        </div>
      );
    }

    // 7. Photos / Gallery
    if (normName.includes('photo') || normName.includes('gallery') || pkg.includes('gallery')) {
      return (
        <div className="w-full h-full bg-white flex items-center justify-center shadow-inner relative">
          <svg className="w-[74%] h-[74%]" viewBox="0 0 192 192">
            <path d="M96 28c0 18.8-15.2 34-34 34H28C28 43.2 43.2 28 62 28h34z" fill="#EA4335" />
            <path d="M164 96c0-18.8-15.2-34-34-34V28c18.8 0 34 15.2 34 34v34z" fill="#FBBC05" />
            <path d="M96 164c0-18.8 15.2-34 34-34h34c0 18.8-15.2 34-34 34H96z" fill="#34A853" />
            <path d="M28 96c0 18.8 15.2 34 34 34v34c-18.8 0-34-15.2-34-34V96z" fill="#4285F4" />
          </svg>
        </div>
      );
    }

    // 8. Snapchat
    if (normName.includes('snapchat') || pkg.includes('snapchat')) {
      return (
        <div className="w-full h-full bg-[#FFFC00] flex items-center justify-center shadow-inner relative">
          <svg className="w-[66%] h-[66%] fill-white stroke-black stroke-[1.4] drop-shadow-[0_1px_1px_rgba(0,0,0,0.4)]" viewBox="0 0 24 24">
            <path d="M12 2.5c-3.1 0-5.3 2.1-5.3 5.3 0 .7.1 1.4.3 2-.9.2-1.7.6-2 1.3-.3.8-.1 1.7.4 2.3.6.7 1.4.9 2.1.8-.2.6-.4 1.2-.4 1.8 0 1.2 1.3 2.1 2.9 2.1.6 0 1.1-.1 1.6-.4.4.4.9.6 1.4.6s1-.2 1.4-.6c.5.3 1 .4 1.6.4 1.6 0 2.9-.9 2.9-2.1 0-.6-.2-1.2-.4-1.8.7.1 1.5-.1 2.1-.8.5-.6.7-1.5.4-2.3-.3-.7-1.1-1.1-2-1.3.2-.6.3-1.3.3-2 0-3.2-2.2-5.3-5.3-5.3z" />
          </svg>
        </div>
      );
    }

    // 9. Gmail
    if (normName.includes('gmail') || normName.includes('mail') || pkg.includes('gm')) {
      return (
        <div className="w-full h-full bg-white flex items-center justify-center shadow-inner relative border border-zinc-200/50">
          <svg className="w-[74%] h-[74%]" viewBox="0 0 48 48">
            <path fill="#4285F4" d="M45 16.2v21.3c0 2.5-2 4.5-4.5 4.5H36V22.5L24 13.5 12 22.5V42H7.5C5 42 3 40 3 37.5V16.2l21-15.7 21 15.7z" />
            <path fill="#34A853" d="M36 42h4.5c2.5 0 4.5-2 4.5-4.5V16.2L36 22.5V42z" />
            <path fill="#EA4335" d="M12 42H7.5C5 42 3 40 3 37.5V16.2L12 22.5V42z" />
            <path fill="#FBBC05" d="M3 16.2L24 .5l21 15.7-21 15.8L3 16.2z" />
            <path fill="#EA4335" d="M24 32L3 16.2V12l21 15.8L45 12v4.2L24 32z" />
          </svg>
        </div>
      );
    }

    // 10. Phone Settings
    if (normName.includes('setting') || pkg.includes('setting')) {
      return (
        <div className="w-full h-full bg-gradient-to-br from-[#4A5568] via-[#2D3748] to-[#1A202C] flex items-center justify-center shadow-inner relative overflow-hidden">
          <div className="absolute inset-0 bg-radial from-white/10 to-transparent pointer-events-none" />
          <svg className="w-[64%] h-[64%] text-zinc-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] animate-spin-slow" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
          </svg>
        </div>
      );
    }

    // 11. Netflix
    if (normName.includes('netflix') || pkg.includes('netflix')) {
      return (
        <div className="w-full h-full bg-black flex items-center justify-center shadow-inner relative border border-zinc-900">
          <span className="text-[#E50914] font-black text-3xl sm:text-4xl tracking-tighter drop-shadow-[0_2px_8px_rgba(229,9,20,0.6)] font-sans">
            N
          </span>
        </div>
      );
    }

    // 12. BGMI / Free Fire Gaming
    if (normName.includes('fire') || normName.includes('bgmi') || normName.includes('game') || pkg.includes('freefire')) {
      return (
        <div className="w-full h-full bg-gradient-to-br from-amber-600 via-orange-600 to-red-800 flex items-center justify-center shadow-inner relative border border-amber-400/40">
          <div className="text-center font-black">
            <span className="text-amber-300 text-xs block leading-none tracking-widest uppercase font-mono">BATTLE</span>
            <span className="text-white text-base block font-extrabold leading-none drop-shadow">PRO</span>
          </div>
        </div>
      );
    }

    // 13. Tinder / Dating
    if (normName.includes('tinder') || normName.includes('bumble') || pkg.includes('tinder')) {
      return (
        <div className="w-full h-full bg-gradient-to-tr from-[#FD297B] via-[#FF5864] to-[#FF655B] flex items-center justify-center shadow-inner relative">
          <svg className="w-[62%] h-[62%] fill-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]" viewBox="0 0 24 24">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </div>
      );
    }

    // 14. Binance / Crypto
    if (normName.includes('binance') || normName.includes('crypto') || normName.includes('coin') || pkg.includes('binance')) {
      return (
        <div className="w-full h-full bg-[#181A20] flex items-center justify-center shadow-inner relative border border-[#F0B90B]/30">
          <svg className="w-[62%] h-[62%] fill-[#F0B90B] drop-shadow-[0_0_6px_rgba(240,185,11,0.4)]" viewBox="0 0 24 24">
            <path d="M12 2L6.5 7.5l2.12 2.12L12 6.24l3.38 3.38 2.12-2.12L12 2zM2 12l5.5-5.5 2.12 2.12L6.24 12l3.38 3.38-2.12 2.12L2 12zm10 10l5.5-5.5-2.12-2.12L12 17.76l-3.38-3.38-2.12 2.12L12 22zm10-10l-5.5 5.5-2.12-2.12L17.76 12l-3.38-3.38 2.12-2.12L22 12zm-10-3.5L8.5 12l3.5 3.5 3.5-3.5-3.5-3.5z" />
          </svg>
        </div>
      );
    }

    // 15. Spotify
    if (normName.includes('spotify') || pkg.includes('spotify')) {
      return (
        <div className="w-full h-full bg-[#1ED760] flex items-center justify-center shadow-inner relative">
          <svg className="w-[65%] h-[65%] fill-black" viewBox="0 0 24 24">
            <path d="M12 2C6.4 2 2 6.4 2 12s4.4 10 10 10 10-4.4 10-10S17.6 2 12 2zm4.6 14.4c-.2.3-.5.4-.8.2-2.2-1.3-4.9-1.6-8.2-.9-.4.1-.7-.1-.8-.5-.1-.4.1-.7.5-.8 3.5-.8 6.6-.4 9.1 1.1.3.2.4.6.2.9zm1.2-2.7c-.2.4-.7.5-1.1.3-2.5-1.5-6.3-2-9.2-1.1-.4.1-.9-.1-1-.5-.1-.4.1-.9.5-1 3.4-1 7.6-.5 10.5 1.3.4.1.5.7.3 1zm.1-2.8c-3-1.8-7.9-1.9-10.8-1-.5.1-1-.2-1.1-.7-.1-.5.2-1 .7-1.1 3.3-1 8.8-.9 12.3 1.2.4.3.6.8.3 1.3-.2.4-.8.6-1.4.3z" />
          </svg>
        </div>
      );
    }

    // 16. Phone Dialer Dock Icon
    if (normName.includes('phone') || pkg.includes('dialer') || iconName === 'Phone') {
      return (
        <div className="w-full h-full bg-[#34C759] flex items-center justify-center shadow-inner relative">
          <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
          <svg className="w-[58%] h-[58%] fill-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]" viewBox="0 0 24 24">
            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
          </svg>
        </div>
      );
    }

    // 17. Messages Dock Icon
    if (normName.includes('message') || pkg.includes('mms') || iconName === 'MessageSquare' || iconName === 'MessageCircle') {
      return (
        <div className="w-full h-full bg-[#007AFF] flex items-center justify-center shadow-inner relative">
          <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
          <svg className="w-[60%] h-[60%] fill-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]" viewBox="0 0 24 24">
            <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z" />
          </svg>
        </div>
      );
    }

    // 18. Camera Dock Icon
    if (normName.includes('camera') || pkg.includes('camera') || iconName === 'Camera') {
      return (
        <div className="w-full h-full bg-gradient-to-b from-[#4A4A4A] via-[#2A2A2A] to-[#141414] flex items-center justify-center shadow-inner relative border border-zinc-700/50">
          <div className="w-[64%] h-[64%] rounded-full bg-gradient-to-b from-[#1C1C1E] to-[#2C2C2E] border-2 border-zinc-400/80 flex items-center justify-center shadow-inner">
            <div className="w-[50%] h-[50%] rounded-full bg-gradient-to-tr from-blue-900 via-indigo-950 to-blue-700 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/80 -translate-y-0.5 translate-x-0.5" />
            </div>
          </div>
        </div>
      );
    }

    // Fallback: Elegant Material App Badge
    return (
      <div className="w-full h-full bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 flex items-center justify-center text-white shadow-inner">
        <span className="font-bold text-lg uppercase tracking-tight">
          {appName.slice(0, 2)}
        </span>
      </div>
    );
  };

  function renderDisguiseIcon(type: string, px: number) {
    switch (type) {
      case 'weather':
        return (
          <div className="w-full h-full bg-gradient-to-tr from-sky-400 to-blue-600 flex items-center justify-center text-white shadow-inner">
            <CloudSun className="w-[62%] h-[62%] text-amber-300 drop-shadow" />
          </div>
        );
      case 'converter':
        return (
          <div className="w-full h-full bg-gradient-to-tr from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-inner">
            <Coins className="w-[62%] h-[62%] text-amber-300 drop-shadow" />
          </div>
        );
      case 'notes':
        return (
          <div className="w-full h-full bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center text-white shadow-inner">
            <FileSpreadsheet className="w-[62%] h-[62%] text-zinc-900 drop-shadow" />
          </div>
        );
      case 'scanner':
        return (
          <div className="w-full h-full bg-gradient-to-tr from-indigo-500 to-purple-700 flex items-center justify-center text-white shadow-inner">
            <QrCode className="w-[62%] h-[62%] text-white drop-shadow" />
          </div>
        );
      case 'calculator':
      default:
        // Authentic iOS / Android Calculator Icon (Dark Charcoal with Orange Grid)
        return (
          <div className="w-full h-full bg-zinc-900 border border-zinc-800 flex flex-col items-center justify-between p-2 shadow-inner relative overflow-hidden">
            <div className="w-full flex justify-between items-center text-[10px] font-mono text-orange-400 font-bold px-0.5">
              <span>AC</span>
              <span>÷</span>
            </div>
            <div className="w-full grid grid-cols-3 gap-0.5 text-center text-[9px] font-bold text-zinc-300">
              <span className="bg-zinc-800 rounded py-0.5">7</span>
              <span className="bg-zinc-800 rounded py-0.5">8</span>
              <span className="bg-orange-500 text-white rounded py-0.5 font-black">=</span>
            </div>
          </div>
        );
    }
  }

  function renderBadgesAndIndicators() {
    return (
      <>
        {/* Notification Dot / Badge Count */}
        {showBadge && typeof badgeCount === 'number' && badgeCount > 0 && (
          <div className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center shadow-lg border-2 border-zinc-950 pointer-events-none animate-pulse">
            {badgeCount > 99 ? '99+' : badgeCount}
          </div>
        )}

        {/* Status Indicators in App Hide & App Lock Dashboards */}
        {showIndicators && (
          <div className="absolute bottom-0 right-0 p-0.5 bg-black/80 rounded-tl-lg flex items-center gap-0.5 pointer-events-none">
            {isLocked && <Lock className="w-2.5 h-2.5 text-amber-400" />}
            {isHidden && <EyeOff className="w-2.5 h-2.5 text-purple-400" />}
          </div>
        )}
      </>
    );
  }

  return (
    <div
      className={`relative flex items-center justify-center select-none shadow-xl hover:scale-105 transition-transform cursor-pointer ring-1 ring-white/10 ${getShapeClass()} ${className}`}
      style={{ width: `${pixelSize}px`, height: `${pixelSize}px` }}
    >
      {renderOfficialLogo()}
      {renderBadgesAndIndicators()}
    </div>
  );
};
