import React, { useEffect, useState } from 'react';
import { useVault } from '../context/VaultContext';
import { soundManager } from '../utils/sound';
import {
  History,
  HelpCircle,
  Trash2,
  X,
  Volume2,
  VolumeX,
  Sparkles,
  CloudSun,
  Coins,
  FileSpreadsheet,
  QrCode,
  Smartphone,
  Monitor,
  CheckCircle2,
  Copy,
  Keyboard
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const Calculator: React.FC = () => {
  const {
    t,
    unlockVault,
    securitySettings,
    effectiveDeviceMode,
    setDeviceMode,
    history,
    addHistoryItem,
    clearHistory,
    setShowSetupModal,
    setShowRecoveryModal,
    updateSecuritySettings,
    language,
    setLanguage,
    setAppViewMode,
    setIsScannerModalOpen
  } = useVault();

  const [display, setDisplay] = useState<string>('0');
  const [equation, setEquation] = useState<string>('');
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [isError, setIsError] = useState<boolean>(false);
  const [isResult, setIsResult] = useState<boolean>(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const playClick = () => {
    if (securitySettings.soundEnabled) {
      soundManager.playKeyClick();
    }
  };

  const handleNumber = (digit: string) => {
    playClick();
    if (isResult || isError || display === '0') {
      setDisplay(digit);
      setIsResult(false);
      setIsError(false);
    } else {
      if (display.length < 20) {
        setDisplay(display + digit);
      }
    }
  };

  const handleDecimal = () => {
    playClick();
    if (isResult || isError) {
      setDisplay('0.');
      setIsResult(false);
      setIsError(false);
      return;
    }
    const parts = display.split(/[\+\-\×\÷\^]/);
    const lastPart = parts[parts.length - 1];
    if (!lastPart.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOperator = (op: string) => {
    playClick();
    setIsError(false);
    setIsResult(false);
    
    const lastChar = display.slice(-1);
    if (['+', '-', '×', '÷', '^'].includes(lastChar)) {
      setDisplay(display.slice(0, -1) + op);
      return;
    }
    setDisplay(display + op);
  };

  const handleClear = () => {
    playClick();
    setDisplay('0');
    setEquation('');
    setIsError(false);
    setIsResult(false);
  };

  const handleBackspace = () => {
    playClick();
    if (isError || isResult) {
      setDisplay('0');
      setIsResult(false);
      setIsError(false);
      return;
    }
    if (display.length <= 1) {
      setDisplay('0');
    } else {
      setDisplay(display.slice(0, -1));
    }
  };

  const handlePercent = () => {
    playClick();
    try {
      const val = parseFloat(display);
      if (!isNaN(val)) {
        const res = (val / 100).toString();
        setDisplay(res);
        setIsResult(true);
      }
    } catch {
      setIsError(true);
    }
  };

  const handleToggleSign = () => {
    playClick();
    try {
      if (display === '0' || isError) return;
      if (display.startsWith('-')) {
        setDisplay(display.slice(1));
      } else {
        setDisplay('-' + display);
      }
    } catch {
      setIsError(true);
    }
  };

  const handleScientificFunc = (func: string) => {
    playClick();
    try {
      const val = parseFloat(display);
      if (isNaN(val)) return;
      let res = 0;
      if (func === 'sqrt') res = Math.sqrt(val);
      else if (func === 'sq') res = Math.pow(val, 2);
      else if (func === 'sin') res = Math.sin((val * Math.PI) / 180);
      else if (func === 'cos') res = Math.cos((val * Math.PI) / 180);
      else if (func === 'tan') res = Math.tan((val * Math.PI) / 180);
      else if (func === 'log') res = Math.log10(val);

      const formatted = Number.isInteger(res) ? res.toString() : parseFloat(res.toFixed(8)).toString();
      setEquation(`${func}(${display}) =`);
      addHistoryItem(`${func}(${display})`, formatted);
      setDisplay(formatted);
      setIsResult(true);
    } catch {
      setIsError(true);
      setDisplay('Error');
    }
  };

  const handleEquals = () => {
    playClick();
    const candidatePin = display.trim();

    // 1. Check if input triggers vault unlock
    const unlocked = unlockVault(candidatePin);
    if (unlocked) {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch {}
      return;
    }

    // 2. Otherwise calculate math expression
    try {
      let expr = display
        .replace(/×/g, '*')
        .replace(/÷/g, '/');

      if (!expr || expr === 'Error') {
        setDisplay('0');
        return;
      }

      if (!/^[0-9+\-*/().\s]+$/.test(expr)) {
        setIsError(true);
        setDisplay('Error');
        return;
      }

      // eslint-disable-next-line no-eval
      const resultVal = Function(`'use strict'; return (${expr})`)();

      if (typeof resultVal === 'number' && !isNaN(resultVal) && isFinite(resultVal)) {
        const formattedRes = Number.isInteger(resultVal)
          ? resultVal.toString()
          : parseFloat(resultVal.toFixed(8)).toString();

        setEquation(`${display} =`);
        addHistoryItem(display, formattedRes);
        setDisplay(formattedRes);
        setIsResult(true);
      } else {
        setIsError(true);
        setDisplay('Error');
      }
    } catch (err) {
      setIsError(true);
      setDisplay('Error');
    }
  };

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(e.key)) {
        handleNumber(e.key);
      } else if (e.key === '.') {
        handleDecimal();
      } else if (e.key === '+') {
        handleOperator('+');
      } else if (e.key === '-') {
        handleOperator('-');
      } else if (e.key === '*') {
        handleOperator('×');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') {
        handleClear();
      } else if (e.key === '%') {
        handlePercent();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [display, equation, isResult, isError, securitySettings]);

  // Disguise Icon Map
  const getDisguiseConfig = () => {
    switch (securitySettings.disguiseIcon) {
      case 'weather':
        return { icon: CloudSun, title: language === 'hi' ? 'मौसम और तापमान' : 'Weather & Temp' };
      case 'converter':
        return { icon: Coins, title: language === 'hi' ? 'मुद्रा कन्वर्टर' : 'Currency Calc' };
      case 'notes':
        return { icon: FileSpreadsheet, title: language === 'hi' ? 'स्मार्ट शीट्स' : 'Mini Sheets' };
      case 'scanner':
        return { icon: QrCode, title: language === 'hi' ? 'क्यूआर स्कैनर' : 'QR Tool' };
      default:
        return { icon: Sparkles, title: t.calcTitle };
    }
  };

  const disguiseConfig = getDisguiseConfig();
  const DisguiseIcon = disguiseConfig.icon;

  const copyHistoryItem = (res: string, idx: number) => {
    navigator.clipboard.writeText(res);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 1500);
  };

  const isPcLayout = effectiveDeviceMode === 'pc';

  return (
    <div id="calculator-view-root" className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col items-center justify-center p-3 sm:p-6 select-none relative">
      
      {/* Top Universal Mode & Control Bar */}
      <header id="calc-top-header" className="w-full max-w-4xl mb-4 flex flex-wrap items-center justify-between gap-3 px-2">
        
        {/* Disguise Branding */}
        <div className="flex items-center gap-2.5">
          <div 
            onClick={() => setShowSetupModal(true)}
            className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 cursor-pointer active:scale-95 transition-transform"
            title={language === 'hi' ? 'कैलकुलेटर v2.4' : 'Calculator v2.4'}
          >
            <DisguiseIcon className="w-5 h-5" />
          </div>
          <div>
            <h1 
              onClick={() => setShowSetupModal(true)}
              className="text-sm sm:text-base font-bold text-zinc-100 flex items-center gap-1.5 cursor-pointer"
            >
              <span>{disguiseConfig.title}</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-zinc-800 text-zinc-400 font-mono font-normal">v2.4</span>
            </h1>
            <p className="text-[11px] text-zinc-500">
              {language === 'hi' ? 'मानक वैज्ञानिक कैलकुलेटर' : 'Standard Scientific Calculator'}
            </p>
          </div>
        </div>

        {/* Mode Switcher Pill & Tools */}
        <div className="flex items-center gap-2">
          
          {/* 1:1 Stealth Clone Launcher Button */}
          <button
            id="btn-open-stealth-launcher"
            onClick={() => setAppViewMode('launcher')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 active:scale-95 transition-all"
            title="Open 1:1 Stealth Phone Clone Launcher"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{language === 'hi' ? '📱 फ़ोन स्क्रीन' : '📱 Phone Screen'}</span>
          </button>

          {/* Screen Scanner Button */}
          <button
            id="btn-scan-screen-calc"
            onClick={() => setIsScannerModalOpen(true)}
            className="p-2 rounded-xl bg-purple-950/60 border border-purple-500/40 text-purple-300 hover:bg-purple-900/80 transition-colors"
            title="Scan & Clone Phone Screen"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
          </button>

          {/* Device Mode Switcher */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-1 flex items-center gap-1 shadow-inner text-xs">
            <button
              id="btn-mode-mobile"
              onClick={() => setDeviceMode('mobile')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                securitySettings.deviceMode === 'mobile'
                  ? 'bg-amber-500 text-zinc-950 font-bold shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="Mobile Phone View"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Mobile</span>
            </button>
            <button
              id="btn-mode-pc"
              onClick={() => setDeviceMode('pc')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                securitySettings.deviceMode === 'pc'
                  ? 'bg-amber-500 text-zinc-950 font-bold shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="Desktop PC Workstation View"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">PC Mode</span>
            </button>
            <button
              id="btn-mode-auto"
              onClick={() => setDeviceMode('auto')}
              className={`px-2 py-1 rounded-lg text-[10px] transition-all ${
                securitySettings.deviceMode === 'auto'
                  ? 'bg-zinc-800 text-amber-400 font-semibold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
              title="Auto Detect Screen"
            >
              Auto ({effectiveDeviceMode === 'pc' ? 'PC' : 'Mob'})
            </button>
          </div>

          {/* Language Switcher */}
          <button
            id="btn-switch-lang-header"
            onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
            className="px-2.5 py-1.5 text-xs font-bold rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-300 transition-colors"
          >
            {language === 'hi' ? 'EN' : 'हिंदी'}
          </button>

          {/* Sound Toggle */}
          <button
            id="btn-toggle-sound-header"
            onClick={() => updateSecuritySettings({ soundEnabled: !securitySettings.soundEnabled })}
            className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors"
            title={securitySettings.soundEnabled ? 'Mute' : 'Unmute'}
          >
            {securitySettings.soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-zinc-500" />}
          </button>
        </div>
      </header>

      {/* Main Responsive Calculator Engine */}
      {isPcLayout ? (
        /* PC WORKSTATION MODE: Dual-Pane Layout */
        <div id="calculator-pc-workstation" className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-5 bg-zinc-900/90 border border-zinc-800 rounded-[32px] p-6 shadow-2xl backdrop-blur-sm">
          
          {/* Left Column: Scientific & Core Calculator Keypad */}
          <div className="lg:col-span-7 flex flex-col">
            
            {/* Large PC Display Screen */}
            <div id="pc-calc-display" className="p-4 sm:p-5 flex flex-col justify-end text-right min-h-[140px] bg-black/90 rounded-2xl mb-4 border border-zinc-800/80 shadow-inner">
              <div className="text-sm text-zinc-500 font-mono h-6 overflow-hidden text-ellipsis">
                {equation}
              </div>
              <div
                id="pc-display-value"
                className="text-4xl sm:text-5xl font-mono font-light tracking-tight text-amber-400 overflow-x-auto whitespace-nowrap scrollbar-none py-1"
              >
                {display}
              </div>
            </div>

            {/* Scientific Function Row (PC Mode) */}
            <div className="grid grid-cols-6 gap-2 mb-3">
              {[
                { label: '√', action: () => handleScientificFunc('sqrt'), title: 'Square Root' },
                { label: 'x²', action: () => handleScientificFunc('sq'), title: 'Square' },
                { label: 'sin', action: () => handleScientificFunc('sin'), title: 'Sine' },
                { label: 'cos', action: () => handleScientificFunc('cos'), title: 'Cosine' },
                { label: 'tan', action: () => handleScientificFunc('tan'), title: 'Tangent' },
                { label: 'log', action: () => handleScientificFunc('log'), title: 'Log 10' },
              ].map((f, idx) => (
                <button
                  key={idx}
                  onClick={f.action}
                  title={f.title}
                  className="h-10 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 font-mono text-xs font-semibold active:scale-95 transition-all"
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Main Keypad Grid */}
            <div className="grid grid-cols-4 gap-2.5 flex-1">
              {/* Row 1 */}
              <button onClick={handleClear} className="h-12 sm:h-14 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30 font-bold text-base transition-all">AC</button>
              <button onClick={handleToggleSign} className="h-12 sm:h-14 rounded-xl bg-zinc-800 text-zinc-200 hover:bg-zinc-700 font-semibold text-base transition-all">+/-</button>
              <button onClick={handlePercent} className="h-12 sm:h-14 rounded-xl bg-zinc-800 text-zinc-200 hover:bg-zinc-700 font-semibold text-base transition-all">%</button>
              <button onClick={() => handleOperator('÷')} className="h-12 sm:h-14 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xl hover:bg-amber-400 transition-all shadow-md shadow-amber-500/20">÷</button>

              {/* Row 2 */}
              <button onClick={() => handleNumber('7')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">7</button>
              <button onClick={() => handleNumber('8')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">8</button>
              <button onClick={() => handleNumber('9')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">9</button>
              <button onClick={() => handleOperator('×')} className="h-12 sm:h-14 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xl hover:bg-amber-400 transition-all shadow-md shadow-amber-500/20">×</button>

              {/* Row 3 */}
              <button onClick={() => handleNumber('4')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">4</button>
              <button onClick={() => handleNumber('5')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">5</button>
              <button onClick={() => handleNumber('6')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">6</button>
              <button onClick={() => handleOperator('-')} className="h-12 sm:h-14 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xl hover:bg-amber-400 transition-all shadow-md shadow-amber-500/20">-</button>

              {/* Row 4 */}
              <button onClick={() => handleNumber('1')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">1</button>
              <button onClick={() => handleNumber('2')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">2</button>
              <button onClick={() => handleNumber('3')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">3</button>
              <button onClick={() => handleOperator('+')} className="h-12 sm:h-14 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xl hover:bg-amber-400 transition-all shadow-md shadow-amber-500/20">+</button>

              {/* Row 5 */}
              <button onClick={() => handleNumber('0')} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-xl transition-all">0</button>
              <button onClick={handleDecimal} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-100 font-mono text-2xl transition-all">.</button>
              <button onClick={handleBackspace} className="h-12 sm:h-14 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 font-semibold text-base transition-all">⌫</button>
              <button
                id="pc-calc-btn-equals"
                onClick={handleEquals}
                className="h-12 sm:h-14 rounded-xl bg-emerald-500 text-zinc-950 font-bold text-2xl hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/30 ring-2 ring-emerald-400/40 flex items-center justify-center"
                title="Calculate / Dial Secret PIN"
              >
                =
              </button>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-500">
              <span className="flex items-center gap-1.5 text-zinc-500">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                <span>{language === 'hi' ? 'मानक गणितीय मोड (v2.4)' : 'Standard Math Engine (v2.4)'}</span>
              </span>
              <button
                onClick={() => setShowRecoveryModal(true)}
                className="flex items-center gap-1.5 hover:text-amber-400 text-zinc-500 transition-colors"
                title={language === 'hi' ? 'सहायता' : 'Help'}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'सहायता' : 'Help'}</span>
              </button>
            </div>
          </div>

          {/* Right Column: Live Calculation Tape & PC Keyboard Reference */}
          <div className="lg:col-span-5 flex flex-col bg-zinc-950/80 border border-zinc-800/80 rounded-2xl p-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-3">
              <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                {language === 'hi' ? 'कैलकुलेशन जर्नल (Live History)' : 'Live Calculation Tape'}
              </span>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
                  title={t.clearHistory}
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{language === 'hi' ? 'साफ करें' : 'Clear'}</span>
                </button>
              )}
            </div>

            {/* History Feed */}
            <div className="flex-1 overflow-y-auto max-h-[260px] space-y-2 pr-1 scrollbar-thin">
              {history.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-zinc-600 text-xs py-8">
                  <History className="w-8 h-8 mb-2 opacity-30" />
                  {t.noHistory}
                </div>
              ) : (
                history.map((item, idx) => (
                  <div
                    key={item.id}
                    className="p-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800/80 hover:border-zinc-700 flex items-center justify-between text-right group transition-all"
                  >
                    <button
                      onClick={() => copyHistoryItem(item.res, idx)}
                      className="p-1 text-zinc-500 hover:text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Copy result"
                    >
                      {copiedIndex === idx ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <div
                      onClick={() => setDisplay(item.res)}
                      className="cursor-pointer"
                    >
                      <div className="text-[11px] text-zinc-500 font-mono">{item.expr}</div>
                      <div className="text-sm font-bold text-amber-400 font-mono">= {item.res}</div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* PC Hotkey Cheat Sheet */}
            <div className="mt-3 pt-3 border-t border-zinc-800/80 text-[11px] text-zinc-400 space-y-1.5">
              <div className="font-semibold text-zinc-300 flex items-center gap-1.5 text-xs">
                <Keyboard className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'hi' ? 'कीबोर्ड शॉर्टकट' : 'Keyboard Hotkeys'}</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-[10px] text-zinc-500">
                <div><span className="font-mono bg-zinc-900 border border-zinc-800 px-1 rounded text-zinc-300">NumPad</span> : Type Numbers</div>
                <div><span className="font-mono bg-zinc-900 border border-zinc-800 px-1 rounded text-zinc-300">Enter / =</span> : Unlock / Solve</div>
                <div><span className="font-mono bg-zinc-900 border border-zinc-800 px-1 rounded text-zinc-300">Esc / C</span> : Clear Screen</div>
                <div><span className="font-mono bg-zinc-900 border border-zinc-800 px-1 rounded text-zinc-300">Backspace</span> : Delete Digit</div>
              </div>
            </div>

          </div>

        </div>
      ) : (
        /* MOBILE PHONE CONTAINER */
        <div id="calculator-phone-frame" className="w-full max-w-sm bg-black border border-zinc-800/90 rounded-[40px] shadow-2xl p-4 sm:p-5 flex flex-col relative overflow-hidden ring-1 ring-white/10">
          
          {/* Mobile Status Bar Disguise */}
          <div className="flex items-center justify-between pb-3 pt-1 border-b border-zinc-900 text-zinc-400 text-xs">
            <div className="flex items-center gap-2">
              <DisguiseIcon className="w-4 h-4 text-emerald-400" />
              <span className="font-medium tracking-tight text-zinc-300">{disguiseConfig.title}</span>
            </div>

            <div className="flex items-center gap-2">
              {/* History Toggle */}
              <button
                id="btn-toggle-history"
                onClick={() => setShowHistory(!showHistory)}
                className={`p-1.5 rounded-lg transition-colors ${showHistory ? 'bg-amber-500/20 text-amber-400' : 'hover:bg-zinc-800 text-zinc-400'}`}
                title={t.calcHistory}
              >
                <History className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* History Slide-in Drawer */}
          {showHistory && (
            <div id="calculator-history-drawer" className="absolute inset-x-0 top-14 bottom-0 bg-zinc-950/95 backdrop-blur-md z-30 p-4 flex flex-col rounded-b-[40px] border-t border-zinc-800">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <span className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
                  <History className="w-4 h-4 text-amber-400" />
                  {t.calcHistory}
                </span>
                <div className="flex items-center gap-2">
                  {history.length > 0 && (
                    <button
                      id="btn-clear-history"
                      onClick={clearHistory}
                      className="p-1 text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
                      title={t.clearHistory}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button
                    id="btn-close-history"
                    onClick={() => setShowHistory(false)}
                    className="p-1 text-zinc-400 hover:text-zinc-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto py-2 space-y-3">
                {history.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-zinc-500 text-xs py-8">
                    <History className="w-8 h-8 mb-2 opacity-40" />
                    {t.noHistory}
                  </div>
                ) : (
                  history.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        setDisplay(item.res);
                        setShowHistory(false);
                      }}
                      className="p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800/80 hover:border-zinc-700 cursor-pointer text-right transition-colors"
                    >
                      <div className="text-xs text-zinc-400 font-mono">{item.expr}</div>
                      <div className="text-base font-bold text-amber-400 font-mono mt-0.5">= {item.res}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Calculator Display Screen */}
          <div id="calculator-screen" className="pt-6 pb-4 px-3 flex flex-col justify-end text-right min-h-[140px] bg-gradient-to-b from-zinc-950 to-zinc-900/60 rounded-2xl mb-4 border border-zinc-900">
            <div className="text-xs text-zinc-500 font-mono h-5 overflow-hidden text-ellipsis">
              {equation}
            </div>
            <div
              id="calculator-display-value"
              className="text-4xl sm:text-5xl font-mono font-light tracking-tight text-zinc-100 overflow-x-auto whitespace-nowrap scrollbar-none py-1"
            >
              {display}
            </div>
          </div>

          {/* Calculator Keypad Grid */}
          <div id="calculator-keypad" className="grid grid-cols-4 gap-2.5 sm:gap-3 flex-1">
            {/* Row 1 */}
            <button
              id="calc-btn-ac"
              onClick={handleClear}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-800/90 text-zinc-200 hover:bg-zinc-700 active:scale-95 font-semibold text-lg transition-all flex items-center justify-center"
            >
              AC
            </button>
            <button
              id="calc-btn-sign"
              onClick={handleToggleSign}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-800/90 text-zinc-200 hover:bg-zinc-700 active:scale-95 font-semibold text-lg transition-all flex items-center justify-center"
            >
              +/-
            </button>
            <button
              id="calc-btn-percent"
              onClick={handlePercent}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-800/90 text-zinc-200 hover:bg-zinc-700 active:scale-95 font-semibold text-lg transition-all flex items-center justify-center"
            >
              %
            </button>
            <button
              id="calc-btn-divide"
              onClick={() => handleOperator('÷')}
              className="h-14 sm:h-16 rounded-2xl bg-amber-500 text-zinc-950 font-bold text-2xl hover:bg-amber-400 active:scale-95 transition-all flex items-center justify-center shadow-lg shadow-amber-500/20"
            >
              ÷
            </button>

            {/* Row 2 */}
            <button
              id="calc-btn-7"
              onClick={() => handleNumber('7')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              7
            </button>
            <button
              id="calc-btn-8"
              onClick={() => handleNumber('8')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              8
            </button>
            <button
              id="calc-btn-9"
              onClick={() => handleNumber('9')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              9
            </button>
            <button
              id="calc-btn-multiply"
              onClick={() => handleOperator('×')}
              className="h-14 sm:h-16 rounded-2xl bg-amber-500 text-zinc-950 font-bold text-2xl hover:bg-amber-400 active:scale-95 transition-all flex items-center justify-center shadow-lg shadow-amber-500/20"
            >
              ×
            </button>

            {/* Row 3 */}
            <button
              id="calc-btn-4"
              onClick={() => handleNumber('4')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              4
            </button>
            <button
              id="calc-btn-5"
              onClick={() => handleNumber('5')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              5
            </button>
            <button
              id="calc-btn-6"
              onClick={() => handleNumber('6')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              6
            </button>
            <button
              id="calc-btn-minus"
              onClick={() => handleOperator('-')}
              className="h-14 sm:h-16 rounded-2xl bg-amber-500 text-zinc-950 font-bold text-2xl hover:bg-amber-400 active:scale-95 transition-all flex items-center justify-center shadow-lg shadow-amber-500/20"
            >
              -
            </button>

            {/* Row 4 */}
            <button
              id="calc-btn-1"
              onClick={() => handleNumber('1')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              1
            </button>
            <button
              id="calc-btn-2"
              onClick={() => handleNumber('2')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              2
            </button>
            <button
              id="calc-btn-3"
              onClick={() => handleNumber('3')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              3
            </button>
            <button
              id="calc-btn-plus"
              onClick={() => handleOperator('+')}
              className="h-14 sm:h-16 rounded-2xl bg-amber-500 text-zinc-950 font-bold text-2xl hover:bg-amber-400 active:scale-95 transition-all flex items-center justify-center shadow-lg shadow-amber-500/20"
            >
              +
            </button>

            {/* Row 5 */}
            <button
              id="calc-btn-0"
              onClick={() => handleNumber('0')}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-medium text-xl transition-all flex items-center justify-center"
            >
              0
            </button>
            <button
              id="calc-btn-dot"
              onClick={handleDecimal}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-100 border border-zinc-800/80 hover:bg-zinc-800 active:scale-95 font-bold text-2xl transition-all flex items-center justify-center"
            >
              .
            </button>
            <button
              id="calc-btn-backspace"
              onClick={handleBackspace}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900 text-zinc-400 border border-zinc-800/80 hover:bg-zinc-800 hover:text-zinc-200 active:scale-95 font-semibold text-lg transition-all flex items-center justify-center"
              title="Backspace"
            >
              ⌫
            </button>
            
            {/* EQUALS / SECRET UNLOCK TRIGGER */}
            <button
              id="calc-btn-equals"
              onClick={handleEquals}
              className="h-14 sm:h-16 rounded-2xl bg-emerald-500 text-zinc-950 font-bold text-2xl hover:bg-emerald-400 active:scale-95 transition-all flex items-center justify-center shadow-lg shadow-emerald-500/25 ring-2 ring-emerald-400/30"
              title="Equals / Secret Vault Trigger"
            >
              =
            </button>
          </div>

          {/* Bottom subtle actions */}
          <div className="mt-4 pt-3 border-t border-zinc-900 flex items-center justify-between text-xs text-zinc-600">
            <span className="flex items-center gap-1.5 text-[11px] text-zinc-500">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
              <span>{language === 'hi' ? 'वैज्ञानिक मोड' : 'Scientific Mode'}</span>
            </span>

            <button
              id="btn-forgot-pin"
              onClick={() => setShowRecoveryModal(true)}
              className="flex items-center gap-1.5 hover:text-amber-400 text-zinc-500 transition-colors text-[11px]"
              title={language === 'hi' ? 'सहायता' : 'Help'}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'सहायता' : 'Help'}</span>
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
