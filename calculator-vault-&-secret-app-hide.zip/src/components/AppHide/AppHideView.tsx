import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { AppItem } from '../../types';
import { AppIcon } from '../Launcher/AppIcon';
import {
  EyeOff,
  Eye,
  Smartphone,
  Play,
  Check,
  Search,
  Plus,
  Shield,
  Layers,
  Sparkles,
  X
} from 'lucide-react';
import { PhoneSimulatorModal } from './PhoneSimulatorModal';
import { soundManager } from '../../utils/sound';

export const AppHideView: React.FC = () => {
  const {
    t,
    apps,
    toggleAppHide,
    language,
    setAppViewMode
  } = useVault();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showPhoneSim, setShowPhoneSim] = useState<boolean>(false);
  const [launchedApp, setLaunchedApp] = useState<AppItem | null>(null);
  const [showHideSelector, setShowHideSelector] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const hiddenApps = apps.filter((a) => a.isHidden);
  const unhiddenApps = apps.filter((a) => !a.isHidden);

  const handleToggleHide = (app: AppItem) => {
    toggleAppHide(app.id);
    soundManager.playUnlockChime();
    const msg = app.isHidden ? t.unhideSuccessMsg : t.hideSuccessMsg;
    setToastMessage(`${app.name}: ${msg}`);
    setTimeout(() => setToastMessage(null), 2500);
  };

  return (
    <div id="app-hide-view-container" className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 p-3.5 rounded-2xl bg-emerald-500 text-zinc-950 font-bold text-xs shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header & Main Phone Simulator Trigger */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-zinc-100 flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center">
              <EyeOff className="w-4 h-4" />
            </span>
            {t.appHideTitle}
          </h2>
          <p className="text-xs text-zinc-400 mt-1">{t.appHideSubtitle}</p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* 1:1 Stealth Clone Launcher Button */}
          <button
            id="btn-hide-view-stealth-launcher"
            onClick={() => setAppViewMode('launcher')}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-lg shadow-purple-600/30 active:scale-95"
          >
            <Smartphone className="w-4 h-4 text-white" />
            <span>{language === 'hi' ? '📱 1:1 फोन स्क्रीन क्लोन' : '📱 1:1 Stealth Launcher'}</span>
          </button>

          {/* Launch Live Phone Simulator */}
          <button
            id="btn-open-phone-simulator"
            onClick={() => setShowPhoneSim(true)}
            className="px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-zinc-500 text-zinc-100 text-xs font-semibold flex items-center gap-2 transition-all shadow-md"
          >
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>{t.launchPhoneSim}</span>
          </button>

          {/* Hide New App */}
          <button
            id="btn-hide-new-app"
            onClick={() => setShowHideSelector(true)}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-lg shadow-rose-600/25"
          >
            <Plus className="w-4 h-4" />
            <span>{t.hideAnApp}</span>
          </button>
        </div>
      </div>

      {/* Notice Banner */}
      <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-start gap-3">
        <div className="w-9 h-9 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
          <Shield className="w-4 h-4" />
        </div>
        <div className="space-y-1">
          <span className="text-xs font-bold text-zinc-200">
            {language === 'hi' ? '100% गायब (Phone Screen Cloaking Active)' : '100% Invisible on Phone Screen'}
          </span>
          <p className="text-xs text-zinc-400 leading-relaxed">
            {t.hiddenNotice}
          </p>
        </div>
      </div>

      {/* Hidden Apps Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
            <span>{t.hiddenAppsCount}</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 font-mono font-bold">
              {hiddenApps.length}
            </span>
          </h3>
        </div>

        {hiddenApps.length === 0 ? (
          <div className="p-10 text-center border border-zinc-900 rounded-3xl bg-zinc-950/60">
            <EyeOff className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <h4 className="text-sm font-semibold text-zinc-400">{t.noHiddenApps}</h4>
            <p className="text-xs text-zinc-600 mt-1">
              {language === 'hi' ? 'नीचे दी गई सूची में से कोई भी ऐप चुनकर "Hide" करें' : 'Click "Hide an App" to remove it from your smartphone screen'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {hiddenApps.map((app) => {
              return (
                <div
                  key={app.id}
                  className="p-4 rounded-2xl bg-zinc-900/90 border border-rose-500/30 flex items-center justify-between gap-3 shadow-md hover:border-rose-500/60 transition-all"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <AppIcon
                      appName={app.name}
                      packageName={app.packageName}
                      iconName={app.iconName}
                      size="compact"
                      shape="squircle"
                      showBadge={false}
                      customIconUrl={app.customIconUrl}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <h4 className="text-xs font-bold text-zinc-100 truncate">{app.name}</h4>
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-semibold uppercase">
                          Hidden
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 truncate">{app.mockDescription}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Launch in Vault */}
                    <button
                      onClick={() => setLaunchedApp(app)}
                      className="p-2 rounded-xl bg-zinc-800 hover:bg-emerald-500 hover:text-zinc-950 text-emerald-400 text-xs transition-colors"
                      title={t.launchSecretly}
                    >
                      <Play className="w-3.5 h-3.5" />
                    </button>

                    {/* Unhide Button */}
                    <button
                      onClick={() => handleToggleHide(app)}
                      className="p-2 rounded-xl bg-zinc-800 hover:bg-rose-500/20 text-zinc-300 hover:text-rose-300 text-xs transition-colors"
                      title={t.unhideApp}
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Manage All Installed Apps Section */}
      <div className="space-y-3 pt-4 border-t border-zinc-900">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-zinc-300">{t.allAppsList}</h3>
          <div className="text-xs text-zinc-500">
            {language === 'hi' ? 'हाइड करने के लिए स्विच टॉगल करें' : 'Toggle to hide / unhide from phone'}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {apps.map((app) => {
            return (
              <div
                key={app.id}
                className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                  app.isHidden
                    ? 'bg-rose-950/20 border-rose-500/40'
                    : 'bg-zinc-950/60 border-zinc-800/80 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <AppIcon
                    appName={app.name}
                    packageName={app.packageName}
                    iconName={app.iconName}
                    size="compact"
                    shape="squircle"
                    showBadge={false}
                    customIconUrl={app.customIconUrl}
                  />
                  <div className="min-w-0 flex-1">
                    <span className="text-xs font-bold text-zinc-100 truncate block">{app.name}</span>
                    <span className="text-[10px] text-zinc-500 block truncate">{app.category}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleToggleHide(app)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    app.isHidden
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {app.isHidden ? (
                    <>
                      <EyeOff className="w-3.5 h-3.5" />
                      <span>{language === 'hi' ? 'छिपा हुआ' : 'Hidden'}</span>
                    </>
                  ) : (
                    <>
                      <Eye className="w-3.5 h-3.5" />
                      <span>{language === 'hi' ? 'दिख रहा है' : 'Visible'}</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Secret App Sandbox Launcher Modal */}
      {launchedApp && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-[36px] overflow-hidden shadow-2xl flex flex-col min-h-[560px] relative text-zinc-100">
            
            {/* Header */}
            <div className="flex items-center justify-between p-4 bg-zinc-900 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-zinc-200">{launchedApp.name} (Vault Sandbox)</span>
              </div>
              <button onClick={() => setLaunchedApp(null)} className="p-1 text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Simulated Live Environment */}
            <div className="flex-1 p-5 space-y-4 overflow-y-auto bg-zinc-900/40">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-zinc-900 border border-zinc-800">
                <AppIcon
                  appName={launchedApp.name}
                  packageName={launchedApp.packageName}
                  iconName={launchedApp.iconName}
                  size="normal"
                  shape="squircle"
                  showBadge={false}
                  customIconUrl={launchedApp.customIconUrl}
                />
                <div>
                  <h4 className="text-sm font-bold text-zinc-100">{launchedApp.name}</h4>
                  <p className="text-xs text-rose-400 font-semibold">
                    {language === 'hi' ? 'सीक्रेट कंटेनर में सक्रिय' : 'Isolated Vault Sandbox'}
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs space-y-3">
                <div className="text-zinc-400">
                  {language === 'hi'
                    ? `यह ऐप मोबाइल की मुख्य स्क्रीन से पूरी तरह छिपी हुई है। केवल आप ही इसे इस कैलकुलेटर वॉल्ट में खोल सकते हैं।`
                    : `This app is completely hidden from your phone launcher. All notifications and data run securely inside this sandbox.`}
                </div>

                <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800/80 font-mono text-[11px] text-emerald-400">
                  Status: Cloaked & Encrypted
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-zinc-900 border-t border-zinc-800">
              <button
                onClick={() => setLaunchedApp(null)}
                className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-300"
              >
                {t.close}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Hide New App Selector Modal */}
      {showHideSelector && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl max-w-md w-full space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <h4 className="text-sm font-bold text-zinc-100">{t.hideAnApp}</h4>
              <button onClick={() => setShowHideSelector(false)} className="text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {unhiddenApps.length === 0 ? (
                <div className="text-center py-6 text-xs text-zinc-500">
                  All apps are already hidden!
                </div>
              ) : (
                unhiddenApps.map((app) => {
                  return (
                    <div
                      key={app.id}
                      onClick={() => {
                        handleToggleHide(app);
                      }}
                      className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-rose-500/50 flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <AppIcon
                          appName={app.name}
                          packageName={app.packageName}
                          iconName={app.iconName}
                          size="compact"
                          shape="squircle"
                          showBadge={false}
                          customIconUrl={app.customIconUrl}
                        />
                        <div>
                          <div className="text-xs font-bold text-zinc-200">{app.name}</div>
                          <div className="text-[10px] text-zinc-500">{app.category}</div>
                        </div>
                      </div>
                      <span className="text-xs font-semibold text-rose-400 hover:underline">
                        {t.hide}
                      </span>
                    </div>
                  );
                })
              )}
            </div>

            <button
              onClick={() => setShowHideSelector(false)}
              className="w-full py-2.5 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300"
            >
              {t.close}
            </button>
          </div>
        </div>
      )}

      {/* Live Phone Home Screen Simulator */}
      <PhoneSimulatorModal
        isOpen={showPhoneSim}
        onClose={() => setShowPhoneSim(false)}
      />

    </div>
  );
};
