import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { AppItem } from '../../types';
import { AppIcon } from '../Launcher/AppIcon';
import {
  X,
  Wifi,
  Battery,
  Signal,
  Smartphone,
  Eye,
  EyeOff,
  Calculator as CalcIcon,
  CloudSun,
  Coins,
  FileSpreadsheet,
  QrCode,
  ShieldAlert,
  Search,
  Mic
} from 'lucide-react';
import { soundManager } from '../../utils/sound';

interface PhoneSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PhoneSimulatorModal: React.FC<PhoneSimulatorModalProps> = ({
  isOpen,
  onClose
}) => {
  const {
    apps,
    toggleAppHide,
    securitySettings,
    launcherConfig,
    language
  } = useVault();

  const [activeApp, setActiveApp] = useState<AppItem | null>(null);

  if (!isOpen) return null;

  // Calculator disguise on phone screen
  const getDisguiseConfig = () => {
    switch (securitySettings.disguiseIcon) {
      case 'weather':
        return { name: 'Weather', icon: CloudSun, bg: 'bg-sky-500' };
      case 'converter':
        return { name: 'Currency', icon: Coins, bg: 'bg-emerald-600' };
      case 'notes':
        return { name: 'Notes', icon: FileSpreadsheet, bg: 'bg-amber-500' };
      case 'scanner':
        return { name: 'Scanner', icon: QrCode, bg: 'bg-indigo-600' };
      default:
        return { name: 'Calculator', icon: CalcIcon, bg: 'bg-zinc-800' };
    }
  };

  const disguise = getDisguiseConfig();

  // Visible apps on phone home screen (apps that are NOT hidden)
  const visibleApps = apps.filter((a) => !a.isHidden);
  const hiddenApps = apps.filter((a) => a.isHidden);

  return (
    <div id="phone-simulator-overlay" className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-2 sm:p-4 backdrop-blur-md">
      <div id="phone-simulator-container" className="w-full max-w-sm h-[680px] max-h-[94vh] bg-zinc-950 border-4 border-zinc-800 rounded-[44px] shadow-2xl relative flex flex-col overflow-hidden ring-1 ring-white/20">
        
        {/* Phone Dynamic Island / Camera Notch */}
        <div className="h-7 bg-black flex items-center justify-between px-6 z-20 text-[11px] font-semibold text-white">
          <span>9:41</span>
          <div className="w-20 h-4 bg-black rounded-full border border-zinc-800 flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-zinc-900 border border-zinc-700" />
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <Battery className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Home Screen View with Wallpaper */}
        <div className="flex-1 p-4 flex flex-col justify-between relative overflow-hidden bg-gradient-to-b from-indigo-950/70 via-zinc-900 to-black">
          
          {/* Subtle Wallpaper Graphic */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-purple-800/30 via-transparent to-transparent pointer-events-none" />

          {/* Top Widget & Info */}
          <div className="space-y-3 relative z-10 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-white drop-shadow">09:41</h3>
                <p className="text-xs text-zinc-300 drop-shadow">Wednesday, Oct 24</p>
              </div>
              <button
                onClick={onClose}
                className="p-1 rounded-full bg-black/60 text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Google-Style Clean Search Widget (Stealth) */}
            <div className="px-3.5 py-2.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-2 text-zinc-300 text-xs">
                <Search className="w-3.5 h-3.5 text-zinc-400" />
                <span className="text-[11px] text-zinc-300">Google</span>
              </div>
              <Mic className="w-3.5 h-3.5 text-zinc-300" />
            </div>
          </div>

          {/* Phone App Grid */}
          <div className="grid grid-cols-4 gap-y-4 gap-x-2 py-2 relative z-10">
            
            {/* The Disguised Calculator Vault Icon */}
            <div
              onClick={() => {
                soundManager.playUnlockChime();
                onClose();
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Calculator Vault"
            >
              <AppIcon
                appName={disguise.name}
                disguiseType={securitySettings.disguiseIcon}
                size="compact"
                shape={launcherConfig.iconShape}
              />
              <span className="text-[10px] font-medium text-white truncate max-w-[56px] text-center">
                {disguise.name}
              </span>
            </div>

            {/* Visible (Unhidden) Phone Apps */}
            {visibleApps.map((app) => {
              return (
                <div
                  key={app.id}
                  onClick={() => setActiveApp(app)}
                  className="flex flex-col items-center gap-1 cursor-pointer group relative"
                >
                  <AppIcon
                    appName={app.name}
                    packageName={app.packageName}
                    iconName={app.iconName}
                    size="compact"
                    shape={launcherConfig.iconShape}
                    badgeCount={app.badgeCount}
                    showBadge={launcherConfig.showNotificationBadges}
                    customIconUrl={app.customIconUrl}
                  />
                  <span className="text-[10px] font-medium text-zinc-200 truncate max-w-[56px] text-center">
                    {app.name}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Bottom Dock */}
          <div className="relative z-10 p-2.5 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 grid grid-cols-4 gap-2">
            <div className="flex flex-col items-center justify-center">
              <AppIcon
                appName="Phone"
                packageName="com.android.dialer"
                iconName="Phone"
                size="compact"
                shape={launcherConfig.iconShape}
                showBadge={false}
              />
            </div>
            <div className="flex flex-col items-center justify-center">
              <AppIcon
                appName="Chrome"
                packageName="com.android.chrome"
                iconName="Compass"
                size="compact"
                shape={launcherConfig.iconShape}
                showBadge={false}
              />
            </div>
            <div className="flex flex-col items-center justify-center">
              <AppIcon
                appName="Messages"
                packageName="com.google.android.apps.messaging"
                iconName="MessageSquare"
                size="compact"
                shape={launcherConfig.iconShape}
                badgeCount={3}
                showBadge={launcherConfig.showNotificationBadges}
              />
            </div>
            <div className="flex flex-col items-center justify-center">
              <AppIcon
                appName="Camera"
                packageName="com.android.camera"
                iconName="Camera"
                size="compact"
                shape={launcherConfig.iconShape}
                showBadge={false}
              />
            </div>
          </div>

        </div>

        {/* Interactive App Modal (If tapped on phone) */}
        {activeApp && (
          <div className="absolute inset-0 bg-zinc-950 z-30 flex flex-col p-4 animate-in fade-in duration-150">
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <AppIcon
                  appName={activeApp.name}
                  packageName={activeApp.packageName}
                  iconName={activeApp.iconName}
                  size="compact"
                  shape={launcherConfig.iconShape}
                  showBadge={false}
                  customIconUrl={activeApp.customIconUrl}
                />
                <span className="font-bold text-white text-sm">{activeApp.name}</span>
              </div>
              <button
                onClick={() => setActiveApp(null)}
                className="p-1.5 rounded-full bg-zinc-900 text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 shadow-xl">
                <AppIcon
                  appName={activeApp.name}
                  packageName={activeApp.packageName}
                  iconName={activeApp.iconName}
                  size="large"
                  shape={launcherConfig.iconShape}
                  showBadge={false}
                  customIconUrl={activeApp.customIconUrl}
                />
              </div>
              <h4 className="font-bold text-white text-base">{activeApp.name}</h4>
              <p className="text-xs text-zinc-400 max-w-xs">
                {language === 'hi'
                  ? 'यह ऐप सामान्य रूप से चल रहा है। यदि आप इसे इस स्क्रीन से गायब करना चाहते हैं, तो वॉल्ट में जाकर "Hide" चालू करें।'
                  : 'This app is running normally. If you want it vanished from this screen, enable "Hide" in the vault.'}
              </p>
              <button
                onClick={() => {
                  toggleAppHide(activeApp.id);
                  setActiveApp(null);
                  soundManager.playClick();
                }}
                className="py-2.5 px-4 rounded-xl bg-purple-600 text-white text-xs font-semibold hover:bg-purple-500 transition-colors shadow-lg shadow-purple-600/30"
              >
                {language === 'hi' ? 'इसे अभी गायब (Hide) करें' : 'Hide This App Now'}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
