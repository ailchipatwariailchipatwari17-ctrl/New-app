import React from 'react';
import { useVault } from '../context/VaultContext';
import { VaultSection } from '../types';
import {
  Image,
  Key,
  Lock,
  EyeOff,
  ShieldAlert,
  Settings,
  Power,
  Shield,
  Smartphone,
  Monitor,
  HardDrive,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { GalleryView } from './Gallery/GalleryView';
import { NotesView } from './Notes/NotesView';
import { AppLockView } from './AppLock/AppLockView';
import { AppHideView } from './AppHide/AppHideView';
import { IntruderLogView } from './IntruderLog/IntruderLogView';
import { SettingsView } from './Settings/SettingsView';

export const VaultDashboard: React.FC = () => {
  const {
    t,
    isDecoyMode,
    activeSection,
    setActiveSection,
    lockVault,
    language,
    setLanguage,
    effectiveDeviceMode,
    setDeviceMode,
    securitySettings,
    media,
    notes,
    apps,
    intruderRecords,
    setAppViewMode,
    setIsScannerModalOpen
  } = useVault();

  const hiddenAppsCount = apps.filter((a) => a.isHidden).length;
  const lockedAppsCount = apps.filter((a) => a.isLocked).length;

  const navTabs: { id: VaultSection; label: string; icon: any; count?: number; color: string; desc: string }[] = [
    {
      id: 'gallery',
      label: t.tabGallery,
      icon: Image,
      count: media.length,
      color: 'text-purple-400',
      desc: language === 'hi' ? 'फोटो व वीडियो' : 'Encrypted Media'
    },
    {
      id: 'notes',
      label: t.tabNotes,
      icon: Key,
      count: notes.length,
      color: 'text-blue-400',
      desc: language === 'hi' ? 'पासवर्ड व सीक्रेट नोट्स' : 'Secret Notes & Passwords'
    },
    {
      id: 'applock',
      label: t.tabAppLock,
      icon: Lock,
      count: lockedAppsCount,
      color: 'text-emerald-400',
      desc: language === 'hi' ? 'पिन व पैटर्न लॉक' : 'PIN & Pattern Lock'
    },
    {
      id: 'apphide',
      label: t.tabAppHide,
      icon: EyeOff,
      count: hiddenAppsCount,
      color: 'text-rose-400',
      desc: language === 'hi' ? 'फोन से ऐप गायब करें' : 'Vanish Apps from Phone'
    },
    {
      id: 'intruder',
      label: t.tabIntruder,
      icon: ShieldAlert,
      count: intruderRecords.length,
      color: 'text-amber-400',
      desc: language === 'hi' ? 'गलत पिन अलर्ट व सेल्फी' : 'Break-in Selfie Logs'
    },
    {
      id: 'settings',
      label: t.tabSettings,
      icon: Settings,
      color: 'text-zinc-400',
      desc: language === 'hi' ? 'पिन व भेष बदलना' : 'Security & Disguise'
    }
  ];

  const isPcLayout = effectiveDeviceMode === 'pc';

  return (
    <div id="vault-dashboard-root" className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans">
      {/* Vault Top Universal Header */}
      <header className="sticky top-0 z-40 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800/80 px-4 sm:px-6 py-3 flex items-center justify-between">
        
        {/* Left: Vault Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-emerald-500 p-0.5 shadow-lg shadow-purple-600/20 flex items-center justify-center">
            <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
              <Shield className="w-5 h-5 text-emerald-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-zinc-100 tracking-tight">
                {t.vaultTitle}
              </h1>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                UNLOCKED
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 hidden sm:block">
              {language === 'hi' ? 'सीक्रेट प्राइवेट वॉल्ट और ऐप हैडर' : 'Secret Disguised Vault & App Cloaker'}
            </p>
          </div>
        </div>

        {/* Right: Device Mode Switcher, Language Toggle, and Panic Lock */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* 1:1 Stealth Clone Launcher Button */}
          <button
            id="btn-vault-open-launcher"
            onClick={() => setAppViewMode('launcher')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 active:scale-95 transition-all"
            title="Open 1:1 Stealth Clone Launcher"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{language === 'hi' ? '📱 फ़ोन स्क्रीन क्लोन' : '📱 Stealth Launcher'}</span>
          </button>

          {/* Screen Scanner Trigger */}
          <button
            id="btn-vault-scan-screen"
            onClick={() => setIsScannerModalOpen(true)}
            className="p-2 rounded-xl bg-purple-950/60 border border-purple-500/40 text-purple-300 hover:bg-purple-900/80 transition-colors"
            title="Scan & Clone Phone Screen"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
          </button>

          {/* Device Mode Switcher */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-1 flex items-center gap-1 shadow-inner text-xs">
            <button
              id="btn-vault-mode-mobile"
              onClick={() => setDeviceMode('mobile')}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-all ${
                securitySettings.deviceMode === 'mobile'
                  ? 'bg-amber-500 text-zinc-950 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="Mobile Phone View"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Mobile</span>
            </button>
            <button
              id="btn-vault-mode-pc"
              onClick={() => setDeviceMode('pc')}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-all ${
                securitySettings.deviceMode === 'pc'
                  ? 'bg-amber-500 text-zinc-950 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="PC Desktop Mode"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden md:inline">PC Mode</span>
            </button>
          </div>

          {/* Language Switcher */}
          <button
            id="btn-vault-lang-switch"
            onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
            className="px-2.5 py-1.5 text-xs font-bold rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-300 transition-colors"
          >
            {language === 'hi' ? 'EN' : 'हिन्दी'}
          </button>

          {/* PANIC SWITCH */}
          <button
            id="btn-panic-lock"
            onClick={lockVault}
            className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-lg shadow-rose-600/25 ring-2 ring-rose-500/30"
            title={t.panicLockBtn}
          >
            <Power className="w-4 h-4" />
            <span className="hidden sm:inline">{t.panicLockBtn}</span>
            <span className="sm:hidden">{language === 'hi' ? 'लॉक' : 'Lock'}</span>
          </button>
        </div>

      </header>

      {/* PC Workstation Layout vs Mobile Layout */}
      {isPcLayout ? (
        /* PC WORKSTATION MODE: Persistent Sidebar + Spacious Main Workspace */
        <div className="flex-1 flex overflow-hidden max-w-7xl mx-auto w-full px-4 py-6 gap-6">
          
          {/* Left Sidebar */}
          <aside className="w-64 shrink-0 flex flex-col gap-4">
            
            {/* Navigation Card */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-3 shadow-xl flex flex-col gap-1.5">
              <div className="px-3 py-2 text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                {language === 'hi' ? 'वॉल्ट टूल्स' : 'Vault Modules'}
              </div>
              {navTabs.map((tab) => {
                const Icon = tab.icon;
                const isSel = activeSection === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveSection(tab.id)}
                    className={`w-full px-3.5 py-2.5 rounded-2xl text-xs font-semibold text-left transition-all flex items-center justify-between group ${
                      isSel
                        ? 'bg-amber-500 text-zinc-950 font-bold shadow-lg shadow-amber-500/20'
                        : 'text-zinc-300 hover:bg-zinc-800/80 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${isSel ? 'text-zinc-950' : tab.color}`} />
                      <span>{tab.label}</span>
                    </div>
                    {tab.count !== undefined && (
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                          isSel ? 'bg-zinc-950 text-amber-400' : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Quick Security Status Card */}
            <div className="bg-zinc-900/70 border border-zinc-800/80 rounded-3xl p-4 shadow-lg text-xs space-y-2.5">
              <div className="flex items-center justify-between text-zinc-300 font-bold">
                <span className="flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
                  {language === 'hi' ? 'वॉल्ट स्थिति' : 'Vault Protection'}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold">100% Encrypted</span>
              </div>
              
              <div className="text-[11px] text-zinc-400 space-y-1">
                <div className="flex justify-between">
                  <span>{language === 'hi' ? 'फोन से छुपे ऐप्स:' : 'Cloaked Apps:'}</span>
                  <span className="font-bold text-rose-400">{hiddenAppsCount}</span>
                </div>
                <div className="flex justify-between">
                  <span>{language === 'hi' ? 'पिन/पैटर्न लॉक्ड:' : 'Locked Apps:'}</span>
                  <span className="font-bold text-emerald-400">{lockedAppsCount}</span>
                </div>
                <div className="flex justify-between">
                  <span>{language === 'hi' ? 'प्राइवेट फाइल्स:' : 'Secret Media:'}</span>
                  <span className="font-bold text-purple-400">{media.length} items</span>
                </div>
              </div>

              <button
                onClick={lockVault}
                className="w-full mt-2 py-2 rounded-xl bg-zinc-800 hover:bg-rose-600/90 text-zinc-200 hover:text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <Power className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'तुरंत कैलकुलेटर पर लौटें' : 'Return to Calculator'}</span>
              </button>
            </div>

          </aside>

          {/* Right Main Content Workspace */}
          <main className="flex-1 min-w-0 bg-zinc-900/40 border border-zinc-800/60 rounded-3xl p-6 shadow-2xl backdrop-blur-sm overflow-y-auto">
            {activeSection === 'gallery' && <GalleryView />}
            {activeSection === 'notes' && <NotesView />}
            {activeSection === 'applock' && <AppLockView />}
            {activeSection === 'apphide' && <AppHideView />}
            {activeSection === 'intruder' && <IntruderLogView />}
            {activeSection === 'settings' && <SettingsView />}
          </main>

        </div>
      ) : (
        /* MOBILE VIEW: Top horizontal scrollable tabs + Full-width Main view */
        <div className="flex-1 flex flex-col">
          
          {/* Scrollable Tab Navigation Bar */}
          <nav aria-label="Vault tabs" className="bg-zinc-900/60 border-b border-zinc-800/80 px-4 sm:px-6">
            <div className="max-w-6xl mx-auto flex items-center gap-2 overflow-x-auto py-2.5 scrollbar-none">
              {navTabs.map((tab) => {
                const Icon = tab.icon;
                const isSel = activeSection === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveSection(tab.id)}
                    className={`px-3.5 py-2 rounded-2xl text-xs font-semibold shrink-0 transition-all flex items-center gap-2 ${
                      isSel
                        ? 'bg-amber-500 text-zinc-950 font-bold shadow-md scale-105'
                        : 'bg-zinc-900/80 border border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isSel ? 'text-zinc-950' : tab.color}`} />
                    <span>{tab.label}</span>
                    {tab.count !== undefined && (
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                          isSel ? 'bg-zinc-950 text-amber-400 font-bold' : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </nav>

          {/* Main Content View Switcher */}
          <main className="flex-1 pb-12 px-3 sm:px-6 py-4">
            {activeSection === 'gallery' && <GalleryView />}
            {activeSection === 'notes' && <NotesView />}
            {activeSection === 'applock' && <AppLockView />}
            {activeSection === 'apphide' && <AppHideView />}
            {activeSection === 'intruder' && <IntruderLogView />}
            {activeSection === 'settings' && <SettingsView />}
          </main>

        </div>
      )}

    </div>
  );
};
