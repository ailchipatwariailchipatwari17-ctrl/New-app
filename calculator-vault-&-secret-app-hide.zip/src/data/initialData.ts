import { Album, AppItem, MediaItem, SecretNote, SecuritySettings } from '../types';

export const DEFAULT_SECURITY_QUESTIONS = [
  'What is the name of your first school? (आपके पहले स्कूल का नाम?)',
  'What is your pet’s name? (आपके पालतू जानवर का नाम?)',
  'What is your mother’s birthplace? (आपकी माताजी का जन्म स्थान?)',
  'What was your first childhood nickname? (बचपन का पहला निकनेम?)',
  'What is your favorite secret movie or song? (पसंदीदा गुप्त फिल्म या गाना?)'
];

export const INITIAL_SECURITY_SETTINGS: SecuritySettings = {
  pin: '4582',
  decoyPin: '0000',
  securityQuestion: DEFAULT_SECURITY_QUESTIONS[0],
  securityAnswer: 'delhi',
  isFirstTimeSetupComplete: false, // Triggers First-time PIN setup guide on clean load
  appLockType: 'pattern',
  appLockPattern: [0, 1, 2, 5, 8], // "L" or "Z" pattern: (0,0)->(0,1)->(0,2)->(1,2)->(2,2)
  appLockPin: '1234',
  disguiseIcon: 'calculator',
  enableFakeCrash: false,
  soundEnabled: true,
  hapticEnabled: true,
  intruderSelfieEnabled: true,
  theme: 'amoled',
  deviceMode: 'auto'
};

export const INITIAL_ALBUMS: Album[] = [
  { id: 'album-personal', name: 'Personal & Secret', icon: 'Lock', isSystem: true },
  { id: 'album-docs', name: 'ID & Documents', icon: 'FileText', isSystem: false },
  { id: 'album-family', name: 'Family & Trips', icon: 'Users', isSystem: false },
  { id: 'album-videos', name: 'Private Clips', icon: 'Video', isSystem: false },
];

export const INITIAL_MEDIA: MediaItem[] = [
  {
    id: 'media-1',
    type: 'image',
    name: 'Passport_Copy_Private.jpg',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&auto=format&fit=crop&q=80',
    size: 2450000,
    dateAdded: Date.now() - 86400000 * 2,
    albumId: 'album-docs',
    favorite: true
  },
  {
    id: 'media-2',
    type: 'image',
    name: 'Aadhaar_Card_Front_Back.jpg',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80',
    size: 1890000,
    dateAdded: Date.now() - 86400000 * 4,
    albumId: 'album-docs',
    favorite: false
  },
  {
    id: 'media-3',
    type: 'image',
    name: 'Secret_Vacation_Sunset.jpg',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
    size: 3200000,
    dateAdded: Date.now() - 86400000 * 1,
    albumId: 'album-personal',
    favorite: true
  },
  {
    id: 'media-4',
    type: 'image',
    name: 'Personal_Photo_Memories.jpg',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    size: 2100000,
    dateAdded: Date.now() - 86400000 * 5,
    albumId: 'album-personal',
    favorite: false
  },
  {
    id: 'media-5',
    type: 'video',
    name: 'Private_Birthday_Celebration.mp4',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&auto=format&fit=crop&q=80',
    size: 14500000,
    dateAdded: Date.now() - 86400000 * 3,
    albumId: 'album-videos',
    favorite: true
  }
];

export const INITIAL_NOTES: SecretNote[] = [
  {
    id: 'note-1',
    title: 'Bank & ATM UPI Passwords (बैंक पिन)',
    content: 'SBI Main A/C Netbanking User: kuldeep_online\nTransaction Limit: 1,00,000 INR\nBranch: New Delhi Main Branch',
    category: 'bank',
    isPinned: true,
    isFavorite: true,
    color: '#1e293b',
    createdAt: Date.now() - 86400000 * 7,
    updatedAt: Date.now() - 86400000 * 2,
    sensitiveFields: [
      { label: 'HDFC Debit Card PIN', value: '8492', isHidden: true },
      { label: 'SBI UPI PIN', value: '459021', isHidden: true },
      { label: 'CVV Code', value: '782', isHidden: true }
    ]
  },
  {
    id: 'note-2',
    title: 'Primary Google & Social Accounts',
    content: 'All recovery codes saved for two-factor authentication.\nGoogle Workspace Admin login & Github Personal Access Tokens.',
    category: 'passwords',
    isPinned: true,
    isFavorite: true,
    color: '#1e293b',
    createdAt: Date.now() - 86400000 * 5,
    updatedAt: Date.now() - 86400000 * 1,
    sensitiveFields: [
      { label: 'Gmail Secret Password', value: 'Kuld€€p#Vault2026!', isHidden: true },
      { label: 'Instagram Master Key', value: 'Insta_Secr3t$99', isHidden: true },
      { label: 'Apple ID Password', value: 'AlphaCloud#8842', isHidden: true }
    ]
  },
  {
    id: 'note-3',
    title: 'Crypto Wallet Recovery Seed (12 Words)',
    content: 'Do NOT share this with anyone online.\nStored strictly inside this offline encrypted vault.',
    category: 'crypto',
    isPinned: false,
    isFavorite: true,
    color: '#1e293b',
    createdAt: Date.now() - 86400000 * 10,
    updatedAt: Date.now() - 86400000 * 3,
    sensitiveFields: [
      { label: 'Seed Phrase', value: 'witch collapse practice feed shame open despair creek road again ice harbor', isHidden: true },
      { label: 'Binance API Secret', value: 'b287ff90aa41c88e9910d', isHidden: true }
    ]
  },
  {
    id: 'note-4',
    title: 'Secret Personal Diary & Goals 2026',
    content: '1. Launch secret side-project with 10k users.\n2. Complete marathon and maintain workout discipline.\n3. Keep financial investments diversified in SIPs and Gold bonds.\n4. Surprise family trip in December.',
    category: 'personal',
    isPinned: false,
    isFavorite: false,
    color: '#1e293b',
    createdAt: Date.now() - 86400000 * 15,
    updatedAt: Date.now() - 86400000 * 6
  }
];

export const INITIAL_APPS: AppItem[] = [
  {
    id: 'app-whatsapp',
    name: 'WhatsApp',
    packageName: 'com.whatsapp',
    category: 'Social & Chat',
    iconName: 'MessageCircle',
    iconBg: 'bg-emerald-500',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: true, // Initially hidden to showcase App Hide feature immediately!
    mockDescription: 'End-to-end encrypted chats & media',
    mockScreenType: 'chat',
    badgeCount: 4
  },
  {
    id: 'app-instagram',
    name: 'Instagram',
    packageName: 'com.instagram.android',
    category: 'Social',
    iconName: 'Camera',
    iconBg: 'bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: false,
    mockDescription: 'Photos, Reels, and direct messages',
    mockScreenType: 'feed',
    badgeCount: 2
  },
  {
    id: 'app-gallery',
    name: 'Photos / Gallery',
    packageName: 'com.android.gallery3d',
    category: 'Media',
    iconName: 'Image',
    iconBg: 'bg-blue-500',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: false,
    mockDescription: 'Device camera photos and video albums',
    mockScreenType: 'gallery'
  },
  {
    id: 'app-telegram',
    name: 'Telegram',
    packageName: 'org.telegram.messenger',
    category: 'Social & Chat',
    iconName: 'Send',
    iconBg: 'bg-sky-500',
    iconColor: 'text-white',
    isLocked: false,
    isHidden: true,
    mockDescription: 'Secret channels and cloud messages',
    mockScreenType: 'chat',
    badgeCount: 12
  },
  {
    id: 'app-gpay',
    name: 'Google Pay / Paytm',
    packageName: 'com.google.android.apps.nfc',
    category: 'Finance',
    iconName: 'CreditCard',
    iconBg: 'bg-indigo-600',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: false,
    mockDescription: 'UPI Payments, Bank transfers & QR scanning',
    mockScreenType: 'bank'
  },
  {
    id: 'app-chrome',
    name: 'Chrome Browser',
    packageName: 'com.android.chrome',
    category: 'Tools & Web',
    iconName: 'Compass',
    iconBg: 'bg-amber-500',
    iconColor: 'text-white',
    isLocked: false,
    isHidden: false,
    mockDescription: 'Fast, secure web browsing with incognito',
    mockScreenType: 'browser'
  },
  {
    id: 'app-snapchat',
    name: 'Snapchat',
    packageName: 'com.snapchat.android',
    category: 'Social',
    iconName: 'Zap',
    iconBg: 'bg-yellow-400',
    iconColor: 'text-black',
    isLocked: true,
    isHidden: true,
    mockDescription: 'Disappearing snaps and friend stories',
    mockScreenType: 'chat',
    badgeCount: 5
  },
  {
    id: 'app-dating',
    name: 'Tinder / Bumble',
    packageName: 'com.tinder',
    category: 'Dating & Social',
    iconName: 'Heart',
    iconBg: 'bg-rose-500',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: true,
    mockDescription: 'Personal matches and private conversations',
    mockScreenType: 'feed',
    badgeCount: 1
  },
  {
    id: 'app-binance',
    name: 'Binance / CoinDCX',
    packageName: 'com.binance.dev',
    category: 'Finance & Crypto',
    iconName: 'TrendingUp',
    iconBg: 'bg-yellow-600',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: true,
    mockDescription: 'Crypto portfolio and trading account',
    mockScreenType: 'bank'
  },
  {
    id: 'app-youtube',
    name: 'YouTube',
    packageName: 'com.google.android.youtube',
    category: 'Video',
    iconName: 'PlaySquare',
    iconBg: 'bg-red-600',
    iconColor: 'text-white',
    isLocked: false,
    isHidden: false,
    mockDescription: 'Video streaming and subscriptions',
    mockScreenType: 'feed'
  },
  {
    id: 'app-gmail',
    name: 'Gmail',
    packageName: 'com.google.android.gm',
    category: 'Email',
    iconName: 'Mail',
    iconBg: 'bg-red-500',
    iconColor: 'text-white',
    isLocked: false,
    isHidden: false,
    mockDescription: 'Personal & work inbox messages',
    mockScreenType: 'chat',
    badgeCount: 3
  },
  {
    id: 'app-settings',
    name: 'Phone Settings',
    packageName: 'com.android.settings',
    category: 'System',
    iconName: 'Settings',
    iconBg: 'bg-zinc-600',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: false,
    mockDescription: 'System accounts, storage and privacy',
    mockScreenType: 'settings'
  },
  {
    id: 'app-freefire',
    name: 'BGMI / Free Fire',
    packageName: 'com.dts.freefireth',
    category: 'Gaming',
    iconName: 'Zap',
    iconBg: 'bg-gradient-to-r from-orange-600 to-amber-500',
    iconColor: 'text-white',
    isLocked: true,
    isHidden: true,
    mockDescription: 'Battle royale secret gaming account & rank',
    mockScreenType: 'feed'
  },
  {
    id: 'app-netflix',
    name: 'Netflix',
    packageName: 'com.netflix.mediaclient',
    category: 'Entertainment',
    iconName: 'PlaySquare',
    iconBg: 'bg-black border border-red-600',
    iconColor: 'text-red-600',
    isLocked: false,
    isHidden: false,
    mockDescription: 'Private watch history and downloads',
    mockScreenType: 'feed'
  }
];

export const WALLPAPER_PRESETS: import('../types').WallpaperPreset[] = [
  {
    id: 's24-titanium',
    name: 'Samsung S24 Ultra Titanium',
    os: 'OneUI 6.1',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
    accentColor: '#3b82f6',
    isDark: true
  },
  {
    id: 'iphone-desert',
    name: 'iPhone 16 Pro Desert Titanium',
    os: 'iOS 18',
    url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
    accentColor: '#f59e0b',
    isDark: false
  },
  {
    id: 'pixel-obsidian',
    name: 'Google Pixel 9 Material Flow',
    os: 'Pixel UI',
    url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=1200&auto=format&fit=crop&q=80',
    accentColor: '#10b981',
    isDark: true
  },
  {
    id: 'oneplus-emerald',
    name: 'OnePlus 12 Flowy Emerald',
    os: 'OxygenOS 14',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&auto=format&fit=crop&q=80',
    accentColor: '#059669',
    isDark: true
  },
  {
    id: 'amoled-deep-black',
    name: 'Deep Minimal AMOLED (Battery Saver)',
    os: 'Universal',
    url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1200&auto=format&fit=crop&q=80',
    accentColor: '#a855f7',
    isDark: true
  },
  {
    id: 'aurora-gradient',
    name: 'Nordic Aurora Horizon',
    os: 'HyperOS',
    url: 'https://images.unsplash.com/photo-1531306728370-e2ebd9d7bb99?w=1200&auto=format&fit=crop&q=80',
    accentColor: '#06b6d4',
    isDark: true
  }
];

export const DEFAULT_LAUNCHER_CONFIG: import('../types').LauncherConfig = {
  osType: 'oneui',
  carrierName: 'Jio 5G',
  batteryLevel: 94,
  isCharging: false,
  wallpaperPreset: 's24-titanium',
  customWallpaperUrl: '',
  iconShape: 'squircle',
  iconSize: 'normal',
  gridSize: '4x5',
  showGoogleSearch: true,
  showWeatherWidget: true,
  showDynamicIsland: true,
  showNotificationBadges: true,
  secretDialCode: '*#4582#',
  secretClockTapEnabled: true,
  gestureSwipeUpEnabled: true,
  gestureSwipeDownEnabled: true
};
