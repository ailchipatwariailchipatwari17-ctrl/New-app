export type Language = 'hi' | 'en';

export type DeviceMode = 'auto' | 'mobile' | 'pc';

export type LockType = 'pin' | 'pattern' | 'biometric';

export interface SecuritySettings {
  pin: string; // default e.g. "4582"
  decoyPin: string; // e.g. "0000" for fake vault
  securityQuestion: string;
  securityAnswer: string;
  isFirstTimeSetupComplete: boolean;
  appLockType: LockType;
  appLockPattern: number[]; // e.g. [0, 1, 2, 5, 8]
  appLockPin: string;
  disguiseIcon: 'calculator' | 'weather' | 'converter' | 'notes' | 'scanner';
  enableFakeCrash: boolean;
  soundEnabled: boolean;
  hapticEnabled: boolean;
  intruderSelfieEnabled: boolean;
  theme: 'dark' | 'amoled' | 'ios' | 'retro';
  deviceMode: DeviceMode;
}

export type MediaType = 'image' | 'video';

export interface MediaItem {
  id: string;
  type: MediaType;
  name: string;
  url: string; // base64 or blob url
  thumbnailUrl?: string;
  size: number;
  dateAdded: number;
  albumId: string;
  favorite?: boolean;
}

export interface Album {
  id: string;
  name: string;
  icon?: string;
  coverUrl?: string;
  isSystem?: boolean;
}

export type NoteCategory = 'passwords' | 'bank' | 'personal' | 'crypto' | 'work' | 'general';

export interface SecretNote {
  id: string;
  title: string;
  content: string;
  category: NoteCategory;
  isPinned: boolean;
  isFavorite: boolean;
  color: string;
  createdAt: number;
  updatedAt: number;
  sensitiveFields?: { label: string; value: string; isHidden: boolean }[];
}

export interface AppItem {
  id: string;
  name: string;
  packageName: string;
  category: string;
  iconName: string;
  iconBg: string;
  iconColor: string;
  isLocked: boolean;
  isHidden: boolean; // hidden from phone home screen
  mockDescription?: string;
  mockScreenType: 'chat' | 'feed' | 'gallery' | 'browser' | 'settings' | 'bank' | 'default';
  customIconUrl?: string;
  badgeCount?: number;
}

export interface IntruderRecord {
  id: string;
  timestamp: number;
  reason: 'wrong_pin' | 'wrong_pattern' | 'fake_crash_trigger' | 'unauthorized_attempt';
  capturedImage?: string;
  attemptedPin?: string;
  appName?: string;
}

export type VaultSection = 'gallery' | 'notes' | 'applock' | 'apphide' | 'intruder' | 'settings' | 'launcher' | 'phone_sim';

export type AppViewMode = 'calculator' | 'vault' | 'launcher';

export type OSType = 'oneui' | 'ios' | 'pixel' | 'oxygen' | 'hyperos' | 'nothing';

export type IconShape = 'squircle' | 'rounded' | 'circle' | 'teardrop';

export type GridSize = '4x5' | '4x6' | '5x6';

export interface LauncherConfig {
  osType: OSType;
  carrierName: string; // e.g. "Jio 5G", "Airtel 5G"
  batteryLevel: number; // 0-100
  isCharging: boolean;
  wallpaperPreset: string; // id of preset wallpaper
  customWallpaperUrl?: string; // base64 or custom uploaded URL
  iconShape: IconShape;
  iconSize: 'compact' | 'normal' | 'large';
  gridSize: GridSize;
  showGoogleSearch: boolean;
  showWeatherWidget: boolean;
  showDynamicIsland: boolean;
  showNotificationBadges: boolean;
  secretDialCode: string; // e.g. "*#4582#"
  secretClockTapEnabled: boolean;
  gestureSwipeUpEnabled: boolean;
  gestureSwipeDownEnabled: boolean;
}

export interface WallpaperPreset {
  id: string;
  name: string;
  os: string;
  url: string;
  accentColor: string;
  isDark: boolean;
}
