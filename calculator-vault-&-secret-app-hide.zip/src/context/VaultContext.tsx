import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  Album,
  AppItem,
  AppViewMode,
  IntruderRecord,
  Language,
  LauncherConfig,
  MediaItem,
  SecretNote,
  SecuritySettings,
  VaultSection
} from '../types';
import {
  DEFAULT_LAUNCHER_CONFIG,
  INITIAL_ALBUMS,
  INITIAL_APPS,
  INITIAL_MEDIA,
  INITIAL_NOTES,
  INITIAL_SECURITY_SETTINGS
} from '../data/initialData';
import {
  clearAllMedia,
  deleteMediaItem,
  getAllMediaItems,
  saveMediaItem
} from '../storage/db';
import { soundManager } from '../utils/sound';
import { translations } from '../utils/translations';

interface HistoryItem {
  id: string;
  expr: string;
  res: string;
  timestamp: number;
}

interface VaultContextType {
  isUnlocked: boolean;
  isDecoyMode: boolean;
  language: Language;
  t: typeof translations.hi;
  activeSection: VaultSection;
  securitySettings: SecuritySettings;
  effectiveDeviceMode: 'mobile' | 'pc';
  media: MediaItem[];
  albums: Album[];
  notes: SecretNote[];
  apps: AppItem[];
  intruderRecords: IntruderRecord[];
  history: HistoryItem[];
  showSetupModal: boolean;
  showRecoveryModal: boolean;
  showFakeCrashModal: boolean;
  appViewMode: AppViewMode;
  launcherConfig: LauncherConfig;
  isScannerModalOpen: boolean;
  selectedAppForCrash: AppItem | null;
  
  // Actions
  unlockVault: (enteredPin: string) => boolean;
  lockVault: () => void;
  setLanguage: (lang: Language) => void;
  setActiveSection: (section: VaultSection) => void;
  updateSecuritySettings: (newSettings: Partial<SecuritySettings>) => void;
  setDeviceMode: (mode: 'auto' | 'mobile' | 'pc') => void;
  setAppViewMode: (mode: AppViewMode) => void;
  updateLauncherConfig: (config: Partial<LauncherConfig>) => void;
  setIsScannerModalOpen: (open: boolean) => void;
  setSelectedAppForCrash: (app: AppItem | null) => void;
  toggleFullscreen: () => void;
  
  // Media actions
  addMediaItem: (item: MediaItem) => Promise<void>;
  removeMediaItem: (id: string) => Promise<void>;
  toggleMediaFavorite: (id: string) => void;
  addAlbum: (name: string, icon?: string) => void;
  
  // Notes actions
  addOrUpdateNote: (note: SecretNote) => void;
  deleteNote: (id: string) => void;
  toggleNotePin: (id: string) => void;
  toggleNoteFavorite: (id: string) => void;
  
  // App Lock & App Hide actions
  toggleAppLock: (id: string) => void;
  toggleAppHide: (id: string) => void;
  setAllAppsLocked: (locked: boolean) => void;
  addCustomApp: (app: Omit<AppItem, 'id'>) => void;
  
  // History & Security
  addHistoryItem: (expr: string, res: string) => void;
  clearHistory: () => void;
  recordIntruder: (reason: IntruderRecord['reason'], attemptedPin?: string, appName?: string, capturedImage?: string) => void;
  clearIntruderLogs: () => void;
  
  // Modal controls
  setShowSetupModal: (show: boolean) => void;
  setShowRecoveryModal: (show: boolean) => void;
  setShowFakeCrashModal: (show: boolean) => void;
  resetAllData: () => Promise<void>;
}

const VaultContext = createContext<VaultContextType | undefined>(undefined);

export const VaultProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [isDecoyMode, setIsDecoyMode] = useState<boolean>(false);
  const [appViewMode, setAppViewMode] = useState<AppViewMode>('calculator');
  const [language, setLangState] = useState<Language>(() => {
    const saved = localStorage.getItem('calc_vault_lang');
    return (saved === 'en' || saved === 'hi') ? saved : 'hi';
  });

  const [activeSection, setActiveSection] = useState<VaultSection>('gallery');

  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>(() => {
    try {
      const saved = localStorage.getItem('calc_vault_security');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_SECURITY_SETTINGS;
  });

  const [launcherConfig, setLauncherConfig] = useState<LauncherConfig>(() => {
    try {
      const saved = localStorage.getItem('calc_vault_launcher_cfg');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_LAUNCHER_CONFIG;
  });

  const [albums, setAlbums] = useState<Album[]>(() => {
    try {
      const saved = localStorage.getItem('calc_vault_albums');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_ALBUMS;
  });

  const [notes, setNotes] = useState<SecretNote[]>(() => {
    try {
      const saved = localStorage.getItem('calc_vault_notes');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_NOTES;
  });

  const [apps, setApps] = useState<AppItem[]>(() => {
    try {
      const saved = localStorage.getItem('calc_vault_apps');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_APPS;
  });

  const [intruderRecords, setIntruderRecords] = useState<IntruderRecord[]>(() => {
    try {
      const saved = localStorage.getItem('calc_vault_intruders');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('calc_vault_calc_history');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  const [media, setMedia] = useState<MediaItem[]>([]);
  const [showSetupModal, setShowSetupModal] = useState<boolean>(false);
  const [showRecoveryModal, setShowRecoveryModal] = useState<boolean>(false);
  const [showFakeCrashModal, setShowFakeCrashModal] = useState<boolean>(false);
  const [isScannerModalOpen, setIsScannerModalOpen] = useState<boolean>(false);
  const [selectedAppForCrash, setSelectedAppForCrash] = useState<AppItem | null>(null);
  const [windowWidth, setWindowWidth] = useState<number>(() => typeof window !== 'undefined' ? window.innerWidth : 1200);

  // Read real battery status if available in browser
  useEffect(() => {
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        const updateBattery = () => {
          setLauncherConfig((prev) => ({
            ...prev,
            batteryLevel: Math.round(battery.level * 100),
            isCharging: battery.charging
          }));
        };
        updateBattery();
        battery.addEventListener('levelchange', updateBattery);
        battery.addEventListener('chargingchange', updateBattery);
      }).catch(() => {});
    }
  }, []);

  // Track window resize for auto device mode
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const effectiveDeviceMode: 'mobile' | 'pc' = 
    securitySettings.deviceMode === 'mobile' 
      ? 'mobile' 
      : securitySettings.deviceMode === 'pc' 
      ? 'pc' 
      : windowWidth >= 1024 
      ? 'pc' 
      : 'mobile';

  // Check on initial mount for first time setup
  useEffect(() => {
    const dismissed = localStorage.getItem('calc_vault_first_setup_dismissed');
    if (!securitySettings.isFirstTimeSetupComplete && !dismissed) {
      const timer = setTimeout(() => {
        setShowSetupModal(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [securitySettings.isFirstTimeSetupComplete]);

  // Load IndexedDB media on mount
  useEffect(() => {
    async function loadMedia() {
      const stored = await getAllMediaItems();
      if (stored && stored.length > 0) {
        setMedia(stored);
      } else {
        // seed initial media
        for (const item of INITIAL_MEDIA) {
          await saveMediaItem(item);
        }
        setMedia(INITIAL_MEDIA);
      }
    }
    loadMedia();
  }, []);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('calc_vault_security', JSON.stringify(securitySettings));
  }, [securitySettings]);

  useEffect(() => {
    localStorage.setItem('calc_vault_launcher_cfg', JSON.stringify(launcherConfig));
  }, [launcherConfig]);

  useEffect(() => {
    localStorage.setItem('calc_vault_albums', JSON.stringify(albums));
  }, [albums]);

  useEffect(() => {
    localStorage.setItem('calc_vault_notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('calc_vault_apps', JSON.stringify(apps));
  }, [apps]);

  useEffect(() => {
    localStorage.setItem('calc_vault_intruders', JSON.stringify(intruderRecords));
  }, [intruderRecords]);

  useEffect(() => {
    localStorage.setItem('calc_vault_calc_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('calc_vault_lang', language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLangState(lang);
  };

  const t = translations[language];

  const updateSecuritySettings = (newSettings: Partial<SecuritySettings>) => {
    setSecuritySettings((prev) => ({ ...prev, ...newSettings }));
  };

  const updateLauncherConfig = (config: Partial<LauncherConfig>) => {
    setLauncherConfig((prev) => ({ ...prev, ...config }));
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const unlockVault = (enteredPin: string): boolean => {
    const cleanPin = enteredPin.replace(/[^0-9]/g, '');
    
    // Check main PIN
    if (cleanPin === securitySettings.pin) {
      if (securitySettings.enableFakeCrash) {
        setShowFakeCrashModal(true);
        return false;
      }
      setIsUnlocked(true);
      setIsDecoyMode(false);
      if (securitySettings.soundEnabled) soundManager.playUnlockChime();
      return true;
    }

    // Check Decoy PIN
    if (securitySettings.decoyPin && cleanPin === securitySettings.decoyPin) {
      setIsUnlocked(true);
      setIsDecoyMode(true);
      if (securitySettings.soundEnabled) soundManager.playUnlockChime();
      return true;
    }

    // Check emergency recovery code 11223344
    if (cleanPin === '11223344') {
      setShowRecoveryModal(true);
      return false;
    }

    return false;
  };

  const lockVault = () => {
    setIsUnlocked(false);
    setIsDecoyMode(false);
    if (securitySettings.soundEnabled) soundManager.playLockTone();
  };

  const addMediaItem = async (item: MediaItem) => {
    await saveMediaItem(item);
    setMedia((prev) => [item, ...prev]);
  };

  const removeMediaItem = async (id: string) => {
    await deleteMediaItem(id);
    setMedia((prev) => prev.filter((m) => m.id !== id));
  };

  const toggleMediaFavorite = (id: string) => {
    setMedia((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const updated = { ...m, favorite: !m.favorite };
          saveMediaItem(updated);
          return updated;
        }
        return m;
      })
    );
  };

  const addAlbum = (name: string, icon: string = 'Folder') => {
    const newAlbum: Album = {
      id: `album-${Date.now()}`,
      name,
      icon,
      isSystem: false
    };
    setAlbums((prev) => [...prev, newAlbum]);
  };

  const addOrUpdateNote = (note: SecretNote) => {
    setNotes((prev) => {
      const exists = prev.some((n) => n.id === note.id);
      if (exists) {
        return prev.map((n) => (n.id === note.id ? note : n));
      }
      return [note, ...prev];
    });
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const toggleNotePin = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isPinned: !n.isPinned } : n))
    );
  };

  const toggleNoteFavorite = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isFavorite: !n.isFavorite } : n))
    );
  };

  const toggleAppLock = (id: string) => {
    setApps((prev) =>
      prev.map((a) => (a.id === id ? { ...a, isLocked: !a.isLocked } : a))
    );
  };

  const toggleAppHide = (id: string) => {
    setApps((prev) =>
      prev.map((a) => (a.id === id ? { ...a, isHidden: !a.isHidden } : a))
    );
  };

  const setAllAppsLocked = (locked: boolean) => {
    setApps((prev) => prev.map((a) => ({ ...a, isLocked: locked })));
  };

  const setDeviceMode = (mode: 'auto' | 'mobile' | 'pc') => {
    updateSecuritySettings({ deviceMode: mode });
  };

  const addCustomApp = (appData: Omit<AppItem, 'id'>) => {
    const newApp: AppItem = {
      ...appData,
      id: `custom-app-${Date.now()}`
    };
    setApps((prev) => [newApp, ...prev]);
  };

  const addHistoryItem = (expr: string, res: string) => {
    const item: HistoryItem = {
      id: `hist-${Date.now()}-${Math.random()}`,
      expr,
      res,
      timestamp: Date.now()
    };
    setHistory((prev) => [item, ...prev].slice(0, 50));
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const recordIntruder = (
    reason: IntruderRecord['reason'],
    attemptedPin?: string,
    appName?: string,
    capturedImage?: string
  ) => {
    const record: IntruderRecord = {
      id: `intruder-${Date.now()}`,
      timestamp: Date.now(),
      reason,
      attemptedPin,
      appName,
      capturedImage
    };
    setIntruderRecords((prev) => [record, ...prev].slice(0, 100));
  };

  const clearIntruderLogs = () => {
    setIntruderRecords([]);
  };

  const resetAllData = async () => {
    await clearAllMedia();
    setMedia([]);
    setAlbums(INITIAL_ALBUMS);
    setNotes([]);
    setApps(INITIAL_APPS);
    setIntruderRecords([]);
    setHistory([]);
    setSecuritySettings(INITIAL_SECURITY_SETTINGS);
    setIsUnlocked(false);
  };

  return (
    <VaultContext.Provider
      value={{
        isUnlocked,
        isDecoyMode,
        language,
        t,
        activeSection,
        securitySettings,
        effectiveDeviceMode,
        media: isDecoyMode ? [] : media,
        albums: isDecoyMode ? [] : albums,
        notes: isDecoyMode ? [] : notes,
        apps,
        intruderRecords,
        history,
        showSetupModal,
        showRecoveryModal,
        showFakeCrashModal,
        appViewMode,
        launcherConfig,
        isScannerModalOpen,
        selectedAppForCrash,
        unlockVault,
        lockVault,
        setLanguage,
        setActiveSection,
        updateSecuritySettings,
        setDeviceMode,
        setAppViewMode,
        updateLauncherConfig,
        setIsScannerModalOpen,
        setSelectedAppForCrash,
        toggleFullscreen,
        addMediaItem,
        removeMediaItem,
        toggleMediaFavorite,
        addAlbum,
        addOrUpdateNote,
        deleteNote,
        toggleNotePin,
        toggleNoteFavorite,
        toggleAppLock,
        toggleAppHide,
        setAllAppsLocked,
        addCustomApp,
        addHistoryItem,
        clearHistory,
        recordIntruder,
        clearIntruderLogs,
        setShowSetupModal,
        setShowRecoveryModal,
        setShowFakeCrashModal,
        resetAllData
      }}
    >
      {children}
    </VaultContext.Provider>
  );
};

export const useVault = (): VaultContextType => {
  const context = useContext(VaultContext);
  if (!context) {
    throw new Error('useVault must be used within a VaultProvider');
  }
  return context;
};
