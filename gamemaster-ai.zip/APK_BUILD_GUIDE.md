# 📱 AutoPlay AI - APK निर्माण और ZIP एक्सपोर्ट गाइड (APK Build & ZIP Guide)

इस ZIP फाइल में वह सारा सोर्स कोड, कॉन्फ़िगरेशन और कंपोनेंट्स मौजूद हैं जिससे आप 2 मिनट में अपने मोबाइल के लिए **Android APK** बना सकते हैं।

---

## 🚀 विकल्प 1: Website Builder / PWA Builder से 1-क्लिक में APK बनाएं (सबसे आसान)

1. इस प्रोजेक्ट को रन करके या डिप्लॉय करके उसका URL लें, अथवा `npm run build` के बाद बने `dist` फोल्डर को होस्ट करें।
2. **[PWABuilder.com](https://www.pwabuilder.com/)** वेबसाइट पर जाएं।
3. अपने ऐप का लिंक डालें (इसमें `manifest.json` और `icon.svg` पहले से कॉन्फिगर कर दिए गए हैं)।
4. **"Generate Android APK"** पर क्लिक करें। आपको सीधे साइन किया हुआ `.apk` डाउनलोड मिल जाएगा।

---

## ⚡ विकल्प 2: Capacitor (Native Android Studio Project) से APK बनाना

यदि आप इस ZIP फाइल से सीधे Android Studio के ज़रिए Native APK बनाना चाहते हैं:

### Step 1: Dependencies इंस्टॉल करें
```bash
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "AutoPlay AI" "com.autoplay.gamebot" --web-dir dist
```

### Step 2: प्रोजेक्ट बिल्ड करें
```bash
npm run build
npx cap add android
npx cap sync
```

### Step 3: APK जनरेट करें
```bash
npx cap open android
```
- Android Studio खुलेगा -> **Build > Build Bundle(s) / APK(s) > Build APK(s)** पर क्लिक करें।
- आपका `.apk` तैयार होकर `android/app/build/outputs/apk/debug/app-debug.apk` में मिल जाएगा।

---

## 🛠️ प्रोजेक्ट संरचना (Project Structure in this ZIP)
- `index.html`: PWA, मोबाइल मेटा टैग्स और व्यू-पोर्ट सपोर्ट के साथ मुख्य एंट्री।
- `public/manifest.json`: Android ऐप पैकेजिंग के लिए वेब ऐप मैनिफेस्ट।
- `public/icon.svg`: हाई-रेज़ोल्यूशन गेमिंग बॉट ऐप आइकन।
- `src/`: पूरा React, TypeScript, AI गेम बॉट सिमुलेशन, मोबाइल कंपनियन ब्रिज और टेलीमेट्री हब।
- `server.ts`: Gemini AI कमांडर और बैकएंड एपीआई रूट।
- `package.json`: सभी आवश्यक डिपेंडेंसी और बिल्ड स्क्रिप्ट्स।
