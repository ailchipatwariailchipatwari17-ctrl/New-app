import { GameBotState, BotLog, OfflineReport, ItemDrop } from '../types';

const STORAGE_KEY = 'autoplay_ai_games_v3';
const LAST_ACTIVE_KEY = 'autoplay_ai_last_active_v3';

const RANDOM_LOOT_NAMES = [
  { name: 'Plasma Katana +5', rarity: 'legendary' as const, bonus: '+60% Crit Strike' },
  { name: 'Quantum Core Drill', rarity: 'epic' as const, bonus: '+45% Resource Velocity' },
  { name: 'Hyper-Phase Boots', rarity: 'rare' as const, bonus: '+30% Speed Multiplier' },
  { name: 'Apex Aegis Shield', rarity: 'legendary' as const, bonus: '+500 Health Pool' },
  { name: 'Neural Overclock Chip', rarity: 'epic' as const, bonus: '+100 APM Execution' },
  { name: 'Cosmic Star Shard', rarity: 'rare' as const, bonus: '+25% Exp Multiplier' },
  { name: 'Dark Matter Catalyst', rarity: 'legendary' as const, bonus: '+200% Passive Coins' },
  { name: 'Prismatic Block Matrix', rarity: 'legendary' as const, bonus: '+50% Blast Combo Multiplier' },
  { name: 'Dragon Frenzy Sensei Blade', rarity: 'legendary' as const, bonus: '+100% Fruit Slice Velocity' }
];

let logCounter = 0;
function generateUniqueLogId(prefix: string, gameId?: string): string {
  logCounter = (logCounter + 1) % 1000000;
  return `${prefix}_${Date.now()}_${logCounter}_${gameId || 'g'}_${Math.random().toString(36).substring(2, 7)}`;
}

export function tickGame(
  game: GameBotState,
  deltaSeconds: number,
  onLog?: (log: BotLog) => void
): { updatedGame: GameBotState; leveledUp: boolean; bossKilled: boolean } {
  if (game.status === 'paused') {
    return { updatedGame: game, leveledUp: false, bossKilled: false };
  }

  // 1. Timer / Duration Check
  let targetDurationHours = game.targetDurationHours;
  let remainingSeconds = game.remainingSeconds;

  if (targetDurationHours !== null && targetDurationHours !== undefined && targetDurationHours > 0) {
    if (remainingSeconds === null || remainingSeconds === undefined) {
      remainingSeconds = targetDurationHours * 3600;
    }

    remainingSeconds -= deltaSeconds;

    if (remainingSeconds <= 0) {
      // Time completed! Auto-pause
      if (onLog) {
        onLog({
          id: generateUniqueLogId('log_timer', game.id),
          timestamp: Date.now(),
          messageHindi: `⏰ समय सीमा पूर्ण! ${game.nameHindi} ने निर्धारित ${targetDurationHours} घंटे का गेमप्ले पूरा कर लिया और सुरक्षित रुक गया।`,
          messageEnglish: `⏰ Session Timer Complete! ${game.name} completed the set ${targetDurationHours}h duration and safely paused.`,
          type: 'timer',
          gameId: game.id
        });
      }
      return {
        updatedGame: {
          ...game,
          status: 'paused',
          remainingSeconds: 0
        },
        leveledUp: false,
        bossKilled: false
      };
    }
  }

  const speed = Math.max(1, game.speedMultiplier || 1);
  const effectiveDelta = deltaSeconds * speed;

  let scoreGainRate = 30; // base score per sec
  let expGainRate = 18; // base exp per sec
  let coinsGainRate = 10;
  let crystalChance = 0.06 * effectiveDelta;

  // Category specific tweaks
  if (game.category === 'block_blast') {
    scoreGainRate = 45;
    expGainRate = 22;
  } else if (game.category === 'fruit_ninja') {
    scoreGainRate = 50;
    expGainRate = 24;
  }

  // Strategy adjustments
  switch (game.strategy) {
    case 'aggressive_xp':
      expGainRate *= 2.4;
      scoreGainRate *= 2.0;
      coinsGainRate *= 0.9;
      break;
    case 'boss_hunter':
      scoreGainRate *= 2.2;
      expGainRate *= 1.5;
      crystalChance *= 2.8;
      break;
    case 'gold_farmer':
      coinsGainRate *= 3.0;
      scoreGainRate *= 1.3;
      expGainRate *= 1.1;
      break;
    case 'survival_safe':
      scoreGainRate *= 1.2;
      expGainRate *= 1.2;
      break;
    case 'overclock':
      scoreGainRate *= 3.5;
      expGainRate *= 3.0;
      coinsGainRate *= 3.0;
      break;
    case 'balanced':
    default:
      scoreGainRate *= 1.5;
      expGainRate *= 1.5;
      coinsGainRate *= 1.5;
      break;
  }

  // Level scaling
  const levelMultiplier = 1 + game.level * 0.09;
  const gainedScore = Math.floor(scoreGainRate * effectiveDelta * levelMultiplier);
  const gainedExp = Math.floor(expGainRate * effectiveDelta * levelMultiplier);
  const gainedCoins = Math.floor(coinsGainRate * effectiveDelta * levelMultiplier);

  let newScore = game.score + gainedScore;
  let newHighScore = Math.max(game.highScore, newScore);
  let newCoins = game.coins + gainedCoins;
  let newCrystals = game.crystals + (Math.random() < crystalChance ? 1 : 0);
  let newUptime = game.uptimeSeconds + Math.floor(effectiveDelta);

  let newExp = game.exp + gainedExp;
  let newLevel = game.level;
  let newMaxExp = game.maxExp;
  let leveledUp = false;

  // Check Level Up
  while (newExp >= newMaxExp) {
    newExp -= newMaxExp;
    newLevel += 1;
    newMaxExp = Math.floor(newMaxExp * 1.22);
    leveledUp = true;

    // Auto-allocate skill points
    game.skills.strength += 1;
    game.skills.agility += 1;
    game.skills.intelligence += 1;
    game.skills.vitality += 1;

    let specialLevelMsgHindi = `🎉 लेवल अप! ${game.nameHindi} अब लेवल ${newLevel} पर पहुंच गया!`;
    let specialLevelMsgEn = `🎉 LEVEL UP! ${game.name} reached Level ${newLevel}!`;

    if (game.category === 'block_blast') {
      specialLevelMsgHindi = `🧩 ब्लॉक ब्लास्ट लेवल पार! AI ने 8x8 ग्रिड क्लियर कर लेवल ${newLevel} क्रैक किया (+स्कोर मल्टीप्लायर)!`;
      specialLevelMsgEn = `🧩 Block Blast Level Cleared! AI solved 8x8 grid and crossed Level ${newLevel}!`;
    } else if (game.category === 'fruit_ninja') {
      specialLevelMsgHindi = `🍉 फ्रूट निंजा डोजो अपग्रेड! AI ने बिना बम छुए डोजो स्टेज पार कर लेवल ${newLevel} हासिल किया!`;
      specialLevelMsgEn = `🍉 Fruit Ninja Stage Cleared! AI sliced all combos & advanced to Level ${newLevel}!`;
    }

    if (onLog) {
      onLog({
        id: generateUniqueLogId('log_lvl', game.id),
        timestamp: Date.now(),
        messageHindi: specialLevelMsgHindi,
        messageEnglish: specialLevelMsgEn,
        type: 'level_up',
        gameId: game.id
      });
    }
  }

  // Boss Battle Simulation
  let bossKilled = false;
  let newBossesDefeated = game.bossesDefeated;
  let currentBossHealth = game.currentBossHealth || 2000;
  let maxBossHealth = game.maxBossHealth || 2000;

  const bossDamage = Math.floor(
    (game.skills.strength * 4 + game.skills.intelligence * 3) *
      effectiveDelta *
      (game.strategy === 'boss_hunter' ? 2.5 : 1.3)
  );
  currentBossHealth -= bossDamage;

  if (currentBossHealth <= 0) {
    bossKilled = true;
    newBossesDefeated += 1;
    maxBossHealth = Math.floor(maxBossHealth * 1.35);
    currentBossHealth = maxBossHealth;
    newScore += 6000 * newLevel;
    newCoins += 2000 * newLevel;
    newCrystals += 5 + Math.floor(newLevel / 2);

    // Give random boss item drop
    const randomLoot = RANDOM_LOOT_NAMES[Math.floor(Math.random() * RANDOM_LOOT_NAMES.length)];
    const newItem: ItemDrop = {
      id: generateUniqueLogId('loot', game.id),
      name: `${randomLoot.name} [Tier ${newBossesDefeated}]`,
      rarity: randomLoot.rarity,
      bonus: randomLoot.bonus
    };

    if (game.inventory.length < 8) {
      game.inventory.push(newItem);
    } else {
      game.inventory[0] = newItem; // replace
    }

    if (onLog) {
      onLog({
        id: generateUniqueLogId('log_boss', game.id),
        timestamp: Date.now(),
        messageHindi: `⚔️ बॉस ढेर! ${game.bossName || 'स्टेज बॉस'} को AI ने परास्त किया! (+6,000 स्कोर, +लूट ${newItem.name})`,
        messageEnglish: `⚔️ BOSS DEFEATED! AI vanquished ${game.bossName || 'Stage Boss'}! (+6,000 Score, +${newItem.name})`,
        type: 'boss',
        gameId: game.id
      });
    }
  }

  // Simulation position animations & metrics
  const sim = { ...game.simulationParams };
  sim.heroX = (sim.heroX + Math.floor(Math.random() * 9 - 4) + 300) % 300;
  sim.heroY = (sim.heroY + Math.floor(Math.random() * 9 - 4) + 200) % 200;
  if (sim.oresMined !== undefined) sim.oresMined += Math.floor(3 * effectiveDelta);
  if (sim.distanceMeters !== undefined) sim.distanceMeters += Math.floor(55 * effectiveDelta);
  if (sim.blocksCleared !== undefined) sim.blocksCleared += Math.floor(6 * effectiveDelta);
  if (sim.comboLines !== undefined && Math.random() < 0.15 * effectiveDelta) sim.comboLines += 1;
  if (sim.fruitsSliced !== undefined) sim.fruitsSliced += Math.floor(8 * effectiveDelta);
  if (sim.bombsDodged !== undefined && Math.random() < 0.2 * effectiveDelta) sim.bombsDodged += 1;

  // Occasional specific action logs for Block Blast & Fruit Ninja
  if (Math.random() < 0.06 * deltaSeconds && onLog) {
    if (game.category === 'block_blast') {
      const lines = Math.floor(Math.random() * 3) + 2;
      onLog({
        id: generateUniqueLogId('log_bb', game.id),
        timestamp: Date.now(),
        messageHindi: `🧩 AI ने 8x8 ग्रिड में ${lines}-लाइन सुपर कॉम्बो ब्लास्ट किया! (+${lines * 350} कॉम्बो बोनस)`,
        messageEnglish: `🧩 AI triggered a ${lines}-Line Super Blast combo on 8x8 grid! (+${lines * 350} combo bonus)`,
        type: 'combat',
        gameId: game.id
      });
    } else if (game.category === 'fruit_ninja') {
      const fruits = Math.floor(Math.random() * 4) + 3;
      onLog({
        id: generateUniqueLogId('log_fn', game.id),
        timestamp: Date.now(),
        messageHindi: `🍉 AI ने बिना किसी बम छुए ${fruits} फलों का ड्रैगन कॉम्बो स्लाइस किया!`,
        messageEnglish: `🍉 AI executed a flawless ${fruits}-Fruit Blitz Combo with 0 bomb contact!`,
        type: 'combat',
        gameId: game.id
      });
    }
  }

  const updated: GameBotState = {
    ...game,
    targetDurationHours,
    remainingSeconds,
    score: newScore,
    highScore: newHighScore,
    exp: newExp,
    maxExp: newMaxExp,
    level: newLevel,
    coins: newCoins,
    crystals: newCrystals,
    uptimeSeconds: newUptime,
    bossesDefeated: newBossesDefeated,
    currentBossHealth,
    maxBossHealth,
    lastTickTime: Date.now(),
    actionsPerMinute: Math.min(
      700,
      Math.floor(220 + game.level * 9 + Math.random() * 40 * speed)
    ),
    simulationParams: sim
  };

  return { updatedGame: updated, leveledUp, bossKilled };
}

export function calculateOfflineProgression(
  games: GameBotState[],
  lastActiveTime: number
): { updatedGames: GameBotState[]; report: OfflineReport | null } {
  const now = Date.now();
  const timeAwaySeconds = Math.max(0, Math.floor((now - lastActiveTime) / 1000));

  // If away for less than 10 seconds, don't show large offline modal
  if (timeAwaySeconds < 10) {
    return { updatedGames: games, report: null };
  }

  // Cap maximum offline farming time to 24 hours (86400 seconds) for realism
  const cappedSeconds = Math.min(timeAwaySeconds, 86400);

  let totalScoreGained = 0;
  let totalExpGained = 0;
  let totalLevelsGained = 0;
  let totalGoldGained = 0;
  let totalCrystalsGained = 0;
  let totalBossesGained = 0;

  const breakdowns: OfflineReport['gamesBreakdown'] = [];

  const updatedGames = games.map((game) => {
    if (game.status === 'paused') return game;

    // If game had a timer remaining, cap offline seconds to that remaining time
    let playableSeconds = cappedSeconds;
    if (game.targetDurationHours && game.remainingSeconds !== null && game.remainingSeconds > 0) {
      playableSeconds = Math.min(cappedSeconds, game.remainingSeconds);
    }

    const initialScore = game.score;
    const initialLevel = game.level;
    const initialGold = game.coins;

    // Simulation of playable seconds
    const simulated = tickGame(game, playableSeconds);
    const updated = simulated.updatedGame;

    const scoreDiff = updated.score - initialScore;
    const levelDiff = updated.level - initialLevel;
    const goldDiff = updated.coins - initialGold;
    const crystalDiff = updated.crystals - game.crystals;
    const bossesDiff = updated.bossesDefeated - game.bossesDefeated;

    totalScoreGained += scoreDiff;
    totalLevelsGained += levelDiff;
    totalGoldGained += goldDiff;
    totalCrystalsGained += crystalDiff;
    totalBossesGained += bossesDiff;
    totalExpGained += levelDiff * 1000 + (updated.exp - game.exp);

    breakdowns.push({
      gameId: game.id,
      name: game.name,
      nameHindi: game.nameHindi,
      scoreGained: scoreDiff,
      levelsGained: levelDiff,
      goldGained: goldDiff
    });

    return updated;
  });

  const report: OfflineReport = {
    timeAwaySeconds,
    totalScoreGained,
    totalExpGained,
    levelsGained: totalLevelsGained,
    goldGained: totalGoldGained,
    crystalsGained: totalCrystalsGained,
    bossesDefeatedGained: totalBossesGained,
    gamesBreakdown: breakdowns
  };

  return { updatedGames, report };
}

export function saveGameStateToStorage(games: GameBotState[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(games));
    localStorage.setItem(LAST_ACTIVE_KEY, Date.now().toString());
  } catch (err) {
    console.error('Failed to save to localStorage:', err);
  }
}

export function loadGameStateFromStorage(): { games: GameBotState[] | null; lastActiveTime: number } {
  if (typeof window === 'undefined') return { games: null, lastActiveTime: Date.now() };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const lastActiveRaw = localStorage.getItem(LAST_ACTIVE_KEY);
    const lastActiveTime = lastActiveRaw ? parseInt(lastActiveRaw, 10) : Date.now();

    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return { games: parsed, lastActiveTime };
      }
    }
  } catch (err) {
    console.error('Failed to load from localStorage:', err);
  }
  return { games: null, lastActiveTime: Date.now() };
}
