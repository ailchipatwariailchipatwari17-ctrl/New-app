import { GameBotState } from '../types';

export const INITIAL_GAMES: GameBotState[] = [
  {
    id: 'game_block_blast',
    name: 'Block Blast: Neural Puzzle Master',
    nameHindi: 'ब्लॉक ब्लास्ट: AI पजल मास्टर (Block Blast)',
    category: 'block_blast',
    description: 'AI calculates 8x8 optimal block placements, triggers massive multi-line combo blasts, and crosses levels endlessly.',
    descriptionHindi: 'AI 8x8 ग्रिड में सबसे बेहतरीन जगह ब्लॉक रखता है, मल्टी-लाइन ब्लास्ट कॉम्बो बनाता है और बिना मरे लगातार लेवल पार करता है।',
    status: 'active',
    level: 18,
    exp: 640,
    maxExp: 1400,
    score: 84200,
    highScore: 84200,
    coins: 7800,
    crystals: 95,
    bossesDefeated: 6,
    bossName: 'Master Grid Overlord (Level 20 Challenge)',
    currentBossHealth: 1200,
    maxBossHealth: 3000,
    actionsPerMinute: 340,
    speedMultiplier: 2,
    strategy: 'aggressive_xp',
    customDirectives: [
      'Always prioritize 3+ line combo clear',
      'Keep 3x3 open spaces for mega block shapes',
      'Chain consecutive blast streaks for 10x score multiplier'
    ],
    uptimeSeconds: 4800,
    targetDurationHours: null, // null = खेलता ही रहे (Infinite 24/7)
    remainingSeconds: null,
    autoUpgrade: true,
    botConfidence: 100,
    skills: {
      strength: 14,
      agility: 28,
      intelligence: 36,
      vitality: 20
    },
    inventory: [
      { id: 'item_bb_1', name: 'Prismatic Block Matrix', rarity: 'legendary', bonus: '+50% Blast Combo Points' },
      { id: 'item_bb_2', name: 'Infinite Undo Gem', rarity: 'epic', bonus: 'Auto-Revive on Deadlock' }
    ],
    lastTickTime: Date.now(),
    simulationParams: {
      heroX: 140,
      heroY: 100,
      monstersCount: 0,
      multiplier: 3.8,
      currentWave: 18,
      blocksCleared: 3420,
      comboLines: 48
    }
  },
  {
    id: 'game_fruit_ninja',
    name: 'Fruit Ninja: Cyber Blade Dojo',
    nameHindi: 'फ्रूट निंजा: AI साइबर ब्लेड (Fruit Ninja)',
    category: 'fruit_ninja',
    description: 'Sub-millisecond blade slashes all flying fruits, triggers Dragon Breath frenzy, and dodges 100% of bombs.',
    descriptionHindi: 'AI मिलीसेकंड स्पीड से सभी फलों को काटता है, कॉम्बो स्ट्रीक बनाता है और बम से बचकर लगातार नए लेवल पार करता है।',
    status: 'active',
    level: 22,
    exp: 820,
    maxExp: 1800,
    score: 126500,
    highScore: 126500,
    coins: 12400,
    crystals: 140,
    bossesDefeated: 8,
    bossName: 'Sensei Bomb Titan (Stage Boss)',
    currentBossHealth: 2200,
    maxBossHealth: 4500,
    actionsPerMinute: 520,
    speedMultiplier: 3,
    strategy: 'aggressive_xp',
    customDirectives: [
      '100% Avoid Bomb Contact',
      'Slice 4+ fruits simultaneously for Blitz Combo',
      'Instantly trigger Frenzy & Freeze Bananas'
    ],
    uptimeSeconds: 6200,
    targetDurationHours: null, // null = लगातार 24/7
    remainingSeconds: null,
    autoUpgrade: true,
    botConfidence: 99,
    skills: {
      strength: 16,
      agility: 42,
      intelligence: 24,
      vitality: 18
    },
    inventory: [
      { id: 'item_fn_1', name: 'Rainbow Plasma Blade', rarity: 'legendary', bonus: '+80% Critical Fruit Slice' },
      { id: 'item_fn_2', name: 'Pomegranate Siphon Dojo', rarity: 'epic', bonus: '+35% Coin Yield' }
    ],
    lastTickTime: Date.now(),
    simulationParams: {
      heroX: 160,
      heroY: 120,
      monstersCount: 0,
      multiplier: 4.5,
      currentWave: 22,
      fruitsSliced: 5120,
      bombsDodged: 410
    }
  },
  {
    id: 'game_dungeon_rpg',
    name: 'Cyber Dungeon: Abyss Slayer',
    nameHindi: 'साइबर डंगियन: एबिस स्लेयर (RPG)',
    category: 'dungeon_rpg',
    description: 'AI Hero navigates dangerous dungeon floors, casts spells, slays demons, and auto-equips legendary armor.',
    descriptionHindi: 'AI हीरो ऑटो-नेविगेट करता है, मॉन्स्टर्स को मारता है, हथियार अपग्रेड करता है और बॉस से लड़ता है।',
    status: 'active',
    level: 12,
    exp: 420,
    maxExp: 1000,
    score: 18450,
    highScore: 18450,
    coins: 3420,
    crystals: 48,
    bossesDefeated: 4,
    bossName: 'Abyss Lord Malakor',
    currentBossHealth: 1500,
    maxBossHealth: 2500,
    actionsPerMinute: 240,
    speedMultiplier: 2,
    strategy: 'aggressive_xp',
    customDirectives: ['Prioritize high XP mobs', 'Auto-use health potion below 30%', 'Cast Frost Nova on groups'],
    uptimeSeconds: 3600,
    targetDurationHours: null,
    remainingSeconds: null,
    autoUpgrade: true,
    botConfidence: 98,
    skills: {
      strength: 18,
      agility: 14,
      intelligence: 22,
      vitality: 16
    },
    inventory: [
      { id: 'item_1', name: 'Plasma Katana +3', rarity: 'epic', bonus: '+35% Critical Dmg' },
      { id: 'item_2', name: 'Nano Shield Vest', rarity: 'rare', bonus: '+200 Shield Pool' }
    ],
    lastTickTime: Date.now(),
    simulationParams: {
      heroX: 120,
      heroY: 150,
      monstersCount: 6,
      multiplier: 1.5,
      currentWave: 14
    }
  },
  {
    id: 'game_space_miner',
    name: 'Galactic Ore Fleet & Asteroid Miner',
    nameHindi: 'गैलेक्टिक स्पेस माइनर एवं फ्लीट',
    category: 'space_miner',
    description: 'AI manages mining drones, harvests rare dark matter asteroids, and upgrades planetary warp drills.',
    descriptionHindi: 'AI माइनिंग ड्रोन को नियंत्रित करता है, एस्टेरॉयड से डार्क मैटर निकालता है और फ्लीट अपग्रेड करता है।',
    status: 'active',
    level: 9,
    exp: 780,
    maxExp: 1200,
    score: 29800,
    highScore: 29800,
    coins: 8900,
    crystals: 112,
    bossesDefeated: 2,
    bossName: 'Cosmic Dreadnought Pirate',
    currentBossHealth: 3200,
    maxBossHealth: 4000,
    actionsPerMinute: 310,
    speedMultiplier: 3,
    strategy: 'gold_farmer',
    customDirectives: ['Overclock drill lasers', 'Auto-deploy defense drones during pirate attack'],
    uptimeSeconds: 5200,
    targetDurationHours: null,
    remainingSeconds: null,
    autoUpgrade: true,
    botConfidence: 95,
    skills: {
      strength: 12,
      agility: 20,
      intelligence: 19,
      vitality: 15
    },
    inventory: [
      { id: 'item_3', name: 'Quantum Core Drill', rarity: 'legendary', bonus: '+80% Mining Speed' }
    ],
    lastTickTime: Date.now(),
    simulationParams: {
      heroX: 180,
      heroY: 100,
      monstersCount: 4,
      multiplier: 2.0,
      currentWave: 9,
      dronesCount: 8,
      oresMined: 1420
    }
  },
  {
    id: 'game_cyber_runner',
    name: 'Neon Cyber Runner 2099',
    nameHindi: 'नियॉन साइबर रनर 2099',
    category: 'cyber_runner',
    description: 'Sub-millisecond AI reaction bot dodging laser walls, triggering hyper-drives, and chaining score combos.',
    descriptionHindi: 'अल्ट्रा-फास्ट AI लेजर दीवारों से बचता है, हाइपरड्राइव चालू करता है और अनस्टॉपेबल कॉम्बो बनाता है।',
    status: 'active',
    level: 16,
    exp: 210,
    maxExp: 1500,
    score: 54200,
    highScore: 54200,
    coins: 5600,
    crystals: 75,
    bossesDefeated: 5,
    bossName: 'Cyber Sentinel Tank',
    currentBossHealth: 800,
    maxBossHealth: 5000,
    actionsPerMinute: 480,
    speedMultiplier: 2,
    strategy: 'balanced',
    customDirectives: ['Maintain 10x Combo', 'Auto-glide through high-risk photon rings'],
    uptimeSeconds: 7400,
    targetDurationHours: null,
    remainingSeconds: null,
    autoUpgrade: true,
    botConfidence: 99,
    skills: {
      strength: 10,
      agility: 34,
      intelligence: 15,
      vitality: 12
    },
    inventory: [
      { id: 'item_4', name: 'Hyper-Phase Boots', rarity: 'epic', bonus: '+50% Dash Invulnerability' }
    ],
    lastTickTime: Date.now(),
    simulationParams: {
      heroX: 80,
      heroY: 180,
      monstersCount: 8,
      multiplier: 3.5,
      currentWave: 22,
      distanceMeters: 48500,
      combosCount: 38
    }
  },
  {
    id: 'game_empire_tycoon',
    name: 'Quantum Realm Empire Tycoon',
    nameHindi: 'क्वांटम एम्पायर टाइकून',
    category: 'empire_tycoon',
    description: 'AI calculates optimal mathematical ROI, re-invests profits automatically, and auto-prestige resets.',
    descriptionHindi: 'AI गणितीय फॉर्मूले से खुद पैसिव इनकम बढ़ाता है, बिल्डिंग्स अपग्रेड करता है और स्कोर मल्टीप्लाई करता है।',
    status: 'active',
    level: 21,
    exp: 950,
    maxExp: 2000,
    score: 112000,
    highScore: 112000,
    coins: 45000,
    crystals: 230,
    bossesDefeated: 7,
    bossName: 'Market Monolith Core',
    currentBossHealth: 12000,
    maxBossHealth: 20000,
    actionsPerMinute: 180,
    speedMultiplier: 4,
    strategy: 'gold_farmer',
    customDirectives: ['Reinvest 80% profits into Quantum Generators', 'Auto-Prestige at 5x multiplier threshold'],
    uptimeSeconds: 12400,
    targetDurationHours: null,
    remainingSeconds: null,
    autoUpgrade: true,
    botConfidence: 100,
    skills: {
      strength: 14,
      agility: 12,
      intelligence: 38,
      vitality: 18
    },
    inventory: [
      { id: 'item_5', name: 'Infinity Multiplier Matrix', rarity: 'legendary', bonus: '+150% Global Passive Yield' }
    ],
    lastTickTime: Date.now(),
    simulationParams: {
      heroX: 150,
      heroY: 120,
      monstersCount: 2,
      multiplier: 5.2,
      currentWave: 35
    }
  }
];
