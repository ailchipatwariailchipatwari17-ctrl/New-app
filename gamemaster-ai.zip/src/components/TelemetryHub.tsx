import React, { useState, useEffect } from 'react';
import { Activity, ShieldAlert, Cpu, Sparkles, Terminal, RefreshCw, Zap, TrendingUp } from 'lucide-react';
import { BotLog, GameBotState } from '../types';
import { playSound } from '../utils/audio';

interface TelemetryHubProps {
  logs: BotLog[];
  activeGames: GameBotState[];
  language: 'hi' | 'en';
}

export const TelemetryHub: React.FC<TelemetryHubProps> = ({
  logs,
  activeGames,
  language
}) => {
  const [advisorData, setAdvisorData] = useState<{
    hindiTips: string[];
    englishTips: string[];
    estimatedSynergyMultiplier: string;
    statusSummary: string;
  } | null>(null);
  const [isLoadingTips, setIsLoadingTips] = useState(false);

  const isHindi = language === 'hi';

  const fetchAdvisorTips = async () => {
    setIsLoadingTips(true);
    try {
      const res = await fetch('/api/ai/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ activeGames })
      });
      const data = await res.json();
      if (data.analysis) {
        setAdvisorData(data.analysis);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingTips(false);
    }
  };

  useEffect(() => {
    fetchAdvisorTips();
    const interval = setInterval(fetchAdvisorTips, 35000); // refresh every 35s
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-4 sm:px-6">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Left: AI Tactical Advisor & Synergy Matrix */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg backdrop-blur-md lg:col-span-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-cyan-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                {isHindi ? 'AI न्यूरल सलाहकार (Synergy & Strategy Optimizer)' : 'Neural Strategy Optimizer'}
              </h3>
            </div>
            <button
              onClick={() => {
                playSound('click');
                fetchAdvisorTips();
              }}
              disabled={isLoadingTips}
              className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
            >
              <RefreshCw className={`h-3 w-3 ${isLoadingTips ? 'animate-spin text-cyan-400' : ''}`} />
              <span>{isHindi ? 'रीफ्रेश' : 'Refresh'}</span>
            </button>
          </div>

          <div className="mt-3 space-y-2.5">
            {advisorData ? (
              <>
                <div className="flex items-center justify-between rounded-xl border border-cyan-500/20 bg-cyan-950/20 p-2.5 text-xs">
                  <span className="text-cyan-300 font-medium">
                    {isHindi ? 'मल्टी-गेम सिनर्जी मल्टीप्लायर:' : 'Multi-Game Synergy Multiplier:'}
                  </span>
                  <span className="rounded bg-cyan-500/20 px-2 py-0.5 font-mono font-bold text-cyan-300">
                    {advisorData.estimatedSynergyMultiplier || '3.5x'}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {(isHindi ? advisorData.hindiTips : advisorData.englishTips || []).map((tip, i) => (
                    <div key={i} className="flex items-start gap-2 rounded-lg bg-slate-950/60 p-2 text-xs text-slate-300">
                      <Zap className="h-3.5 w-3.5 mt-0.5 shrink-0 text-amber-400" />
                      <span>{tip}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex h-24 items-center justify-center text-xs text-slate-500">
                <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                {isHindi ? 'AI रणनीति का विश्लेषण हो रहा है...' : 'Analyzing fleet optimization...'}
              </div>
            )}
          </div>
        </div>

        {/* Right: Live Real-time Bot Execution Logs */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg backdrop-blur-md lg:col-span-6 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-emerald-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                {isHindi ? 'लाइव AI एक्शन स्ट्रीम (Live Bot Activity)' : 'Live Bot Action Stream'}
              </h3>
            </div>
            <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
              {isHindi ? 'रियल-टाइम लॉग' : 'Real-time'}
            </span>
          </div>

          <div className="mt-3 h-36 overflow-y-auto space-y-1.5 font-mono text-[11px]">
            {logs.length === 0 ? (
              <div className="text-slate-500 text-center py-6">
                {isHindi ? 'AI बॉट्स बैकग्राउंड में सक्रिय हैं...' : 'AI bots active in background...'}
              </div>
            ) : (
              logs.slice(0, 15).map((log, idx) => (
                <div
                  key={`${log.id || 'log'}_${idx}`}
                  className={`flex items-center justify-between rounded px-2 py-1 ${
                    log.type === 'level_up'
                      ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/30'
                      : log.type === 'boss'
                      ? 'bg-rose-950/40 text-rose-300 border border-rose-500/30'
                      : 'bg-slate-950/50 text-slate-300'
                  }`}
                >
                  <span className="truncate mr-2">
                    {isHindi ? log.messageHindi : log.messageEnglish}
                  </span>
                  <span className="text-[9px] text-slate-500 shrink-0">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
