import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Smartphone,
  Zap,
  ShieldCheck,
  BatteryCharging,
  Clock,
  Infinity as InfinityIcon,
  Play,
  CheckCircle2,
  Cpu,
  Flame,
  Swords,
  Layers,
  Touchpad,
  Award,
  Globe
} from 'lucide-react';
import { GameBotState, GameCategory } from '../types';
import { playSound } from '../utils/audio';

export interface GameSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmLaunch: (game: GameBotState) => void;
  initialTemplate?: {
    name: string;
    nameHindi: string;
    category: GameCategory;
    description: string;
    descriptionHindi: string;
    packageName?: string;
    bossName?: string;
    initialScore?: number;
    speed?: number;
  } | null;
  language: 'hi' | 'en';
}

export const GameSetupModal: React.FC<GameSetupModalProps> = ({
  isOpen,
  onClose,
  onConfirmLaunch,
  initialTemplate,
  language
}) => {
  const isHindi = language === 'hi';

  // State options
  const [playModeGoal, setPlayModeGoal] = useState<'slice_only' | 'level_up' | 'boss_rush' | 'resource_farm' | 'endless_score'>('slice_only');
  const [touchProfile, setTouchProfile] = useState<'human_like' | 'robotic_lightning' | 'stealth_anti_ban'>('human_like');
  const [batterySavingMode, setBatterySavingMode] = useState<'ultra_saver' | 'balanced' | 'performance'>('ultra_saver');
  const [executionTarget, setExecutionTarget] = useState<'phone_installed_app' | 'browser_simulation'>('phone_installed_app');
  const [targetDurationHours, setTargetDurationHours] = useState<number | null>(null);
  const [customHours, setCustomHours] = useState<string>('');
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(3);

  if (!isOpen || !initialTemplate) return null;

  const isFruitNinja = initialTemplate.category === 'fruit_ninja' || initialTemplate.name.toLowerCase().includes('fruit');
  const isBlockBlast = initialTemplate.category === 'block_blast' || initialTemplate.name.toLowerCase().includes('block');

  const handleStartGame = () => {
    playSound('levelup');

    const resolvedDuration = customHours && parseFloat(customHours) > 0 ? parseFloat(customHours) : targetDurationHours;

    // Directives based on user choices
    const customDirectives: string[] = [];
    if (playModeGoal === 'slice_only') {
      customDirectives.push(isFruitNinja ? 'Prioritize non-stop fruit slicing & pure combo streaks' : 'Focus purely on board clearing and relaxed score');
    } else if (playModeGoal === 'level_up') {
      customDirectives.push('Aggressively complete all level quests, star fruits & rush stages');
    } else if (playModeGoal === 'boss_rush') {
      customDirectives.push('Target Boss health and execute power moves');
    } else {
      customDirectives.push('Maximize coins, crystals and drop collection');
    }

    if (touchProfile === 'human_like') {
      customDirectives.push('Human-like Bezier curves & 210ms organic reaction delay active');
    } else if (touchProfile === 'robotic_lightning') {
      customDirectives.push('Sub-millisecond blitz slicing mode');
    } else {
      customDirectives.push('Stealth coordinate jitter enabled to prevent any detection');
    }

    if (batterySavingMode === 'ultra_saver') {
      customDirectives.push('Screen-Off OLED Black Background Saver Active (-75% Battery)');
    }

    if (executionTarget === 'phone_installed_app') {
      customDirectives.push(`Direct Touch Injection into installed phone app [${initialTemplate.packageName || 'com.game.app'}]`);
    }

    const newBot: GameBotState = {
      id: `bot_${initialTemplate.category}_${Date.now()}`,
      name: executionTarget === 'phone_installed_app' ? `${initialTemplate.name} [Phone App]` : initialTemplate.name,
      nameHindi: executionTarget === 'phone_installed_app' ? `${initialTemplate.nameHindi} [फोन ऐप सिंक]` : initialTemplate.nameHindi,
      category: initialTemplate.category,
      description: `${initialTemplate.description} (${executionTarget === 'phone_installed_app' ? 'Running on Downloaded Mobile App via Accessibility' : 'Running in Hub Engine'})`,
      descriptionHindi: `${initialTemplate.descriptionHindi} (${executionTarget === 'phone_installed_app' ? 'फोन में डाउनलोड किए गए गेम में ऑटो-टच एक्टिव' : 'वेब सिमुलेटर'})`,
      status: 'active',
      level: 1,
      exp: 0,
      maxExp: 500,
      score: initialTemplate.initialScore || 10000,
      highScore: initialTemplate.initialScore || 10000,
      coins: 2000,
      crystals: 30,
      bossesDefeated: 0,
      bossName: initialTemplate.bossName || 'Grand Dojo Master',
      currentBossHealth: 2000,
      maxBossHealth: 2000,
      actionsPerMinute: touchProfile === 'human_like' ? 240 : touchProfile === 'robotic_lightning' ? 480 : 180,
      speedMultiplier: speedMultiplier,
      strategy: playModeGoal === 'level_up' ? 'aggressive_xp' : playModeGoal === 'boss_rush' ? 'boss_hunter' : playModeGoal === 'resource_farm' ? 'gold_farmer' : 'balanced',
      customDirectives,
      uptimeSeconds: 0,
      targetDurationHours: resolvedDuration,
      remainingSeconds: resolvedDuration ? resolvedDuration * 3600 : null,
      autoUpgrade: true,
      botConfidence: 99,
      playModeGoal,
      touchProfile,
      batterySavingMode,
      executionTarget,
      phonePackageName: initialTemplate.packageName || 'com.halfbrick.fruitninja',
      skills: {
        strength: 15,
        agility: touchProfile === 'human_like' ? 18 : 25,
        intelligence: 20,
        vitality: 15
      },
      inventory: [
        {
          id: `gear_${Date.now()}`,
          name: touchProfile === 'human_like' ? 'Organic Human Swipe Driver' : 'Cybernetic Lightning Slicer',
          rarity: 'legendary',
          bonus: touchProfile === 'human_like' ? '+99.8% Human Mimicry & Anti-Ban' : '+50% Cut Speed'
        }
      ],
      lastTickTime: Date.now(),
      simulationParams: {
        heroX: 120,
        heroY: 100,
        monstersCount: 4,
        multiplier: 2.0,
        currentWave: 1,
        fruitsSliced: isFruitNinja ? 100 : undefined,
        bombsDodged: isFruitNinja ? 20 : undefined,
        blocksCleared: isBlockBlast ? 60 : undefined
      }
    };

    onConfirmLaunch(newBot);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
      <div className="relative max-h-[95vh] w-full max-w-3xl overflow-y-auto rounded-3xl border border-emerald-500/40 bg-slate-950 p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 text-2xl shadow-lg shadow-emerald-500/20">
              {isFruitNinja ? '🍉' : isBlockBlast ? '🧩' : '🎮'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white sm:text-xl">
                  {isHindi
                    ? `${initialTemplate.nameHindi} - गेम मोड व ऑटो-प्ले सेटअप`
                    : `${initialTemplate.name} - Mode & Autoplay Setup`}
                </h2>
                <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400">
                  {isHindi ? 'पूरी तरह कस्टमाइजेबल' : 'Customizable'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {isHindi
                  ? 'चुनें कि AI को केवल फ्रूट काटना है या लेवल बढ़ाना है, इंसानों जैसा टच कैसा रहे और बैटरी सेविंग मोड।'
                  : 'Configure game goal (slice only vs level-up), human-like touch profile, battery saver & target device.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-slate-700 bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* SECTION 1: EXECUTION TARGET (PHONE INSTALLED APP VS BROWSER) */}
        <div className="mt-5 rounded-2xl border border-cyan-500/40 bg-gradient-to-r from-cyan-950/40 to-slate-900/60 p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-cyan-400" />
              <label className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                {isHindi ? '1. गेम कहाँ खेलना है? (Where to Play):' : '1. Where to Execute Game:'}
              </label>
            </div>
            <span className="text-[11px] font-mono text-emerald-400">
              ✓ {isHindi ? 'फोन पर डाउनलोड किए हुए में खेले' : 'Play in Downloaded Mobile App'}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div
              onClick={() => {
                playSound('click');
                setExecutionTarget('phone_installed_app');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                executionTarget === 'phone_installed_app'
                  ? 'border-cyan-400 bg-cyan-950/70 shadow-lg shadow-cyan-950/40'
                  : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Smartphone className="h-4 w-4 text-cyan-400" />
                  {isHindi ? '📱 फोन पर डाउनलोड किए हुए ऐप में' : '📱 Downloaded Phone App (Real Mobile)'}
                </span>
                {executionTarget === 'phone_installed_app' && (
                  <CheckCircle2 className="h-4 w-4 text-cyan-400" />
                )}
              </div>
              <p className="text-[11px] text-slate-300">
                {isHindi
                  ? 'AI आपके मोबाइल फोन की स्क्रीन पर वास्तविक Fruit Ninja / Block Blast ऐप में लाइव टच स्वाइप करेगा।'
                  : 'AI sends touch strokes directly into your real Android / iOS installed game via accessibility bridge.'}
              </p>
            </div>

            <div
              onClick={() => {
                playSound('click');
                setExecutionTarget('browser_simulation');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                executionTarget === 'browser_simulation'
                  ? 'border-emerald-400 bg-emerald-950/70 shadow-lg shadow-emerald-950/40'
                  : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Globe className="h-4 w-4 text-emerald-400" />
                  {isHindi ? '💻 वेब हब सिमुलेटर में' : '💻 Web Hub Simulator'}
                </span>
                {executionTarget === 'browser_simulation' && (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                )}
              </div>
              <p className="text-[11px] text-slate-300">
                {isHindi
                  ? 'वेब ब्राउज़र के अंदर हाई-स्पीड सिमुलेशन इंजन पर खेलेगा।'
                  : 'Runs inside the web dashboard simulation sandbox.'}
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 2: GAME MODE GOAL (कोनसा मोड खेलना है: बस फ्रूट काटना vs लेवल बढ़ाना) */}
        <div className="mt-5 space-y-2">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
            {isHindi ? '2. आपको कौन सा मोड खेलना है? (Game Mode Goal):' : '2. Which Game Mode Goal to Play:'}
          </label>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {/* Mode 1: Slice only */}
            <div
              onClick={() => {
                playSound('click');
                setPlayModeGoal('slice_only');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                playModeGoal === 'slice_only'
                  ? 'border-emerald-500 bg-emerald-950/40 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>🍉</span>
                  {isFruitNinja
                    ? (isHindi ? 'बस फ्रूट काटने हैं (Zen & Non-Stop Slicing)' : 'Just Slice Fruits (Zen Flow)')
                    : (isHindi ? 'बस स्कोर व बोर्ड क्लियर करना है (Relaxed Score)' : 'Relaxed High Score Mode')}
                </h4>
                {playModeGoal === 'slice_only' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-400">
                {isHindi
                  ? 'AI बिना किसी जल्दबाजी के सभी फलों को 100% काटता रहेगा और बम से पूरी तरह बचकर हाई स्कोर बनाएगा।'
                  : 'AI continuously slices all fruits with 100% precision, 0 bombs hit, and maximum combo chains.'}
              </p>
            </div>

            {/* Mode 2: Level up */}
            <div
              onClick={() => {
                playSound('click');
                setPlayModeGoal('level_up');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                playModeGoal === 'level_up'
                  ? 'border-emerald-500 bg-emerald-950/40 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>🚀</span>
                  {isHindi ? 'लेवल बढ़ाने हैं / स्टेज पार करने हैं (Fast Level Up)' : 'Fast Level Up & Stage Rush'}
                </h4>
                {playModeGoal === 'level_up' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-400">
                {isHindi
                  ? 'AI तेजी से XP, गोल्डन फ्रूट्स, स्टार मिशन्स और स्टेज टास्क पूरे करके लगातार नए लेवल अनलॉक करेगा।'
                  : 'Aggressively targets XP milestones, star challenges, and clears stages to rank up levels rapidly.'}
              </p>
            </div>

            {/* Mode 3: Boss rush */}
            <div
              onClick={() => {
                playSound('click');
                setPlayModeGoal('boss_rush');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                playModeGoal === 'boss_rush'
                  ? 'border-emerald-500 bg-emerald-950/40 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>👑</span>
                  {isHindi ? 'बॉस हंटर / मास्टर डोज़ो (Dojo Master Boss Battle)' : 'Dojo Master & Boss Battles'}
                </h4>
                {playModeGoal === 'boss_rush' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-400">
                {isHindi
                  ? 'स्पेशल ड्रैगन फ्रूट्स, बड़े डोज़ो बॉस और टाइटन चैलेंज को टारगेट करके दुर्लभ क्रिस्टल जीतेगा।'
                  : 'Fights giant boss encounters, triggers Dragon frenzy slashes, and claims rare epic loot.'}
              </p>
            </div>

            {/* Mode 4: Resource Farm */}
            <div
              onClick={() => {
                playSound('click');
                setPlayModeGoal('resource_farm');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                playModeGoal === 'resource_farm'
                  ? 'border-emerald-500 bg-emerald-950/40 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>🪙</span>
                  {isHindi ? 'गोल्ड व कॉइन्स फार्मिंग (Starfruit & Coins Farm)' : 'Starfruit & Currency Farming'}
                </h4>
                {playModeGoal === 'resource_farm' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-400">
                {isHindi
                  ? 'स्टारफ्रूट, इन-गेम गोल्ड और गियर अपग्रेड के लिए सिक्के ज्यादा से ज्यादा बटोरेगा।'
                  : 'Farms starfruits, coins and upgrades blades/dojos automatically.'}
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 3: TOUCH & SWIPE STYLE (इंसानों जैसा लगे / Human-like vs Robotic) */}
        <div className="mt-5 space-y-2">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
            {isHindi ? '3. स्वाइप व टच स्टाइल (इंसानों जैसा स्वाइप):' : '3. Touch & Swipe Style (Human-like vs Robotic):'}
          </label>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
            {/* Option A: Human-like */}
            <div
              onClick={() => {
                playSound('click');
                setTouchProfile('human_like');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                touchProfile === 'human_like'
                  ? 'border-cyan-400 bg-cyan-950/50 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1">
                  <span>👤</span>
                  {isHindi ? 'इंसानों जैसा नैचुरल टच' : 'Human-like Natural'}
                </h4>
                {touchProfile === 'human_like' && <CheckCircle2 className="h-4 w-4 text-cyan-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">
                {isHindi
                  ? 'प्राकृतिक कर्व स्वाइप्स (Organic Bezier arcs), 210ms इंसानी रिएक्शन टाइम, बिल्कुल प्रो गेमर जैसा दिखेगा।'
                  : 'Natural curved swipes with organic 210ms human reaction time. 99.8% indistinguishable from a pro human.'}
              </p>
              <span className="mt-2 inline-block rounded bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-bold text-emerald-400">
                ✓ {isHindi ? 'एंटी-चीट से 100% सुरक्षित' : 'Zero Detection'}
              </span>
            </div>

            {/* Option B: Robotic Blitz */}
            <div
              onClick={() => {
                playSound('click');
                setTouchProfile('robotic_lightning');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                touchProfile === 'robotic_lightning'
                  ? 'border-cyan-400 bg-cyan-950/50 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1">
                  <span>⚡</span>
                  {isHindi ? 'रोबोटिक लाइटनिंग (0ms)' : 'Robotic Lightning (0ms)'}
                </h4>
                {touchProfile === 'robotic_lightning' && <CheckCircle2 className="h-4 w-4 text-cyan-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">
                {isHindi
                  ? 'अल्ट्रा-फास्ट 0.1ms इंस्टेंट स्वाइप। स्क्रीन पर आते ही तुरंत फल कट जाएंगे।'
                  : 'Sub-millisecond blitz slicing. Slices the exact frame a fruit spawns.'}
              </p>
              <span className="mt-2 inline-block rounded bg-amber-500/10 px-1.5 py-0.5 text-[10px] font-bold text-amber-400">
                ⚡ {isHindi ? 'अधिकतम गति' : 'Max APM'}
              </span>
            </div>

            {/* Option C: Stealth Anti-ban */}
            <div
              onClick={() => {
                playSound('click');
                setTouchProfile('stealth_anti_ban');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                touchProfile === 'stealth_anti_ban'
                  ? 'border-cyan-400 bg-cyan-950/50 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1">
                  <span>🛡️</span>
                  {isHindi ? 'स्टील्थ एंटी-बैन शील्ड' : 'Stealth Anti-Ban Shield'}
                </h4>
                {touchProfile === 'stealth_anti_ban' && <CheckCircle2 className="h-4 w-4 text-cyan-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">
                {isHindi
                  ? 'रैंडमाइज्ड कोऑर्डिनेट्स और पॉज ताकि किसी भी सर्वर को पता न चले।'
                  : 'Randomized touch coordinates with variable human micro-pauses.'}
              </p>
              <span className="mt-2 inline-block rounded bg-cyan-500/10 px-1.5 py-0.5 text-[10px] font-bold text-cyan-400">
                🛡️ {isHindi ? '100% सेफ' : 'Max Safety'}
              </span>
            </div>
          </div>
        </div>

        {/* SECTION 4: BATTERY SAVING MODE (बैटरी सेविंग) */}
        <div className="mt-5 space-y-2">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <BatteryCharging className="h-4 w-4 text-emerald-400" />
            {isHindi ? '4. बैटरी सेविंग प्रोफाइल (Battery Saver Profile):' : '4. Battery Saving Profile:'}
          </label>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
            {/* Saver 1: Ultra Saver */}
            <div
              onClick={() => {
                playSound('click');
                setBatterySavingMode('ultra_saver');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                batterySavingMode === 'ultra_saver'
                  ? 'border-emerald-500 bg-emerald-950/50 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1">
                  <span>🔋</span>
                  {isHindi ? 'अल्ट्रा बैटरी सेवर (-75% खपत)' : 'Ultra Saver (-75% Drain)'}
                </h4>
                {batterySavingMode === 'ultra_saver' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">
                {isHindi
                  ? 'स्क्रीन-ऑफ OLED ब्लैक मोड, फोन में सिर्फ 2% बैटरी/घंटा की खपत, कोई हीटिंग नहीं।'
                  : 'Screen-off OLED black overlay with eco CPU clock. Only ~2% battery/hour and zero overheating.'}
              </p>
            </div>

            {/* Saver 2: Balanced */}
            <div
              onClick={() => {
                playSound('click');
                setBatterySavingMode('balanced');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                batterySavingMode === 'balanced'
                  ? 'border-emerald-500 bg-emerald-950/50 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1">
                  <span>⚖️</span>
                  {isHindi ? 'बैलेंस्ड मोड (60 FPS)' : 'Balanced Mode (60 FPS)'}
                </h4>
                {batterySavingMode === 'balanced' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">
                {isHindi
                  ? 'स्मूथ 60 FPS स्वाइप और सामान्य बैटरी उपयोग।'
                  : 'Standard smooth 60 FPS touch tracking with optimal battery balance.'}
              </p>
            </div>

            {/* Saver 3: Performance */}
            <div
              onClick={() => {
                playSound('click');
                setBatterySavingMode('performance');
              }}
              className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                batterySavingMode === 'performance'
                  ? 'border-emerald-500 bg-emerald-950/50 shadow-md'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white flex items-center gap-1">
                  <span>🚀</span>
                  {isHindi ? 'मैक्सिमम स्पीड (120 FPS)' : 'Max Performance (120 FPS)'}
                </h4>
                {batterySavingMode === 'performance' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">
                {isHindi
                  ? 'फुल टेलीमेट्री और लाइव पार्टिकल्स।'
                  : 'Maximum frame refresh and live visual telemetry.'}
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 5: PLAY DURATION (समय-सीमा: 24/7 या घंटे) */}
        <div className="mt-5 rounded-2xl border border-slate-800 bg-slate-900/80 p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Clock className="h-4 w-4 text-cyan-400" />
              <label className="text-xs font-bold uppercase tracking-wider text-slate-200">
                {isHindi ? '5. AI खेलने की समय-सीमा (Gameplay Duration):' : '5. Session Duration:'}
              </label>
            </div>
            <span className="text-xs text-slate-400">
              {targetDurationHours
                ? `${targetDurationHours} ${isHindi ? 'घंटे' : 'hours'}`
                : isHindi ? '♾️ लगातार 24/7 चलता रहेगा' : '♾️ Endless (24/7)'}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                playSound('click');
                setTargetDurationHours(null);
                setCustomHours('');
              }}
              className={`flex items-center gap-1 rounded-xl px-3 py-2 text-xs font-bold transition-all ${
                targetDurationHours === null && !customHours
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <InfinityIcon className="h-4 w-4" />
              <span>{isHindi ? '♾️ लगातार 24/7 (अनंत)' : '♾️ Endless 24/7'}</span>
            </button>

            {[1, 2, 4, 8, 12].map((hr) => (
              <button
                key={hr}
                type="button"
                onClick={() => {
                  playSound('click');
                  setTargetDurationHours(hr);
                  setCustomHours('');
                }}
                className={`rounded-xl px-3.5 py-2 text-xs font-bold transition-all ${
                  targetDurationHours === hr && !customHours
                    ? 'bg-cyan-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {hr} {isHindi ? (hr === 1 ? 'घंटा' : 'घंटे') : (hr === 1 ? 'Hour' : 'Hours')}
              </button>
            ))}

            <input
              type="number"
              min="0.5"
              step="0.5"
              value={customHours}
              onChange={(e) => {
                setCustomHours(e.target.value);
                setTargetDurationHours(null);
              }}
              placeholder={isHindi ? 'कस्टम घंटे...' : 'Custom hrs...'}
              className="w-28 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Action Footer */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-800 pt-4">
          <div className="text-xs text-slate-400">
            <span>
              {isHindi
                ? `⚡ ${touchProfile === 'human_like' ? 'इंसानों जैसा टच' : 'रोबोटिक'} | ${batterySavingMode === 'ultra_saver' ? '🔋 बैटरी सेवर ऑन' : 'बैलेंस्ड'} | ${targetDurationHours ? `${targetDurationHours} घंटे` : '♾️ 24/7 लगातार'}`
                : `⚡ ${touchProfile} | ${batterySavingMode} | ${targetDurationHours ? `${targetDurationHours}h` : 'Endless'}`}
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-1/2 sm:w-auto rounded-xl border border-slate-700 bg-slate-800 px-4 py-2.5 text-xs font-bold text-slate-300 hover:bg-slate-700"
            >
              {isHindi ? 'रद्द करें' : 'Cancel'}
            </button>

            <button
              onClick={handleStartGame}
              className="w-1/2 sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-6 py-2.5 text-xs font-bold text-slate-950 shadow-lg shadow-emerald-500/20 hover:brightness-110 active:scale-95"
            >
              <Play className="h-4 w-4 fill-current" />
              <span>{isHindi ? '🚀 गेम शुरू करें' : '🚀 Launch Autoplay'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
