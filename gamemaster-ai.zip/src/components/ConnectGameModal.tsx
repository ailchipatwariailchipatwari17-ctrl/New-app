import React, { useState } from 'react';
import { X, Sparkles, Plus, Gamepad2, Swords, Rocket, Compass, RefreshCw, Flame, Clock, Infinity as InfinityIcon, Smartphone, ArrowRight, Settings2 } from 'lucide-react';
import { GameBotState, GameCategory } from '../types';
import { playSound } from '../utils/audio';
import { GameSetupModal } from './GameSetupModal';

interface ConnectGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddGame: (game: GameBotState) => void;
  onOpenPhoneModal?: () => void;
  language: 'hi' | 'en';
}

const PRESET_TEMPLATES = [
  {
    name: 'Fruit Ninja: Dojo Sensei',
    nameHindi: 'फ्रूट निंजा (Fruit Ninja)',
    category: 'fruit_ninja' as GameCategory,
    description: 'Sub-millisecond or human-like blade slashes all flying fruits, triggers Dragon frenzy, and dodges 100% of bombs.',
    descriptionHindi: 'AI फलों को इंसानों जैसे नैचुरल स्वाइप से काटता है, केवल फ्रूट्स या लेवल रश मोड में खेलता है।',
    packageName: 'com.halfbrick.fruitninja',
    bossName: 'Sensei Bomb Titan (Stage Boss)',
    initialScore: 12500,
    speed: 3
  },
  {
    name: 'Block Blast: Puzzle Master',
    nameHindi: 'ब्लॉक ब्लास्ट (Block Blast)',
    category: 'block_blast' as GameCategory,
    description: 'AI calculates 8x8 optimal block placements, triggers massive multi-line combo blasts, and crosses levels endlessly.',
    descriptionHindi: 'AI 8x8 ग्रिड में सबसे बेहतरीन जगह ब्लॉक रखता है, कॉम्बो ब्लास्ट बनाता है और लगातार नए लेवल पार करता है।',
    packageName: 'com.block.puzzle.game.blast',
    bossName: 'Master Grid Overlord (Level 20)',
    initialScore: 8500,
    speed: 3
  },
  {
    name: 'Subway Surfers: High Roller',
    nameHindi: 'सबवे सर्फर्स (Subway Surfers)',
    category: 'cyber_runner' as GameCategory,
    description: 'AI detects trains, barriers and coins with sub-second lane swipes and infinite multiplier runs.',
    descriptionHindi: 'AI सभी बाधाओं को पहचानकर तुरंत जंप/रोल/स्वाइप करता है और मिलियन का स्कोर बनाता है।',
    packageName: 'com.kiloo.subwaysurf',
    bossName: 'Inspector Dread Chase',
    initialScore: 15000,
    speed: 3
  },
  {
    name: 'Shadow Ninja: Shinobi Blade',
    nameHindi: 'शैडो निंजा: शिनोबी ब्लेड (Ninja RPG)',
    category: 'combat' as GameCategory,
    description: 'AI executes stealth combos, dodges shurikens, and clears wave-after-wave of enemy ninjas.',
    descriptionHindi: 'AI स्टील्थ कॉम्बो लगाता है, शूरिकेन से बचता है और दुश्मनों को खत्म कर लेवल अप करता है।',
    bossName: 'Grandmaster Orochi',
    initialScore: 5000,
    speed: 2
  },
  {
    name: 'Dragon Tower: Infinite Climb',
    nameHindi: 'ड्रैगन टॉवर: अनंत चढ़ाई (Tower Slayer)',
    category: 'dungeon_rpg' as GameCategory,
    description: 'AI climbs a 100-floor mystical tower, farms rare elemental relics, and slays ancient drakes.',
    descriptionHindi: 'AI 100 मंजिलों के रहस्यमय टॉवर पर चढ़ता है, अवशेष इकट्ठा करता है और ड्रैगन्स को मारता है।',
    bossName: 'Ancient Crimson Dragon',
    initialScore: 7200,
    speed: 3
  },
  {
    name: 'Cyberpunk Drone Mining Fleet',
    nameHindi: 'साइबर ड्रोन माइनिंग फ्लीट',
    category: 'space_miner' as GameCategory,
    description: 'AI manages an armada of automated mining freighters extracting plasma crystals from nebulae.',
    descriptionHindi: 'AI स्पेस में ऑटोमेटेड जहाजों से प्लाज्मा क्रिस्टल माइन करता है और पैसिव स्कोर बढ़ाता है।',
    bossName: 'Nebula Titan Dreadnought',
    initialScore: 12000,
    speed: 2
  }
];

export const ConnectGameModal: React.FC<ConnectGameModalProps> = ({
  isOpen,
  onClose,
  onAddGame,
  onOpenPhoneModal,
  language
}) => {
  const [customPrompt, setCustomPrompt] = useState('');
  const [targetHours, setTargetHours] = useState<string>(''); // empty = endless 24/7
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedTemplateForSetup, setSelectedTemplateForSetup] = useState<typeof PRESET_TEMPLATES[0] | null>(null);
  const isHindi = language === 'hi';

  const parsedDuration = targetHours && parseFloat(targetHours) > 0 ? parseFloat(targetHours) : null;

  if (!isOpen) return null;

  const handleOpenSetupWizard = (template: typeof PRESET_TEMPLATES[0]) => {
    playSound('click');
    setSelectedTemplateForSetup(template);
  };

  const handleSelectPreset = (template: typeof PRESET_TEMPLATES[0]) => {
    setSelectedTemplateForSetup(template);
  };

  const handleGenerateCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim() || isGenerating) return;
    setIsGenerating(true);
    playSound('ai_command');

    try {
      const res = await fetch('/api/ai/create-game', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gamePrompt: customPrompt })
      });
      const data = await res.json();
      const g = data.game || {};

      let resolvedCategory: GameCategory = 'custom';
      const promptLower = customPrompt.toLowerCase();
      if (promptLower.includes('block') || promptLower.includes('blast') || promptLower.includes('puzzle')) {
        resolvedCategory = 'block_blast';
      } else if (promptLower.includes('fruit') || promptLower.includes('ninja') || promptLower.includes('slice')) {
        resolvedCategory = 'fruit_ninja';
      }

      const newGame: GameBotState = {
        id: `game_custom_${Date.now()}`,
        name: g.name || customPrompt,
        nameHindi: g.nameHindi || `${customPrompt} (AI ऑटो-बॉट)`,
        category: resolvedCategory,
        description: g.description || 'Custom autonomous AI bot playing and leveling.',
        descriptionHindi: g.lore || 'कस्टम AI एजेंट बिना रुके गेम खेल रहा है और स्कोर बढ़ा रहा है।',
        status: 'active',
        level: 1,
        exp: 0,
        maxExp: 600,
        score: g.initialScoreRate ? g.initialScoreRate * 20 : 8000,
        highScore: g.initialScoreRate ? g.initialScoreRate * 20 : 8000,
        coins: 1500,
        crystals: 25,
        bossesDefeated: 0,
        bossName: g.bossName || 'Final Overlord',
        currentBossHealth: 2000,
        maxBossHealth: 2000,
        actionsPerMinute: 280,
        speedMultiplier: 2,
        strategy: 'aggressive_xp',
        customDirectives: [g.aiPlayStyle || 'Autonomous pathfinding & maximum XP rush'],
        uptimeSeconds: 0,
        targetDurationHours: parsedDuration,
        remainingSeconds: parsedDuration ? parsedDuration * 3600 : null,
        autoUpgrade: true,
        botConfidence: 99,
        skills: {
          strength: 12,
          agility: 12,
          intelligence: 12,
          vitality: 12
        },
        inventory: [
          { id: `loot_${Date.now()}`, name: `${g.primaryResourceName || 'Energy'} Siphon Matrix`, rarity: 'epic', bonus: '+30% Farm Rate' }
        ],
        lastTickTime: Date.now(),
        simulationParams: {
          heroX: 140,
          heroY: 100,
          monstersCount: 5,
          multiplier: 1.5,
          currentWave: 1,
          blocksCleared: resolvedCategory === 'block_blast' ? 50 : undefined,
          fruitsSliced: resolvedCategory === 'fruit_ninja' ? 80 : undefined
        }
      };

      playSound('levelup');
      onAddGame(newGame);
      setCustomPrompt('');
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
      <div className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-emerald-500/30 bg-slate-900 p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Gamepad2 className="h-6 w-6 text-emerald-400" />
            <div>
              <h2 className="text-lg font-bold text-white">
                {isHindi ? 'नया गेम कनेक्ट करें (Connect Game Bot)' : 'Connect & Autoplay New Game'}
              </h2>
              <p className="text-xs text-slate-400">
                {isHindi
                  ? 'AI किसी भी गेम को बैकग्राउंड में ऑटो-प्ले और लेवल अप कर सकता है।'
                  : 'AI autonomously plays and clears levels in background.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Phone Downloaded Games Quick Connect Banner */}
        {onOpenPhoneModal && (
          <div
            onClick={() => {
              playSound('click');
              onClose();
              onOpenPhoneModal();
            }}
            className="mt-4 flex cursor-pointer items-center justify-between rounded-2xl border border-cyan-500/40 bg-gradient-to-r from-cyan-950/60 to-slate-900 p-4 transition-all hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-950/40 group"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-400 group-hover:scale-110 transition-transform">
                <Smartphone className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-cyan-300">
                  {isHindi ? '📱 फोन पर डाउनलोड किए गए गेम्स सिंक करें' : '📱 Sync Games Installed on your Phone'}
                </h4>
                <p className="text-[11px] text-slate-400">
                  {isHindi
                    ? 'Block Blast, Fruit Ninja, Subway Surfers, Candy Crush आदि को फोन स्क्रीन से जोड़ें।'
                    : 'Auto-detect mobile apps & launch AI Touch & Screen Reader automation.'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs font-bold text-cyan-400">
              <span>{isHindi ? 'सिंक करें' : 'Pair Phone'}</span>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </div>
          </div>
        )}

        {/* Global / New Game Duration Selector (समय सीमा या अनवरत 24/7) */}
        <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950 p-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Clock className="h-4 w-4 text-cyan-400" />
              <label className="text-xs font-bold text-slate-200">
                {isHindi ? 'गेम खेलने की समय-सीमा (Gameplay Duration):' : 'Gameplay Session Duration:'}
              </label>
            </div>
            <span className="text-[11px] text-slate-400">
              {targetHours && parseFloat(targetHours) > 0
                ? `${targetHours} ${isHindi ? 'घंटे' : 'hours'}`
                : isHindi ? '♾️ ऑप्शन खाली = लगातार 24/7 खेलता रहेगा' : '♾️ Blank = Endless 24/7'}
            </span>
          </div>

          <div className="mt-2.5 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setTargetHours('')}
              className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-all ${
                !targetHours
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <InfinityIcon className="h-3.5 w-3.5" />
              <span>{isHindi ? 'अनंत (24/7 खेलता रहे)' : 'Endless (24/7)'}</span>
            </button>

            {['1', '2', '4', '8'].map((hr) => (
              <button
                key={hr}
                type="button"
                onClick={() => setTargetHours(hr)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  targetHours === hr
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {hr} {isHindi ? (hr === '1' ? 'घंटा' : 'घंटे') : (hr === '1' ? 'Hour' : 'Hours')}
              </button>
            ))}

            <div className="flex items-center gap-1 ml-auto">
              <input
                type="number"
                min="0.5"
                step="0.5"
                max="72"
                value={targetHours}
                onChange={(e) => setTargetHours(e.target.value)}
                placeholder={isHindi ? 'कस्टम घंटे...' : 'Custom hrs...'}
                className="w-24 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* AI Custom Game Generator Box */}
        <div className="mt-4 rounded-xl border border-cyan-500/30 bg-slate-950 p-4">
          <div className="mb-2 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-cyan-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              {isHindi ? 'AI से कोई भी गेम बनाएं और ऑटो-प्ले कराएं' : 'Generate & Connect ANY Custom Game via AI'}
            </h3>
          </div>
          <p className="mb-3 text-xs text-slate-400">
            {isHindi
              ? 'जो भी गेम आप AI से खिलवाना चाहते हैं, उसका नाम या प्रकार लिखें (उदा. "Block Blast", "Fruit Ninja", "Subway Surfers", "Chess Pro"):'
              : 'Enter any game title or concept. AI will configure autonomous bots to clear levels:'}
          </p>

          <form onSubmit={handleGenerateCustom} className="flex gap-2">
            <input
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder={isHindi ? 'गेम का नाम (उदा. Block Blast, Fruit Ninja, Cyberpunk Slayer)...' : 'Game name or concept (e.g. Block Blast, Fruit Ninja, Chess Master)...'}
              className="flex-1 rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={isGenerating || !customPrompt.trim()}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 px-4 py-2.5 text-xs font-bold text-white transition-all hover:from-cyan-500 hover:to-blue-500 active:scale-95 disabled:opacity-50"
            >
              {isGenerating ? (
                <RefreshCw className="h-4 w-4 animate-spin text-white" />
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  <span>{isHindi ? 'AI बॉट बनाएं' : 'Create Bot'}</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Preset Fast-Connect Templates */}
        <div className="mt-5">
          <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">
            {isHindi ? 'रेडी-टू-कनेक्ट लोकप्रिय गेम्स (Block Blast, Fruit Ninja & More)' : 'Popular Ready-to-Connect Games'}
          </h3>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {PRESET_TEMPLATES.map((tmpl, idx) => (
              <div
                key={idx}
                onClick={() => handleOpenSetupWizard(tmpl)}
                className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-950/70 p-3.5 transition-all hover:border-emerald-500/50 hover:bg-slate-900"
              >
                <div className="flex items-start justify-between">
                  <h4 className="font-bold text-white group-hover:text-emerald-400 text-xs sm:text-sm flex items-center gap-1.5">
                    <span>{tmpl.category === 'fruit_ninja' ? '🍉' : tmpl.category === 'block_blast' ? '🧩' : '🎮'}</span>
                    <span>{isHindi ? tmpl.nameHindi : tmpl.name}</span>
                  </h4>
                  <span className="rounded bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-bold text-emerald-400">
                    {tmpl.speed}x Speed
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-400 line-clamp-2">
                  {isHindi ? tmpl.descriptionHindi : tmpl.description}
                </p>
                <div className="mt-2.5 flex items-center justify-between border-t border-slate-800/80 pt-2 text-[11px]">
                  <span className="text-rose-400 font-mono">👑 {tmpl.bossName}</span>
                  <span className="flex items-center gap-1 font-semibold text-emerald-400 group-hover:underline">
                    <Settings2 className="h-3.5 w-3.5" />
                    <span>{isHindi ? 'मोड व सेटिंग्स चुनें' : 'Configure & Play'}</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Game Mode, Human Touch & Battery Setup Modal */}
      {selectedTemplateForSetup && (
        <GameSetupModal
          isOpen={!!selectedTemplateForSetup}
          onClose={() => setSelectedTemplateForSetup(null)}
          onConfirmLaunch={(game) => {
            onAddGame(game);
            setSelectedTemplateForSetup(null);
            onClose();
          }}
          initialTemplate={selectedTemplateForSetup}
          language={language}
        />
      )}
    </div>
  );
};
