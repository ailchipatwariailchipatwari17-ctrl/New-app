import React, { useState, useEffect, useRef } from 'react';
import { X, Shield, Zap, Sparkles, Award, Swords, Skull, Plus, Terminal, CheckCircle2, ChevronRight, Clock, Infinity as InfinityIcon, Check } from 'lucide-react';
import { GameBotState, BotStrategy } from '../types';
import { playSound } from '../utils/audio';

interface GameInspectModalProps {
  game: GameBotState | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStrategy: (gameId: string, strategy: BotStrategy) => void;
  onUpdateDuration: (gameId: string, hours: number | null) => void;
  onUpgradeSkill: (gameId: string, skill: keyof GameBotState['skills']) => void;
  onAddDirective: (gameId: string, directive: string) => void;
  language: 'hi' | 'en';
}

export const GameInspectModal: React.FC<GameInspectModalProps> = ({
  game,
  isOpen,
  onClose,
  onUpdateStrategy,
  onUpdateDuration,
  onUpgradeSkill,
  onAddDirective,
  language
}) => {
  const [newDirective, setNewDirective] = useState('');
  const [customHours, setCustomHours] = useState('');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isHindi = language === 'hi';

  const formatCountdown = (seconds: number | null) => {
    if (seconds === null || seconds === undefined) return null;
    const s = Math.max(0, Math.floor(seconds));
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (!isOpen || !game) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let frame = 0;

    const render = () => {
      frame++;
      const w = canvas.width;
      const h = canvas.height;

      // Deep cyber background
      ctx.fillStyle = '#030712';
      ctx.fillRect(0, 0, w, h);

      // Radar / Grid lines
      ctx.strokeStyle = '#0f2942';
      ctx.lineWidth = 1;
      for (let r = 30; r < w; r += 30) {
        ctx.beginPath();
        ctx.moveTo(r, 0);
        ctx.lineTo(r, h);
        ctx.stroke();
      }
      for (let r = 30; r < h; r += 30) {
        ctx.beginPath();
        ctx.moveTo(0, r);
        ctx.lineTo(w, r);
        ctx.stroke();
      }

      if (game.category === 'block_blast') {
        // Block blast 8x8 high-res board
        const cellSize = 22;
        const startX = (w - 8 * cellSize) / 2;
        const startY = (h - 8 * cellSize) / 2;
        const colors = ['#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];

        ctx.fillStyle = '#0a1728';
        ctx.fillRect(startX - 4, startY - 4, 8 * cellSize + 8, 8 * cellSize + 8);
        ctx.strokeStyle = '#38bdf8';
        ctx.strokeRect(startX - 4, startY - 4, 8 * cellSize + 8, 8 * cellSize + 8);

        for (let row = 0; row < 8; row++) {
          for (let col = 0; col < 8; col++) {
            const isFilled = (row * 8 + col + Math.floor(frame / 35)) % 13 < 7;
            const x = startX + col * cellSize;
            const y = startY + row * cellSize;

            ctx.strokeStyle = '#1e3a5f';
            ctx.strokeRect(x, y, cellSize, cellSize);

            if (isFilled) {
              ctx.fillStyle = colors[(row + col) % colors.length];
              ctx.fillRect(x + 2, y + 2, cellSize - 4, cellSize - 4);
              ctx.fillStyle = 'rgba(255,255,255,0.4)';
              ctx.fillRect(x + 2, y + 2, (cellSize - 4) / 2, 3);
            }
          }
        }

        // Active combo clear flash
        const line = Math.floor((frame / 25) % 8);
        if (Math.sin(frame * 0.2) > 0.2) {
          ctx.fillStyle = 'rgba(251, 191, 36, 0.85)';
          ctx.fillRect(startX, startY + line * cellSize, 8 * cellSize, cellSize);

          ctx.fillStyle = '#facc15';
          ctx.font = 'bold 13px monospace';
          ctx.fillText(`⚡ AI TRIPLE BLAST COMBO (+${game.level * 250} PTS)`, startX + 10, startY + line * cellSize + 15);
        }
      } else if (game.category === 'fruit_ninja') {
        // Fruit ninja high-res dojo slicer
        for (let i = 0; i < 4; i++) {
          const t = ((frame * 0.03) + i * 1.5) % Math.PI;
          const fx = 70 + i * 110 + Math.cos(t) * 35;
          const fy = h - Math.sin(t) * (h - 40);

          // Fruit
          ctx.fillStyle = i % 2 === 0 ? '#22c55e' : '#f97316';
          ctx.beginPath();
          ctx.arc(fx - 6, fy, 16, Math.PI / 2, (3 * Math.PI) / 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(fx + 6, fy, 16, -(Math.PI / 2), Math.PI / 2);
          ctx.fill();

          ctx.fillStyle = i % 2 === 0 ? '#ef4444' : '#fed7aa';
          ctx.beginPath();
          ctx.arc(fx - 6, fy, 13, Math.PI / 2, (3 * Math.PI) / 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(fx + 6, fy, 13, -(Math.PI / 2), Math.PI / 2);
          ctx.fill();
        }

        // Katana Trail
        const sx = (frame * 6) % w;
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(sx - 40, h / 2 - 20);
        ctx.lineTo(sx + 40, h / 2 + 20);
        ctx.stroke();

        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 12px monospace';
        ctx.fillText(`🍉 100% BOMB DEFLECTED | DRAGON BLADE FRENZY`, 20, h - 20);
      } else {
        // Radar Rings
        for (let r = 40; r < w / 2; r += 45) {
          ctx.beginPath();
          ctx.arc(w / 2, h / 2, r, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Sweeping beam
        const sweepAngle = (frame * 0.03) % (Math.PI * 2);
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(w / 2, h / 2);
        ctx.lineTo(w / 2 + Math.cos(sweepAngle) * (w / 2), h / 2 + Math.sin(sweepAngle) * (h / 2));
        ctx.stroke();

        // Hero Node
        const pulse = Math.sin(frame * 0.1) * 6;
        ctx.fillStyle = 'rgba(16, 185, 129, 0.3)';
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, 24 + pulse, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, 14, 0, Math.PI * 2);
        ctx.fill();
      }

      // HUD Text
      ctx.fillStyle = '#10b981';
      ctx.font = '11px monospace';
      ctx.fillText(`AI CONFIDENCE: ${game.botConfidence}% | TARGET: LOCKED`, 14, 24);
      ctx.fillText(`AUTONOMOUS APM: ${game.actionsPerMinute}`, 14, 40);

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isOpen, game]);

  if (!isOpen || !game) return null;

  const handleAddDirectiveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDirective.trim()) return;
    playSound('ai_command');
    onAddDirective(game.id, newDirective.trim());
    setNewDirective('');
  };

  const countdownText = formatCountdown(game.remainingSeconds);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
      <div className="relative max-h-[95vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-emerald-500/40 bg-slate-950 p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 shadow-md">
              <Swords className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">
                  {isHindi ? game.nameHindi : game.name}
                </h2>
                <span className="rounded-lg bg-emerald-500/20 px-2 py-0.5 text-xs font-bold text-emerald-400">
                  Level {game.level}
                </span>
              </div>
              
              {/* Badges */}
              <div className="mt-1 flex flex-wrap items-center gap-1.5">
                {game.playModeGoal === 'slice_only' ? (
                  <span className="rounded-md bg-teal-500/20 border border-teal-500/40 px-2 py-0.5 text-xs font-bold text-teal-300">
                    🍉 {isHindi ? 'मोड: बस फ्रूट काटना (Zen Slicing)' : 'Mode: Just Slice Fruits'}
                  </span>
                ) : game.playModeGoal === 'level_up' ? (
                  <span className="rounded-md bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 text-xs font-bold text-emerald-300">
                    🚀 {isHindi ? 'मोड: लेवल रश (Fast Level Up)' : 'Mode: Fast Level Up'}
                  </span>
                ) : game.playModeGoal === 'boss_rush' ? (
                  <span className="rounded-md bg-purple-500/20 border border-purple-500/40 px-2 py-0.5 text-xs font-bold text-purple-300">
                    👑 {isHindi ? 'मोड: बॉस हंटर (Boss Master)' : 'Mode: Boss Master'}
                  </span>
                ) : null}

                {game.touchProfile === 'human_like' && (
                  <span className="rounded-md bg-cyan-500/20 border border-cyan-500/40 px-2 py-0.5 text-xs font-semibold text-cyan-300">
                    👤 {isHindi ? 'इंसानों जैसा टच (99.8% Natural)' : 'Human-like Touch (99.8% Natural)'}
                  </span>
                )}

                {game.batterySavingMode === 'ultra_saver' && (
                  <span className="rounded-md bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 text-xs font-semibold text-emerald-300">
                    🔋 {isHindi ? 'अल्ट्रा बैटरी सेवर (-75% खपत)' : 'Ultra Battery Saver (-75%)'}
                  </span>
                )}

                {game.executionTarget === 'phone_installed_app' ? (
                  <span className="rounded-md bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 text-xs font-bold text-amber-300">
                    📱 {isHindi ? 'फोन पर डाउनलोड किए हुए गेम में' : 'Direct Mobile App Touch'}
                  </span>
                ) : (
                  <span className="rounded-md bg-slate-800 px-2 py-0.5 text-xs text-slate-400">
                    💻 {isHindi ? 'वेब हब सिमुलेटर' : 'Hub Engine'}
                  </span>
                )}
              </div>

              <p className="mt-1 text-xs text-slate-400">
                {isHindi ? game.descriptionHindi : game.description}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Duration / Gameplay Timer Bar */}
        <div className="mt-4 rounded-xl border border-cyan-500/30 bg-slate-900/80 p-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-cyan-400" />
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                  {isHindi ? 'AI खेलने की समय-सीमा (Gameplay Duration Timer)' : 'AI Session Duration Timer'}
                </h4>
                <p className="text-xs text-slate-400">
                  {game.targetDurationHours
                    ? isHindi
                      ? `AI निर्धारित ${game.targetDurationHours} घंटे खेलकर स्वतः सुरक्षित रुकेगा।`
                      : `Bot will play for ${game.targetDurationHours} hours and then safely pause.`
                    : isHindi
                    ? '♾️ ऑप्शन सेट नहीं है: AI लगातार 24/7 बैकग्राउंड में खेलता ही रहेगा।'
                    : '♾️ No limit set: AI will keep farming 24/7 without stopping.'}
                </p>
              </div>
            </div>

            {/* Countdown Badge */}
            <div className="flex items-center gap-2">
              {countdownText ? (
                <div className="flex items-center gap-2 rounded-xl bg-cyan-950 px-3 py-1.5 border border-cyan-500/40">
                  <span className="h-2 w-2 animate-ping rounded-full bg-cyan-400" />
                  <span className="font-mono text-sm font-bold text-cyan-300">
                    {countdownText}
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 rounded-xl bg-emerald-950 px-3 py-1.5 border border-emerald-500/30 text-xs font-bold text-emerald-400">
                  <InfinityIcon className="h-4 w-4" />
                  <span>{isHindi ? '24/7 अनवरत खेलता रहेगा' : 'Endless 24/7'}</span>
                </div>
              )}
            </div>
          </div>

          {/* Duration Buttons Selector */}
          <div className="mt-3 flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800">
            <button
              onClick={() => {
                playSound('click');
                onUpdateDuration(game.id, null);
              }}
              className={`flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-semibold ${
                game.targetDurationHours === null
                  ? 'bg-emerald-600 text-white font-bold shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <InfinityIcon className="h-3.5 w-3.5" />
              <span>{isHindi ? 'लगातार खेलता रहे (24/7)' : 'Endless (24/7)'}</span>
            </button>

            {[1, 2, 4, 8, 12, 24].map((hrs) => (
              <button
                key={hrs}
                onClick={() => {
                  playSound('click');
                  onUpdateDuration(game.id, hrs);
                }}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${
                  game.targetDurationHours === hrs
                    ? 'bg-cyan-600 text-white font-bold shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {hrs} {isHindi ? (hrs === 1 ? 'घंटा' : 'घंटे') : (hrs === 1 ? 'hr' : 'hrs')}
              </button>
            ))}

            <div className="flex items-center gap-1.5 ml-auto">
              <input
                type="number"
                min="0.5"
                step="0.5"
                value={customHours}
                onChange={(e) => setCustomHours(e.target.value)}
                placeholder={isHindi ? 'कस्टम घंटे...' : 'Custom hrs...'}
                className="w-28 rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
              />
              <button
                onClick={() => {
                  const val = parseFloat(customHours);
                  if (val > 0) {
                    playSound('click');
                    onUpdateDuration(game.id, val);
                    setCustomHours('');
                  }
                }}
                className="rounded-lg bg-cyan-600 px-3 py-1 text-xs font-bold text-white hover:bg-cyan-500"
              >
                {isHindi ? 'लागू करें' : 'Apply'}
              </button>
            </div>
          </div>
        </div>

        {/* Top Grid: Live Canvas & Stats */}
        <div className="mt-5 grid grid-cols-1 gap-4 lg:grid-cols-12">
          {/* Live Radar Arena */}
          <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900 lg:col-span-7">
            <div className="border-b border-slate-800 bg-slate-950 px-3 py-2 text-xs font-semibold text-emerald-400 flex items-center justify-between">
              <span>{isHindi ? 'लाइव AI कॉम्बैट व पाथफाइंडिंग' : 'Live AI Combat & Neural Pathfinding'}</span>
              <span className="text-[10px] text-slate-400">{game.actionsPerMinute} APM</span>
            </div>
            <canvas ref={canvasRef} width={500} height={260} className="h-64 w-full" />
          </div>

          {/* Core Bot Stats & Boss status */}
          <div className="flex flex-col justify-between space-y-3 rounded-xl border border-slate-800 bg-slate-900/60 p-4 lg:col-span-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              {isHindi ? 'AI बॉट मेट्रिक्स' : 'Bot Telemetry'}
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between rounded-lg bg-slate-950 p-2.5">
                <span className="text-slate-400">{isHindi ? 'कुल स्कोर' : 'Total Score'}</span>
                <span className="font-bold text-amber-400">{game.score.toLocaleString()}</span>
              </div>
              <div className="flex justify-between rounded-lg bg-slate-950 p-2.5">
                <span className="text-slate-400">{isHindi ? 'गोल्ड कॉइन्स' : 'Gold Coins'}</span>
                <span className="font-bold text-yellow-300">🪙 {game.coins.toLocaleString()}</span>
              </div>
              <div className="flex justify-between rounded-lg bg-slate-950 p-2.5">
                <span className="text-slate-400">{isHindi ? 'क्रिस्टल्स' : 'Crystals'}</span>
                <span className="font-bold text-cyan-400">💎 {game.crystals}</span>
              </div>
              <div className="flex justify-between rounded-lg bg-slate-950 p-2.5">
                <span className="text-slate-400">{isHindi ? 'मारे गए बॉस' : 'Bosses Vanquished'}</span>
                <span className="font-bold text-rose-400">👑 {game.bossesDefeated}</span>
              </div>
            </div>

            {/* Boss bar */}
            {game.bossName && (
              <div className="rounded-lg border border-rose-500/30 bg-rose-950/20 p-2.5">
                <div className="flex items-center justify-between text-xs text-rose-300 font-semibold mb-1">
                  <span className="truncate max-w-[180px]">{game.bossName}</span>
                  <span>{game.currentBossHealth} / {game.maxBossHealth} HP</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-rose-500 to-amber-500"
                    style={{
                      width: `${Math.max(0, Math.min(100, Math.floor(((game.currentBossHealth || 1) / (game.maxBossHealth || 1)) * 100)))}%`
                    }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Skills Upgrade Tree */}
        <div className="mt-5 rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              {isHindi ? 'AI कैरेक्टर स्किल्स (Auto-Allocated & Upgradable)' : 'Character Skills'}
            </h3>
            <span className="text-[11px] text-emerald-400">
              {isHindi ? 'AI हर लेवल अप पर खुद स्किल्स बढ़ाता है' : 'AI automatically allocates points'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {(['strength', 'agility', 'intelligence', 'vitality'] as const).map((skillKey) => (
              <div key={skillKey} className="rounded-lg border border-slate-800 bg-slate-950 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold capitalize text-slate-300">{skillKey}</span>
                  <span className="text-sm font-bold text-emerald-400">{game.skills[skillKey]}</span>
                </div>
                <button
                  onClick={() => {
                    playSound('levelup');
                    onUpgradeSkill(game.id, skillKey);
                  }}
                  className="mt-2.5 flex w-full items-center justify-center gap-1 rounded bg-slate-800 py-1 text-[11px] font-semibold text-slate-200 hover:bg-emerald-600 hover:text-white"
                >
                  <Plus className="h-3 w-3" />
                  <span>{isHindi ? '+ अपग्रेड' : '+ Upgrade'}</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* AI Directives & Custom Instructions */}
        <div className="mt-5 rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-300">
            {isHindi ? 'AI कस्टम निर्देश (Active Directives)' : 'Active AI Directives'}
          </h3>

          <div className="mb-3 flex flex-wrap gap-2">
            {game.customDirectives.map((d, idx) => (
              <span key={idx} className="flex items-center gap-1 rounded-md border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-xs text-emerald-300">
                <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                {d}
              </span>
            ))}
          </div>

          <form onSubmit={handleAddDirectiveSubmit} className="flex gap-2">
            <input
              type="text"
              value={newDirective}
              onChange={(e) => setNewDirective(e.target.value)}
              placeholder={isHindi ? 'इस गेम के लिए नया AI निर्देश लिखें (उदा. "Always prioritize 3+ lines combo clear")...' : 'Add custom AI directive for this bot...'}
              className="flex-1 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={!newDirective.trim()}
              className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
            >
              {isHindi ? 'निर्देश जोड़ें' : 'Add Rule'}
            </button>
          </form>
        </div>

        {/* Inventory Stash */}
        <div className="mt-5 rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-300">
            {isHindi ? 'लूट और गियर (AI Auto-Collected Loot)' : 'Collected Loot & Equipment'}
          </h3>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {game.inventory.map((item) => (
              <div key={item.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-2.5 text-xs">
                <div>
                  <span className="font-bold text-white">{item.name}</span>
                  <span className="block text-[10px] text-emerald-400">{item.bonus}</span>
                </div>
                <span className="rounded bg-purple-500/20 px-2 py-0.5 text-[10px] font-bold text-purple-300 uppercase">
                  {item.rarity}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
