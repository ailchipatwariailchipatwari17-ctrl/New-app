package com.example.model

import android.graphics.Bitmap
import androidx.annotation.StringRes
import androidx.compose.ui.geometry.Offset
import com.example.R

enum class WorkflowStep(val stepNumber: Int, @StringRes val labelRes: Int) {
  IMPORT(1, R.string.step_1_import),
  MASK(2, R.string.step_2_mask),
  CLEANUP(3, R.string.step_3_cleanup),
  PREVIEW_EXPORT(4, R.string.step_4_preview_export)
}

enum class MaskTool {
  BRUSH,
  CLONE_PATCH,
  ERASER
}

enum class InpaintingEngineMode {
  LOCAL_FREEZE_PATCH,
  FREE_CLOUD_AI
}

data class VideoFrame(
  val index: Int,
  val timestampMs: Long,
  val originalBitmap: Bitmap,
  var cleanedBitmap: Bitmap? = null,
  val cameraShiftX: Float = 0f,
  val cameraShiftY: Float = 0f
)

data class BrushPoint(
  val x: Float,
  val y: Float
)

data class BrushStroke(
  val points: List<BrushPoint>,
  val radius: Float = 28f,
  val opacity: Float = 0.9f,
  val feather: Float = 0.5f,
  val isEraser: Boolean = false
)

data class ClonePatchConfig(
  val sourceX: Float = 0.25f,
  val sourceY: Float = 0.35f,
  val targetX: Float = 0.65f,
  val targetY: Float = 0.55f,
  val radius: Float = 0.18f,
  val featherRatio: Float = 0.45f,
  val opacity: Float = 1.0f,
  val harmonizeLuminance: Boolean = true
)

data class SampleVideoPreset(
  val id: String,
  @StringRes val titleRes: Int,
  @StringRes val descRes: Int,
  val frameCount: Int = 30,
  val durationMs: Long = 2000L,
  val defaultSource: Offset = Offset(0.25f, 0.25f),
  val defaultTarget: Offset = Offset(0.65f, 0.55f),
  val defaultRadius: Float = 0.16f
)

data class ExportState(
  val isExporting: Boolean = false,
  val currentFrame: Int = 0,
  val totalFrames: Int = 0,
  val progress: Float = 0f,
  val statusMessage: String = "",
  val exportedUri: String? = null,
  val isComplete: Boolean = false,
  val error: String? = null
)

data class TextCommandResult(
  val prompt: String,
  val detectedCategory: String,
  val confidence: Float,
  val patchConfig: ClonePatchConfig,
  val explanationHindi: String,
  val explanationEnglish: String
)

enum class DecorType {
  WALL_ART_FRAME,
  WALL_CLOCK,
  INDOOR_PLANT,
  LIGHT_FIXTURE,
  WALLPAPER_STRIPES
}

data class DecorItem(
  val id: String,
  val type: DecorType,
  val nameHindi: String,
  val nameEnglish: String,
  val normalizedX: Float,
  val normalizedY: Float,
  val scale: Float = 0.22f
)

data class WallPaintConfig(
  val enabled: Boolean = false,
  val colorNameHindi: String = "रॉयल ब्लू",
  val colorNameEnglish: String = "Royal Sapphire Blue",
  val colorHex: Long = 0xFF1E3A8A, // ARGB
  val opacity: Float = 0.45f,
  val blendMode: String = "MULTIPLY"
)

data class GeminiChatMessage(
  val id: String = java.util.UUID.randomUUID().toString(),
  val isUser: Boolean,
  val text: String,
  val timestampMs: Long = System.currentTimeMillis(),
  val actionApplied: String? = null,
  val suggestedPrompts: List<String> = emptyList(),
  val hasMedia: Boolean = false,
  val mediaType: String? = null
)

data class PinnedAttachment(
  val id: String = java.util.UUID.randomUUID().toString(),
  val title: String,
  val subtitle: String = "घर का वीडियो",
  val uri: android.net.Uri? = null,
  val presetId: String? = null,
  val thumbnailBitmap: Bitmap? = null
)

data class ChatSession(
  val id: String = java.util.UUID.randomUUID().toString(),
  val title: String,
  val timestampMs: Long = System.currentTimeMillis(),
  val messages: List<GeminiChatMessage> = emptyList(),
  val presetId: String = "dampness",
  val wallPaintConfig: WallPaintConfig = WallPaintConfig(),
  val decorItems: List<DecorItem> = emptyList()
)

