package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.WorkflowStep
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun StepProgressBar(
  currentStep: WorkflowStep,
  onStepSelected: (WorkflowStep) -> Unit,
  modifier: Modifier = Modifier
) {
  val steps = WorkflowStep.values()

  Row(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(DarkSurfaceElevated)
      .padding(horizontal = 8.dp, vertical = 10.dp)
      .testTag("step_progress_bar"),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    steps.forEachIndexed { index, step ->
      val isSelected = step == currentStep
      val isPast = step.stepNumber < currentStep.stepNumber

      val activeColor by animateColorAsState(
        targetValue = when {
          isSelected -> CyanPrimary
          isPast -> Color(0xFF10B981)
          else -> TextMuted
        },
        label = "step_color"
      )

      Column(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(8.dp))
          .clickable { onStepSelected(step) }
          .padding(vertical = 4.dp)
          .testTag("step_item_${step.name.lowercase()}"),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (isSelected) CyanPrimary.copy(alpha = 0.2f) else Color.Transparent),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = getStepIcon(step),
            contentDescription = step.name,
            tint = activeColor,
            modifier = Modifier.size(18.dp)
          )
        }

        Spacer(modifier = Modifier.height(3.dp))

        Text(
          text = getStepShortTitle(step),
          fontSize = 11.sp,
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
          color = if (isSelected) TextPrimary else TextMuted,
          textAlign = TextAlign.Center,
          maxLines = 1
        )

        Spacer(modifier = Modifier.height(4.dp))

        Box(
          modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(3.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(if (isSelected || isPast) activeColor else DarkSurfaceBorder)
        )
      }
    }
  }
}

private fun getStepIcon(step: WorkflowStep): ImageVector = when (step) {
  WorkflowStep.IMPORT -> Icons.Default.VideoFile
  WorkflowStep.MASK -> Icons.Default.Brush
  WorkflowStep.CLEANUP -> Icons.Default.AutoAwesome
  WorkflowStep.PREVIEW_EXPORT -> Icons.Default.Compare
}

private fun getStepShortTitle(step: WorkflowStep): String = when (step) {
  WorkflowStep.IMPORT -> "1. Import"
  WorkflowStep.MASK -> "2. Mask"
  WorkflowStep.CLEANUP -> "3. Inpaint"
  WorkflowStep.PREVIEW_EXPORT -> "4. Preview"
}
