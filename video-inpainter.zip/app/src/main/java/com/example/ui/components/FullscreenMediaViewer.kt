package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Fullscreen Photo & Video Viewer for AI output.
 * Renders the 100% finished clean frame (Zero Before/After lines).
 * Allows instant play/pause, seek, and download to phone gallery.
 */
@Composable
fun FullscreenMediaViewer(
  bitmap: Bitmap?,
  isPlaying: Boolean,
  currentFrameIndex: Int,
  totalFrames: Int,
  onTogglePlay: () -> Unit,
  onSaveToGallery: () -> Unit,
  onClose: () -> Unit,
  modifier: Modifier = Modifier
) {
  if (bitmap == null) return

  Dialog(
    onDismissRequest = onClose,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(Color.Black)
        .testTag("fullscreen_media_viewer")
    ) {
      // Main 100% Clean Frame - ZERO split lines
      Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = "Cleaned Output",
        modifier = Modifier
          .fillMaxSize()
          .clickable { onTogglePlay() },
        contentScale = ContentScale.Fit
      )

      // Top Control Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onClose,
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.6f))
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = Color.White
          )
        }

        Surface(
          shape = RoundedCornerShape(16.dp),
          color = Color.Black.copy(alpha = 0.65f)
        ) {
          Text(
            text = "Gemini Ultra Video",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF38BDF8),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
          )
        }

        IconButton(
          onClick = onSaveToGallery,
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(Color(0xFF2563EB))
            .testTag("btn_viewer_download")
        ) {
          Icon(
            imageVector = Icons.Default.Download,
            contentDescription = "Download to Gallery",
            tint = Color.White
          )
        }
      }

      // Center Big Play/Pause overlay button
      if (!isPlaying) {
        Box(
          modifier = Modifier
            .align(Alignment.Center)
            .size(68.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable { onTogglePlay() },
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = "Play",
            tint = Color.White,
            modifier = Modifier.size(36.dp)
          )
        }
      }

      // Bottom Control Bar
      Column(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .navigationBarsPadding()
          .background(Color.Black.copy(alpha = 0.75f))
          .padding(horizontal = 20.dp, vertical = 14.dp)
      ) {
        // Progress indicator
        if (totalFrames > 1) {
          LinearProgressIndicator(
            progress = { (currentFrameIndex + 1) / totalFrames.toFloat() },
            modifier = Modifier
              .fillMaxWidth()
              .height(4.dp)
              .clip(RoundedCornerShape(2.dp)),
            color = Color(0xFF38BDF8),
            trackColor = Color(0xFF334155)
          )
          Spacer(modifier = Modifier.height(10.dp))
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onTogglePlay,
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (totalFrames > 1) "फ़्रेम: ${currentFrameIndex + 1}/$totalFrames" else "क्लीन फोटो",
              fontSize = 12.sp,
              color = Color(0xFFE2E8F0)
            )
          }

          Surface(
            onClick = onSaveToGallery,
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF2563EB)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Download,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "गैलरी में सेव करें",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
              )
            }
          }
        }
      }
    }
  }
}
