package com.example.ui.components

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api

import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.Pause
import com.example.ui.ComparisonMode
import com.example.model.GeminiChatMessage
import com.example.model.VideoFrame
import com.example.ui.MainViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeminiAppScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val focusManager = LocalFocusManager.current

  val frames by viewModel.videoFrames.collectAsState()
  val currentFrameIndex by viewModel.currentFrameIndex.collectAsState()
  val isPlaying by viewModel.isPlaying.collectAsState()
  val splitSliderPosition by viewModel.splitSliderPosition.collectAsState()
  val comparisonMode by viewModel.comparisonMode.collectAsState()
  val exportState by viewModel.exportState.collectAsState()
  val statusMessage by viewModel.statusMessage.collectAsState()
  val wallPaintConfig by viewModel.wallPaintConfig.collectAsState()
  val decorItems by viewModel.decorItems.collectAsState()
  val chatMessages by viewModel.chatMessages.collectAsState()
  val isChatAiThinking by viewModel.isChatAiThinking.collectAsState()
  val selectedPresetId by viewModel.selectedPresetId.collectAsState()
  val isDrawerOpen by viewModel.isDrawerOpen.collectAsState()
  val chatSessions by viewModel.chatSessions.collectAsState()
  val currentSessionId by viewModel.currentSessionId.collectAsState()
  val pinnedAttachment by viewModel.pinnedAttachment.collectAsState()
  val fullscreenMediaVisible by viewModel.fullscreenMediaVisible.collectAsState()

  var inputText by remember { mutableStateOf("") }
  var showAttachmentSheet by remember { mutableStateOf(false) }
  var showModelSelectorMenu by remember { mutableStateOf(false) }
  var selectedModelName by remember { mutableStateOf("Gemini Flash") }
  val sheetState = rememberModalBottomSheetState()
  val listState = rememberLazyListState()

  val currentFrame = frames.getOrNull(currentFrameIndex)

  // Video picker contract - Pins video to chat box first as requested
  val videoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    uri?.let {
      viewModel.importVideo(context, it)
      viewModel.pinAttachment(
        title = "घर का वीडियो (Video File)",
        subtitle = "अटैच किया गया वीडियो",
        uri = it
      )
    }
  }

  // Auto-scroll on new message or AI thinking state
  LaunchedEffect(chatMessages.size, isChatAiThinking) {
    if (chatMessages.isNotEmpty()) {
      listState.animateScrollToItem(chatMessages.size)
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF000000))
  ) {
    // Subtle ambient gradient background (matches Google Gemini's dark cosmic depth)
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      // Deep blue/violet bottom-center ambient light
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            Color(0x221E3A8A),
            Color(0x110F172A),
            Color.Transparent
          ),
          center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.82f),
          radius = w * 0.75f
        )
      )
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      // 1. TOP APP BAR (Pixel-identical to Gemini Screenshot)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Left: Gemini Hamburger Menu (= 3 horizontal lines from user screenshot)
        IconButton(
          onClick = { viewModel.openDrawer() },
          modifier = Modifier
            .size(40.dp)
            .testTag("btn_hamburger_menu")
        ) {
          Column(
            modifier = Modifier.width(22.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(Color(0xFFE2E8F0), RoundedCornerShape(1.dp))
            )
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(Color(0xFFE2E8F0), RoundedCornerShape(1.dp))
            )
            Box(
              modifier = Modifier
                .width(16.dp)
                .height(2.dp)
                .background(Color(0xFFE2E8F0), RoundedCornerShape(1.dp))
            )
          }
        }

        // Center: Model Selector ("Gemini Flash v")
        Box {
          Row(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .clickable { showModelSelectorMenu = true }
              .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = selectedModelName,
              fontSize = 17.sp,
              fontWeight = FontWeight.Medium,
              color = Color(0xFFF1F5F9)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Default.KeyboardArrowDown,
              contentDescription = "Select Model",
              tint = Color(0xFF94A3B8),
              modifier = Modifier.size(18.dp)
            )
          }

          DropdownMenu(
            expanded = showModelSelectorMenu,
            onDismissRequest = { showModelSelectorMenu = false }
          ) {
            DropdownMenuItem(
              text = { Text("Gemini Flash (तेज़ और सटीक)") },
              onClick = {
                selectedModelName = "Gemini Flash"
                showModelSelectorMenu = false
              }
            )
            DropdownMenuItem(
              text = { Text("Gemini 2.5 Pro (डीप मेकओवर & इनपेंटिंग)") },
              onClick = {
                selectedModelName = "Gemini 2.5 Pro"
                showModelSelectorMenu = false
              }
            )
          }
        }

        // Right corner: Clean top bar without third-party ID/account avatar
        Spacer(modifier = Modifier.size(40.dp))
      }

      // 2. MAIN BODY: Welcome Greeting or Conversation Stream
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth(),
        contentAlignment = Alignment.Center
      ) {
        if (chatMessages.isEmpty() || (chatMessages.size == 1 && chatMessages.first().isUser.not() && frames.isEmpty())) {
          // Centered Iconic Screen (Exact screenshot match)
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
          ) {

            // Authentic Gemini Gradient Star
            GeminiStarIcon(
              size = 64.dp,
              animated = true
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Hindi Typography: "कहाँ से शुरुआत करें?"
            Text(
              text = "कहाँ से शुरुआत करें?",
              fontSize = 28.sp,
              fontWeight = FontWeight.Normal,
              color = Color(0xFFF1F5F9),
              letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
              text = "कुछ भी पूछें, सीखें, डिवाइस कंट्रोल करें या घर के वीडियो में बदलाव करें",
              fontSize = 13.sp,
              color = Color(0xFF94A3B8),
              lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Three-dots menu revealing all options on tap
            GeminiThreeDotsActionMenu(
              onSelectOption = { prompt ->
                viewModel.sendGeminiChatMessage(prompt)
              },
              tagSuffix = "_welcome"
            )
          }
        } else {
          // Interactive AI Chat Conversation Stream with Embedded Video Previews
          LazyColumn(
            state = listState,
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            items(chatMessages, key = { it.id }) { msg ->
              GeminiChatRow(
                message = msg,
                currentFrame = currentFrame,
                splitSliderPosition = splitSliderPosition,
                comparisonMode = comparisonMode,
                isPlaying = isPlaying,
                totalFrames = frames.size,
                currentFrameIndex = currentFrameIndex,
                wallPaintConfig = wallPaintConfig,
                decorItems = decorItems,
                onSliderChange = { viewModel.setSplitSliderPosition(it) },
                onComparisonModeChange = { viewModel.setComparisonMode(it) },
                onTogglePlay = { viewModel.togglePlayPause() },
                onOpenFullscreen = { viewModel.openFullscreenMedia() },
                onSaveToGallery = { viewModel.saveCleanResultToGallery(context) },
                onPromptClick = { prompt -> viewModel.sendGeminiChatMessage(prompt) },
                onExportClick = { viewModel.startExport(context) }
              )
            }

            if (isChatAiThinking) {
              item {
                Row(
                  modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  GeminiStarIcon(size = 20.dp, animated = true)
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = statusMessage?.ifBlank { "Gemini उत्तर तैयार कर रहा है..." } ?: "Gemini उत्तर तैयार कर रहा है...",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                  )
                }
              }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
          }
        }
      }

      // PINNED ATTACHMENT CARD (User Requirement: Video pins to chat box first before sending)
      if (pinnedAttachment != null) {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("pinned_attachment_card"),
          shape = RoundedCornerShape(16.dp),
          color = Color(0xFF1E2738),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0284C7).copy(alpha = 0.25f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Movie,
                contentDescription = null,
                tint = Color(0xFF38BDF8),
                modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = pinnedAttachment!!.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
              )
              Text(
                text = "📌 चैट में पिन है • इसमें क्या बदलाव करना है नीचे लिखकर भेजें",
                fontSize = 11.sp,
                color = Color(0xFF38BDF8)
              )
            }
            IconButton(
              onClick = { viewModel.unpinAttachment() },
              modifier = Modifier
                .size(32.dp)
                .testTag("btn_unpin_attachment")
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove attachment",
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }
      }

      // 3. BOTTOM GEMINI INPUT PILL (Exact 1:1 match to screenshot, positioned cleanly just above keyboard)
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom))
          .padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 4.dp),
        shape = RoundedCornerShape(32.dp),
        color = Color(0xFF1E2430), // Exact dark charcoal/navy pill from screenshot
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A3444))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Plus (+) Icon for adding video/media
          IconButton(
            onClick = { showAttachmentSheet = true },
            modifier = Modifier
              .size(42.dp)
              .testTag("btn_gemini_plus")
          ) {
            Icon(
              imageVector = Icons.Default.Add,
              contentDescription = "Add media or video",
              tint = Color(0xFFCBD5E1),
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(4.dp))

          // Text Input ("Gemini से कहें")
          Box(
            modifier = Modifier
              .weight(1f)
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.CenterStart
          ) {
            if (inputText.isEmpty()) {
              Text(
                text = "Gemini से कहें",
                fontSize = 16.sp,
                color = Color(0xFF8896A8),
                fontWeight = FontWeight.Normal
              )
            }

            BasicTextField(
              value = inputText,
              onValueChange = { inputText = it },
              textStyle = TextStyle(
                color = Color(0xFFF1F5F9),
                fontSize = 16.sp
              ),
              cursorBrush = SolidColor(Color(0xFF38BDF8)),
              singleLine = false,
              maxLines = 3,
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
              keyboardActions = KeyboardActions(
                onSend = {
                  if (inputText.isNotBlank()) {
                    focusManager.clearFocus()
                    val text = inputText
                    inputText = ""
                    viewModel.sendGeminiChatMessage(text)
                  }
                }
              ),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("gemini_prompt_input")
            )
          }

          Spacer(modifier = Modifier.width(6.dp))

          // Microphone Icon
          IconButton(
            onClick = {
              viewModel.sendGeminiChatMessage("दीवार की सीलन हटाओ और रॉयल ब्लू पेंट लगाओ")
            },
            modifier = Modifier.size(40.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Mic,
              contentDescription = "Voice Input",
              tint = Color(0xFFCBD5E1),
              modifier = Modifier.size(22.dp)
            )
          }

          Spacer(modifier = Modifier.width(4.dp))

          // Rightmost Gemini Live Audio Pulse Button (Circular blue badge with vertical wave bars)
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(Color(0xFF2563EB)) // Google Gemini Royal Blue
              .clickable {
                if (inputText.isNotBlank()) {
                  val text = inputText
                  inputText = ""
                  viewModel.sendGeminiChatMessage(text)
                } else {
                  viewModel.sendGeminiChatMessage("कमरे को मॉडर्न लुक में सजाएं और सुंदर वॉल आर्ट जोड़ें")
                }
              },
            contentAlignment = Alignment.Center
          ) {
            if (inputText.isNotBlank()) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = "Send",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
            } else {
              // Exact 3 audio wave bars ("|||")
              Row(
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .width(2.5.dp)
                    .height(10.dp)
                    .background(Color.White, RoundedCornerShape(1.dp))
                )
                Box(
                  modifier = Modifier
                    .width(2.5.dp)
                    .height(18.dp)
                    .background(Color.White, RoundedCornerShape(1.dp))
                )
                Box(
                  modifier = Modifier
                    .width(2.5.dp)
                    .height(12.dp)
                    .background(Color.White, RoundedCornerShape(1.dp))
                )
              }
            }
          }
        }
      }
    }
  }

  // ATTACHMENT BOTTOM SHEET (Invoked from Plus (+) icon)
  if (showAttachmentSheet) {
    ModalBottomSheet(
      onDismissRequest = { showAttachmentSheet = false },
      sheetState = sheetState,
      containerColor = Color(0xFF141A24),
      scrimColor = Color.Black.copy(alpha = 0.65f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 12.dp)
          .navigationBarsPadding()
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "वीडियो जोड़ें और AI से बदलाव करवाएं",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFF1F5F9)
          )
          IconButton(onClick = { showAttachmentSheet = false }) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Option 1: Pick from Device
        Surface(
          onClick = {
            showAttachmentSheet = false
            videoPicker.launch("video/*")
          },
          shape = RoundedCornerShape(16.dp),
          color = Color(0xFF1E2738),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xFF0284C7)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = Color.White)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
              Text("डिवाइस से वीडियो चुनें (Gallery)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
              Text("अपने घर, दीवार या कमरे का MP4/MOV वीडियो", fontSize = 12.sp, color = Color(0xFF94A3B8))
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "या टेस्ट सैंपल वीडियो आज़माएं:",
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          color = Color(0xFF94A3B8)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Option 2: Dampness Test Video (Pins to chat box first)
        Surface(
          onClick = {
            showAttachmentSheet = false
            viewModel.loadPreset("dampness")
            viewModel.pinAttachment(
              title = "दीवार की सीलन (Seepage Video)",
              subtitle = "कमरे का वीडियो",
              presetId = "dampness"
            )
          },
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFF192230),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("preset_dampness_pin")
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.VideoFile, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("दीवार की सीलन (Wall Moisture Seepage)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
              Text("अवांछित पानी के दाग और सीलन हटाने का वीडियो (पिन करें)", fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Option 3: Floor Litter Test Video (Pins to chat box first)
        Surface(
          onClick = {
            showAttachmentSheet = false
            viewModel.loadPreset("litter")
            viewModel.pinAttachment(
              title = "फर्श का कचरा (Litter Video)",
              subtitle = "कमरे का वीडियो",
              presetId = "litter"
            )
          },
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFF192230),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("preset_litter_pin")
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Movie, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("फर्श का कचरा (Floor Litter & Trash)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
              Text("टाइल पर पड़ा कचरा व प्लास्टिक हटाने का वीडियो (पिन करें)", fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))
      }
    }
  }

  // Export Progress / Completion Dialog
  if (exportState.isExporting || exportState.isComplete) {
    ExportDialog(
      exportState = exportState,
      onDismiss = { viewModel.dismissExportDialog() }
    )
  }

  // Gemini Navigation Drawer (Recent Saved Chats Sidebar from user screenshot)
  GeminiNavigationDrawer(
    isOpen = isDrawerOpen,
    onClose = { viewModel.closeDrawer() },
    sessions = chatSessions,
    currentSessionId = currentSessionId,
    onNewChat = { viewModel.startNewChat() },
    onSelectSession = { viewModel.loadChatSession(it) },
    onDeleteSession = { viewModel.deleteChatSession(it) }
  )

  // Fullscreen Media Viewer for AI output video/photo (NO Before/After lines)
  if (fullscreenMediaVisible && currentFrame != null) {
    FullscreenMediaViewer(
      bitmap = currentFrame.cleanedBitmap ?: currentFrame.originalBitmap,
      isPlaying = isPlaying,
      currentFrameIndex = currentFrameIndex,
      totalFrames = frames.size,
      onTogglePlay = { viewModel.togglePlayPause() },
      onSaveToGallery = { viewModel.saveCleanResultToGallery(context) },
      onClose = { viewModel.closeFullscreenMedia() }
    )
  }
}

/**
 * Chat row representing either User prompt or Gemini AI response
 * including live interactive Video Inpainting Before/After preview.
 */
@Composable
private fun GeminiChatRow(
  message: GeminiChatMessage,
  currentFrame: VideoFrame?,
  splitSliderPosition: Float,
  comparisonMode: ComparisonMode,
  isPlaying: Boolean,
  totalFrames: Int,
  currentFrameIndex: Int,
  wallPaintConfig: com.example.model.WallPaintConfig,
  decorItems: List<com.example.model.DecorItem>,
  onSliderChange: (Float) -> Unit,
  onComparisonModeChange: (ComparisonMode) -> Unit,
  onTogglePlay: () -> Unit,
  onOpenFullscreen: () -> Unit,
  onSaveToGallery: () -> Unit,
  onPromptClick: (String) -> Unit,
  onExportClick: () -> Unit
) {
  if (message.isUser) {
    // User message bubble (Right aligned, pill styled)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.End
    ) {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF1E293B),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
      ) {
        Text(
          text = message.text,
          fontSize = 15.sp,
          color = Color(0xFFF1F5F9),
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
      }
    }
  } else {
    // Gemini AI Response (Left aligned with Gemini Star icon and rich video result)
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.Start
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 6.dp)
      ) {
        GeminiStarIcon(size = 18.dp, animated = false)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Gemini",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF38BDF8)
        )
      }

      // Gemini Response text
      Text(
        text = message.text,
        fontSize = 14.sp,
        color = Color(0xFFE2E8F0),
        lineHeight = 20.sp,
        modifier = Modifier.padding(start = 26.dp)
      )

      // If video frames are loaded, render interactive Split Slider & Video Player
      if (currentFrame != null) {
        Spacer(modifier = Modifier.height(12.dp))

        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .padding(start = 26.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF263346), RoundedCornerShape(16.dp)),
          color = Color(0xFF0F172A)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            // Split Before/After Preview
            SplitPreviewSlider(
              originalBitmap = currentFrame.originalBitmap,
              cleanedBitmap = currentFrame.cleanedBitmap,
              sliderPosition = splitSliderPosition,
              comparisonMode = comparisonMode,
              onSliderPositionChanged = onSliderChange,
              onComparisonModeChanged = onComparisonModeChange
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Video Actions: Play without saving to gallery, watch fullscreen, and save to gallery
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Left: Play/Pause button (बिना गैलरी में लिए सीधे चैट में वीडियो चलाएं)
              Surface(
                onClick = onTogglePlay,
                shape = RoundedCornerShape(10.dp),
                color = if (isPlaying) Color(0xFFE11D48) else Color(0xFF0284C7),
                modifier = Modifier.testTag("btn_play_video_chat")
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = if (isPlaying) "रोकें" else "चलाएं",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }

              // Right: Fullscreen Viewer & Save to Gallery
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // In-App Fullscreen View (बिना गैलरी में लिए फुल स्क्रीन में देखें)
                Surface(
                  onClick = onOpenFullscreen,
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFF1E293B),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF475569)),
                  modifier = Modifier.testTag("btn_fullscreen_chat")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.Fullscreen,
                      contentDescription = "Fullscreen",
                      tint = Color(0xFF38BDF8),
                      modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "फुलस्क्रीन",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Medium,
                      color = Color(0xFFF1F5F9)
                    )
                  }
                }

                // Direct Save to Gallery button (गैलरी में लेकर भी देख सके)
                Surface(
                  onClick = onSaveToGallery,
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFF0F766E),
                  modifier = Modifier.testTag("btn_save_to_gallery_chat")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.Download,
                      contentDescription = "Save to Gallery",
                      tint = Color.White,
                      modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "गैलरी में सेव",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = Color.White
                    )
                  }
                }

                // Export Button
                Surface(
                  onClick = onExportClick,
                  shape = RoundedCornerShape(10.dp),
                  color = Color(0xFF2563EB),
                  modifier = Modifier.testTag("btn_export_chat")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.Download,
                      contentDescription = "Export",
                      tint = Color.White,
                      modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "एक्सपोर्ट",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Three-dots menu replacing the horizontal suggestion chips
      if (!message.isUser) {
        Spacer(modifier = Modifier.height(6.dp))
        GeminiThreeDotsActionMenu(
          onSelectOption = { prompt -> onPromptClick(prompt) },
          modifier = Modifier.padding(start = 26.dp),
          tagSuffix = "_chat_${message.id}"
        )
      }
    }
  }
}
