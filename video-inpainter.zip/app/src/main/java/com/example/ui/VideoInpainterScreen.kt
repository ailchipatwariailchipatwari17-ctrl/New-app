package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.ui.components.GeminiAppScreen

@Composable
fun VideoInpainterScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  // Pure Gemini AI Interface (1:1 with user's uploaded screenshot)
  GeminiAppScreen(
    viewModel = viewModel,
    modifier = modifier
  )
}
