package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class GeminiActionOption(
  val label: String,
  val category: String,
  val emoji: String,
  val prompt: String
)

val GEMINI_FULL_OPTIONS = listOf(
  GeminiActionOption("मनाली घूमने का 3-दिवसीय प्लान", "यात्रा व टूर", "✈️", "मनाली घूमने का 3 दिन का पूरा प्लान और बजट बताओ"),
  GeminiActionOption("सूर्य का प्रकाश पृथ्वी तक आने का समय", "विज्ञान व अंतरिक्ष", "☀️", "सूर्य के प्रकाश को पृथ्वी तक पहुँचने में कितना समय लगता है?"),
  GeminiActionOption("गणित हल करो (BODMAS)", "गणित व गणना", "🔢", "1450 + 850 * 2 का हल बताओ"),
  GeminiActionOption("ज़रूरी बातचीत व मीटिंग कैसे करें", "पर्सनल गाइड", "💼", "किसी भी ज़रूरी बातचीत को प्रभावी बनाने के नियम बताओ"),
  GeminiActionOption("पायथन में लूप्स कैसे काम करते हैं", "कोडिंग व टेक", "💻", "Python में Loops कैसे काम करते हैं उदाहरण सहित समझाओ"),
  GeminiActionOption("यूट्यूब खोलो", "डिवाइस कंट्रोल", "▶️", "यूट्यूब खोलो"),
  GeminiActionOption("दीवार से सीलन हटाओ", "क्लीन व इनपेंट", "💧", "दीवार से सीलन व नमी पूरी तरह हटा दो"),
  GeminiActionOption("दीवार पर रॉयल ब्लू पेंट लगाओ", "रंग व पेंट", "🎨", "दीवार पर रॉयल ब्लू पेंट लगाओ"),
  GeminiActionOption("फर्श का कचरा साफ़ करो", "क्लीन व इनपेंट", "🧹", "फर्श से सारा कचरा और दाग साफ़ करो"),
  GeminiActionOption("लक्ज़री वॉल आर्ट फ्रेम लगाएं", "होम डेकोर", "🖼️", "दीवार पर लक्ज़री वॉल आर्ट फ्रेम लगाओ"),
  GeminiActionOption("कमरे में इनडोर प्लांट रखें", "होम डेकोर", "🪴", "कमरे में इनडोर मॉन्स्टेरा प्लांट रखो"),
  GeminiActionOption("गैलरी में वीडियो सेव करें", "आउटपुट", "📥", "साफ़ वीडियो गैलरी में सेव करो")
)

/**
 * Sleek Three-Dots Action Button and Menu.
 * Replaces hardcoded starter pills and prompts as explicitly requested.
 */
@Composable
fun GeminiThreeDotsActionMenu(
  onSelectOption: (String) -> Unit,
  modifier: Modifier = Modifier,
  tagSuffix: String = ""
) {
  var isMenuExpanded by remember { mutableStateOf(false) }

  Box(modifier = modifier) {
    // Elegant 3-Dots Button
    Surface(
      onClick = { isMenuExpanded = true },
      shape = RoundedCornerShape(20.dp),
      color = Color(0xFF1E293B),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
      modifier = Modifier.testTag("btn_three_dots$tagSuffix")
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Icon(
          imageVector = Icons.Default.MoreHoriz,
          contentDescription = "सभी विकल्प (More Options)",
          tint = Color(0xFF38BDF8),
          modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "सभी विकल्प",
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          color = Color(0xFFE2E8F0)
        )
      }
    }

    DropdownMenu(
      expanded = isMenuExpanded,
      onDismissRequest = { isMenuExpanded = false },
      modifier = Modifier
        .background(Color(0xFF0F172A))
        .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
        .testTag("dropdown_three_dots_menu$tagSuffix")
    ) {
      Text(
        text = "सुझाए गए विकल्प व टूल्स",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF94A3B8),
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
      )
      HorizontalDivider(color = Color(0xFF1E293B))

      GEMINI_FULL_OPTIONS.forEach { opt ->
        DropdownMenuItem(
          text = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = opt.emoji,
                fontSize = 16.sp
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = opt.label,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = Color(0xFFF1F5F9)
                )
                Text(
                  text = opt.category,
                  fontSize = 10.sp,
                  color = Color(0xFF64748B)
                )
              }
            }
          },
          onClick = {
            isMenuExpanded = false
            onSelectOption(opt.prompt)
          },
          modifier = Modifier.testTag("menu_item_${opt.label.take(8)}")
        )
      }
    }
  }
}
