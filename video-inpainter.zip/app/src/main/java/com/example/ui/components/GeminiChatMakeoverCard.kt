package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Yard
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DecorItem
import com.example.model.DecorType
import com.example.model.GeminiChatMessage
import com.example.model.WallPaintConfig
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GeminiChatMakeoverCard(
  chatMessages: List<GeminiChatMessage>,
  isAiThinking: Boolean,
  wallPaintConfig: WallPaintConfig,
  decorItems: List<DecorItem>,
  onSendMessage: (String) -> Unit,
  onSelectColor: (Long, String, String) -> Unit,
  onAddDecor: (DecorType, String, String) -> Unit,
  onClearDecor: () -> Unit,
  onRemoveDecor: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var userInput by remember { mutableStateOf("") }
  val focusManager = LocalFocusManager.current
  val listState = rememberLazyListState()

  // Auto-scroll to latest message
  LaunchedEffect(chatMessages.size, isAiThinking) {
    if (chatMessages.isNotEmpty()) {
      listState.animateScrollToItem(chatMessages.size - 1)
    }
  }

  // Pre-configured elegant wall paint palette
  val paintPalettes = listOf(
    Triple(0xFF1E3A8A, "रॉयल ब्लू", "Royal Blue"),
    Triple(0xFF2D5A43, "सेज ग्रीन", "Sage Green"),
    Triple(0xFF9C4221, "वार्म टेराकोटा", "Terracotta"),
    Triple(0xFFFDFBF7, "आइवरी क्रीम", "Ivory Cream"),
    Triple(0xFF334155, "स्लेट ग्रे", "Slate Grey")
  )

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(18.dp))
      .border(
        width = 1.dp,
        brush = Brush.linearGradient(
          colors = listOf(
            CyanPrimary.copy(alpha = 0.6f),
            Color(0xFF8B5CF6).copy(alpha = 0.6f)
          )
        ),
        shape = RoundedCornerShape(18.dp)
      ),
    color = Color(0xFF0D131F),
    shape = RoundedCornerShape(18.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      // Top Gemini AI Branding Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(
                Brush.linearGradient(
                  colors = listOf(CyanPrimary, Color(0xFF8B5CF6), Color(0xFFEC4899))
                )
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = Color.Black,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Gemini AI Home Makeover",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(Color(0xFF8B5CF6).copy(alpha = 0.25f))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "LIVE CHAT",
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFC084FC)
                )
              }
            }
            Text(
              text = "चैट करके घर का वीडियो बदलें व सजाएं",
              fontSize = 11.sp,
              color = TextSecondary
            )
          }
        }

        if (wallPaintConfig.enabled || decorItems.isNotEmpty()) {
          IconButton(
            onClick = onClearDecor,
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Delete,
              contentDescription = "Clear Makeover",
              tint = Color(0xFFF43F5E),
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Active Makeover Badges (Shows currently active Wall Color & Decors)
      if (wallPaintConfig.enabled || decorItems.isNotEmpty()) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (wallPaintConfig.enabled) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(wallPaintConfig.colorHex).copy(alpha = 0.35f))
                .border(1.dp, Color(wallPaintConfig.colorHex), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Color(wallPaintConfig.colorHex))
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                  text = "दीवार: ${wallPaintConfig.colorNameHindi}",
                  fontSize = 10.sp,
                  color = TextPrimary,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }

          decorItems.forEach { item ->
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E293B))
                .border(1.dp, CyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "✨ ${item.nameHindi}",
                  fontSize = 10.sp,
                  color = TextPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                  imageVector = Icons.Default.Clear,
                  contentDescription = "Remove",
                  tint = TextMuted,
                  modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                )
              }
            }
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
      }

      // Chat Messages History Box
      LazyColumn(
        state = listState,
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 240.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF090E17))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(chatMessages, key = { it.id }) { msg ->
          ChatBubble(msg = msg, onPromptClick = { prompt -> onSendMessage(prompt) })
        }

        if (isAiThinking) {
          item {
            Row(
              modifier = Modifier.padding(start = 4.dp, top = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              CircularProgressIndicator(
                modifier = Modifier.size(14.dp),
                color = CyanPrimary,
                strokeWidth = 2.dp
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Gemini वीडियो में बदलाव लागू कर रहा है...",
                fontSize = 11.sp,
                color = CyanGlow
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Quick Makeover Shortcuts Toolbar (Wall Color & Decors)
      Text(
        text = "त्वरित सजावट शॉर्टकट्स (Quick Add):",
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = TextSecondary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Wall Color chips
        paintPalettes.forEach { (colorHex, nameHi, nameEn) ->
          FilterChip(
            selected = wallPaintConfig.enabled && wallPaintConfig.colorHex == colorHex,
            onClick = { onSelectColor(colorHex, nameHi, nameEn) },
            label = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Color(colorHex))
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(nameHi, fontSize = 11.sp)
              }
            },
            colors = FilterChipDefaults.filterChipColors(
              containerColor = Color(0xFF182232),
              selectedContainerColor = Color(colorHex).copy(alpha = 0.4f)
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = wallPaintConfig.enabled && wallPaintConfig.colorHex == colorHex,
              borderColor = DarkSurfaceBorder,
              selectedBorderColor = Color(colorHex)
            ),
            shape = RoundedCornerShape(8.dp)
          )
        }

        // Add Wall Art
        FilterChip(
          selected = false,
          onClick = { onAddDecor(DecorType.WALL_ART_FRAME, "लक्ज़री वॉल आर्ट", "Wall Art Frame") },
          label = { Text("+ 🖼️ वॉल आर्ट", fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(containerColor = Color(0xFF182232)),
          border = FilterChipDefaults.filterChipBorder(enabled = true, selected = false, borderColor = DarkSurfaceBorder),
          shape = RoundedCornerShape(8.dp)
        )

        // Add Clock
        FilterChip(
          selected = false,
          onClick = { onAddDecor(DecorType.WALL_CLOCK, "आधुनिक घड़ी", "Wall Clock") },
          label = { Text("+ ⏱️ घड़ी", fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(containerColor = Color(0xFF182232)),
          border = FilterChipDefaults.filterChipBorder(enabled = true, selected = false, borderColor = DarkSurfaceBorder),
          shape = RoundedCornerShape(8.dp)
        )

        // Add Plant
        FilterChip(
          selected = false,
          onClick = { onAddDecor(DecorType.INDOOR_PLANT, "इनडोर पौधा", "Indoor Plant") },
          label = { Text("+ 🌿 पौधा", fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(containerColor = Color(0xFF182232)),
          border = FilterChipDefaults.filterChipBorder(enabled = true, selected = false, borderColor = DarkSurfaceBorder),
          shape = RoundedCornerShape(8.dp)
        )

        // Add Pendant Lamp
        FilterChip(
          selected = false,
          onClick = { onAddDecor(DecorType.LIGHT_FIXTURE, "हैंगिंग लैंप", "Pendant Lamp") },
          label = { Text("+ 💡 लैंप", fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(containerColor = Color(0xFF182232)),
          border = FilterChipDefaults.filterChipBorder(enabled = true, selected = false, borderColor = DarkSurfaceBorder),
          shape = RoundedCornerShape(8.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Input Field + Send Button (Gemini Chat Prompt Bar)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = userInput,
          onValueChange = { userInput = it },
          placeholder = {
            Text(
              text = "Gemini को बताएं: 'दीवार का रंग हरा करो'...",
              fontSize = 12.sp,
              color = TextMuted
            )
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
          keyboardActions = KeyboardActions(
            onSend = {
              focusManager.clearFocus()
              if (userInput.isNotBlank()) {
                onSendMessage(userInput)
                userInput = ""
              }
            }
          ),
          trailingIcon = {
            if (userInput.isNotEmpty()) {
              IconButton(onClick = { userInput = "" }) {
                Icon(
                  imageVector = Icons.Default.Clear,
                  contentDescription = "Clear",
                  tint = TextMuted,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CyanPrimary,
            unfocusedBorderColor = DarkSurfaceBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedContainerColor = Color(0xFF141C2B),
            unfocusedContainerColor = Color(0xFF141C2B)
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("gemini_chat_input")
        )

        Spacer(modifier = Modifier.width(8.dp))

        Button(
          onClick = {
            focusManager.clearFocus()
            if (userInput.isNotBlank()) {
              onSendMessage(userInput)
              userInput = ""
            }
          },
          enabled = !isAiThinking && userInput.isNotBlank(),
          colors = ButtonDefaults.buttonColors(
            containerColor = CyanPrimary,
            contentColor = Color.Black,
            disabledContainerColor = DarkSurfaceBorder,
            disabledContentColor = TextMuted
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .height(50.dp)
            .testTag("btn_gemini_send")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send",
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun ChatBubble(
  msg: GeminiChatMessage,
  onPromptClick: (String) -> Unit
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
  ) {
    Surface(
      color = if (msg.isUser) Color(0xFF0284C7) else Color(0xFF1E293B),
      shape = RoundedCornerShape(
        topStart = 14.dp,
        topEnd = 14.dp,
        bottomStart = if (msg.isUser) 14.dp else 2.dp,
        bottomEnd = if (msg.isUser) 2.dp else 14.dp
      ),
      border = if (!msg.isUser) {
        androidx.compose.foundation.BorderStroke(1.dp, CyanPrimary.copy(alpha = 0.3f))
      } else null
    ) {
      Column(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
      ) {
        if (!msg.isUser) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = CyanPrimary,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Gemini AI",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = CyanPrimary
            )
          }
        }

        Text(
          text = msg.text,
          fontSize = 12.sp,
          color = Color.White,
          lineHeight = 16.sp
        )

        if (msg.actionApplied != null) {
          Spacer(modifier = Modifier.height(4.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = Color(0xFF10B981),
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = msg.actionApplied,
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF10B981)
            )
          }
        }
      }
    }

    // Suggested next prompts from Gemini AI
    if (msg.suggestedPrompts.isNotEmpty()) {
      Spacer(modifier = Modifier.height(4.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        msg.suggestedPrompts.forEach { prompt ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFF18202F))
              .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(6.dp))
              .padding(horizontal = 6.dp, vertical = 3.dp)
              .clickable { onPromptClick(prompt) }
          ) {
            Text(
              text = "💬 $prompt",
              fontSize = 10.sp,
              color = TextSecondary
            )
          }
        }
      }
    }
  }
}
