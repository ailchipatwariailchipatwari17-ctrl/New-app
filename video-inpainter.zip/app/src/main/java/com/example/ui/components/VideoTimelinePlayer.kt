package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VideoFrame
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun VideoTimelinePlayer(
  frames: List<VideoFrame>,
  currentFrameIndex: Int,
  isPlaying: Boolean,
  playbackSpeed: Float,
  onFrameSelected: (Int) -> Unit,
  onStepFrame: (Int) -> Unit,
  onTogglePlayPause: () -> Unit,
  onSpeedChanged: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  val totalFrames = frames.size.coerceAtLeast(1)
  val currentFrame = frames.getOrNull(currentFrameIndex)
  val timestampMs = currentFrame?.timestampMs ?: 0L

  val minutes = (timestampMs / 60000)
  val seconds = (timestampMs % 60000) / 1000
  val millis = (timestampMs % 1000) / 10
  val formattedTime = String.format("%02d:%02d.%02d", minutes, seconds, millis)

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("video_timeline_player"),
    shape = RoundedCornerShape(16.dp),
    color = DarkSurfaceElevated,
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
      // Top info row: Frame info & Timestamp badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(if (isPlaying) Color(0xFF10B981) else AmberAccentColor)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Frame ${currentFrameIndex + 1} / $totalFrames",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.4f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Text(
            text = formattedTime,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = CyanGlow
          )
        }
      }

      // Precise Timeline Scrubber Slider
      Slider(
        value = currentFrameIndex.toFloat(),
        onValueChange = { onFrameSelected(it.toInt()) },
        valueRange = 0f..(totalFrames - 1).toFloat().coerceAtLeast(1f),
        colors = SliderDefaults.colors(
          thumbColor = CyanPrimary,
          activeTrackColor = CyanPrimary,
          inactiveTrackColor = DarkSurfaceBorder
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("timeline_slider")
      )

      // Playback Controls Row: Step <<, Play/Pause, Step >>, Speed Options
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Frame navigation controls
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = { onStepFrame(-1) },
            modifier = Modifier.size(38.dp).testTag("btn_prev_frame")
          ) {
            Icon(
              imageVector = Icons.Default.SkipPrevious,
              contentDescription = "Previous Frame",
              tint = TextSecondary,
              modifier = Modifier.size(22.dp)
            )
          }

          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(CyanPrimary)
              .clickable { onTogglePlayPause() }
              .testTag("btn_play_pause"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = if (isPlaying) "Pause" else "Play",
              tint = Color.Black,
              modifier = Modifier.size(26.dp)
            )
          }

          IconButton(
            onClick = { onStepFrame(1) },
            modifier = Modifier.size(38.dp).testTag("btn_next_frame")
          ) {
            Icon(
              imageVector = Icons.Default.SkipNext,
              contentDescription = "Next Frame",
              tint = TextSecondary,
              modifier = Modifier.size(22.dp)
            )
          }
        }

        // Playback Speed Chips (0.5x, 1x, 2x)
        Row(
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          listOf(0.5f, 1.0f, 2.0f).forEach { speed ->
            val isSelected = playbackSpeed == speed
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) CyanPrimary.copy(alpha = 0.25f) else Color.Transparent)
                .clickable { onSpeedChanged(speed) }
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .testTag("speed_chip_${speed}x"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "${speed}x",
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) CyanGlow else TextMuted
              )
            }
          }
        }
      }
    }
  }
}

private val AmberAccentColor = Color(0xFFF59E0B)
