package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.GalleryExporter
import com.example.engine.InpaintingEngine
import com.example.engine.SampleVideoGenerator
import com.example.engine.VideoExporter
import com.example.model.BrushPoint
import com.example.model.BrushStroke
import com.example.model.ChatSession
import com.example.model.ClonePatchConfig
import com.example.model.DecorItem
import com.example.model.DecorType
import com.example.model.ExportState
import com.example.model.GeminiChatMessage
import com.example.model.InpaintingEngineMode
import com.example.model.MaskTool
import com.example.model.PinnedAttachment
import com.example.model.TextCommandResult
import com.example.model.VideoFrame
import com.example.model.WallPaintConfig
import com.example.model.WorkflowStep
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class ComparisonMode {
  SPLIT_SLIDER,
  SIDE_BY_SIDE,
  CLEANED_ONLY,
  ORIGINAL_ONLY
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val _workflowStep = MutableStateFlow(WorkflowStep.IMPORT)
  val workflowStep: StateFlow<WorkflowStep> = _workflowStep.asStateFlow()

  private val _videoFrames = MutableStateFlow<List<VideoFrame>>(emptyList())
  val videoFrames: StateFlow<List<VideoFrame>> = _videoFrames.asStateFlow()

  private val _currentFrameIndex = MutableStateFlow(0)
  val currentFrameIndex: StateFlow<Int> = _currentFrameIndex.asStateFlow()

  private val _isPlaying = MutableStateFlow(false)
  val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

  private val _playbackSpeed = MutableStateFlow(1.0f)
  val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

  private val _activeMaskTool = MutableStateFlow(MaskTool.CLONE_PATCH)
  val activeMaskTool: StateFlow<MaskTool> = _activeMaskTool.asStateFlow()

  private val _brushStrokes = MutableStateFlow<List<BrushStroke>>(emptyList())
  val brushStrokes: StateFlow<List<BrushStroke>> = _brushStrokes.asStateFlow()

  private val _brushRadius = MutableStateFlow(24f)
  val brushRadius: StateFlow<Float> = _brushRadius.asStateFlow()

  private val _brushFeather = MutableStateFlow(0.5f)
  val brushFeather: StateFlow<Float> = _brushFeather.asStateFlow()

  private val _cloneConfig = MutableStateFlow(ClonePatchConfig())
  val cloneConfig: StateFlow<ClonePatchConfig> = _cloneConfig.asStateFlow()

  private val _inpaintingMode = MutableStateFlow(InpaintingEngineMode.LOCAL_FREEZE_PATCH)
  val inpaintingMode: StateFlow<InpaintingEngineMode> = _inpaintingMode.asStateFlow()

  private val _autoTrack = MutableStateFlow(true)
  val autoTrack: StateFlow<Boolean> = _autoTrack.asStateFlow()

  private val _splitSliderPosition = MutableStateFlow(0.5f)
  val splitSliderPosition: StateFlow<Float> = _splitSliderPosition.asStateFlow()

  // Default to CLEANED_ONLY so NO Before/After split line appears in the AI result!
  private val _comparisonMode = MutableStateFlow(ComparisonMode.CLEANED_ONLY)
  val comparisonMode: StateFlow<ComparisonMode> = _comparisonMode.asStateFlow()

  private val _exportState = MutableStateFlow(ExportState())
  val exportState: StateFlow<ExportState> = _exportState.asStateFlow()

  private val _isProcessing = MutableStateFlow(false)
  val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

  private val _statusMessage = MutableStateFlow<String?>(null)
  val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

  private val _textCommandResult = MutableStateFlow<TextCommandResult?>(null)
  val textCommandResult: StateFlow<TextCommandResult?> = _textCommandResult.asStateFlow()

  private val _isProcessingTextPrompt = MutableStateFlow(false)
  val isProcessingTextPrompt: StateFlow<Boolean> = _isProcessingTextPrompt.asStateFlow()

  private val _selectedPresetId = MutableStateFlow("dampness")
  val selectedPresetId: StateFlow<String> = _selectedPresetId.asStateFlow()

  // Pinned attachment in chat box (User requirement: pins before sharing so user can write instructions)
  private val _pinnedAttachment = MutableStateFlow<PinnedAttachment?>(null)
  val pinnedAttachment: StateFlow<PinnedAttachment?> = _pinnedAttachment.asStateFlow()

  // Gemini Navigation Drawer state
  private val _isDrawerOpen = MutableStateFlow(false)
  val isDrawerOpen: StateFlow<Boolean> = _isDrawerOpen.asStateFlow()

  // Fullscreen photo / video viewer dialog state
  private val _fullscreenMediaVisible = MutableStateFlow(false)
  val fullscreenMediaVisible: StateFlow<Boolean> = _fullscreenMediaVisible.asStateFlow()

  // Chat Sessions ("हाल ही के" - Auto-saved past chats matching screenshot)
  private val _currentSessionId = MutableStateFlow(UUID.randomUUID().toString())
  val currentSessionId: StateFlow<String> = _currentSessionId.asStateFlow()

  private val _chatSessions = MutableStateFlow<List<ChatSession>>(
    listOf(
      ChatSession(
        id = "session_dampness",
        title = "दीवार की सीलन और नमी साफ़ करना",
        presetId = "dampness",
        timestampMs = System.currentTimeMillis() - 3600000L
      ),
      ChatSession(
        id = "session_blue_art",
        title = "रॉयल ब्लू पेंट और गोल्डन वॉल आर्ट",
        presetId = "dampness",
        wallPaintConfig = WallPaintConfig(enabled = true, colorNameHindi = "रॉयल ब्लू", colorHex = 0xFF1E3A8A),
        timestampMs = System.currentTimeMillis() - 7200000L
      ),
      ChatSession(
        id = "session_hall_plants",
        title = "हॉल मेकओवर और इंडोर प्लांट",
        presetId = "dampness",
        timestampMs = System.currentTimeMillis() - 86400000L
      ),
      ChatSession(
        id = "session_litter_floor",
        title = "फर्श का कचरा हटाना",
        presetId = "litter",
        timestampMs = System.currentTimeMillis() - 172800000L
      )
    )
  )
  val chatSessions: StateFlow<List<ChatSession>> = _chatSessions.asStateFlow()

  // Gemini AI Chat & Home Makeover states
  private val _wallPaintConfig = MutableStateFlow(WallPaintConfig())
  val wallPaintConfig: StateFlow<WallPaintConfig> = _wallPaintConfig.asStateFlow()

  private val _decorItems = MutableStateFlow<List<DecorItem>>(emptyList())
  val decorItems: StateFlow<List<DecorItem>> = _decorItems.asStateFlow()

  private val _chatMessages = MutableStateFlow<List<GeminiChatMessage>>(emptyList())
  val chatMessages: StateFlow<List<GeminiChatMessage>> = _chatMessages.asStateFlow()

  private val _isChatAiThinking = MutableStateFlow(false)
  val isChatAiThinking: StateFlow<Boolean> = _isChatAiThinking.asStateFlow()

  private var playbackJob: Job? = null

  init {
    // App opens completely clean. No automatic video or greeting response until user sends a message.
  }

  fun setWorkflowStep(step: WorkflowStep) {
    _workflowStep.value = step
    if (step == WorkflowStep.PREVIEW_EXPORT) {
      applyInpaintingToAllFrames()
    }
  }

  fun loadPreset(presetId: String) {
    viewModelScope.launch {
      _isProcessing.value = true
      _selectedPresetId.value = presetId
      val preset = SampleVideoGenerator.PRESETS.find { it.id == presetId }
      val frames = SampleVideoGenerator.generatePresetFrames(
        context = getApplication(),
        presetId = presetId
      )
      _videoFrames.value = frames
      _currentFrameIndex.value = 0

      if (preset != null) {
        _cloneConfig.value = ClonePatchConfig(
          sourceX = preset.defaultSource.x,
          sourceY = preset.defaultSource.y,
          targetX = preset.defaultTarget.x,
          targetY = preset.defaultTarget.y,
          radius = preset.defaultRadius
        )
      }
      _isProcessing.value = false
      applyInpaintingToCurrentFrame()
    }
  }

  fun importVideo(context: Context, uri: Uri) {
    viewModelScope.launch {
      _isProcessing.value = true
      _statusMessage.value = "Extracting video frames..."
      val frames = SampleVideoGenerator.extractFramesFromUri(context, uri)
      _videoFrames.value = frames
      _currentFrameIndex.value = 0
      _isProcessing.value = false
      _statusMessage.value = "Video imported: ${frames.size} frames loaded"

      // Trigger AI Auto-Detection for the imported video
      if (frames.isNotEmpty()) {
        val detected = InpaintingEngine.autoDetectBlemishPatch(frames[0].originalBitmap)
        _cloneConfig.value = detected
        applyInpaintingToCurrentFrame()
      }
    }
  }

  fun setCurrentFrame(index: Int) {
    val frames = _videoFrames.value
    if (frames.isNotEmpty()) {
      _currentFrameIndex.value = index.coerceIn(0, frames.size - 1)
      applyInpaintingToCurrentFrame()
    }
  }

  fun stepFrame(delta: Int) {
    val frames = _videoFrames.value
    if (frames.isNotEmpty()) {
      val next = (_currentFrameIndex.value + delta + frames.size) % frames.size
      setCurrentFrame(next)
    }
  }

  fun togglePlayPause() {
    val playing = !_isPlaying.value
    _isPlaying.value = playing
    if (playing) {
      startPlayback()
    } else {
      playbackJob?.cancel()
    }
  }

  private fun startPlayback() {
    playbackJob?.cancel()
    playbackJob = viewModelScope.launch {
      while (_isPlaying.value) {
        val frames = _videoFrames.value
        if (frames.isEmpty()) break
        val interval = (66f / _playbackSpeed.value).toLong().coerceAtLeast(16L)
        delay(interval)
        val next = (_currentFrameIndex.value + 1) % frames.size
        _currentFrameIndex.value = next
      }
    }
  }

  fun setPlaybackSpeed(speed: Float) {
    _playbackSpeed.value = speed
    if (_isPlaying.value) {
      startPlayback()
    }
  }

  fun setMaskTool(tool: MaskTool) {
    _activeMaskTool.value = tool
  }

  fun setBrushRadius(radius: Float) {
    _brushRadius.value = radius
  }

  fun setBrushFeather(feather: Float) {
    _brushFeather.value = feather
  }

  fun updateCloneConfig(update: (ClonePatchConfig) -> ClonePatchConfig) {
    _cloneConfig.update(update)
    applyInpaintingToCurrentFrame()
  }

  fun addBrushPoint(x: Float, y: Float, isStart: Boolean) {
    val current = _brushStrokes.value.toMutableList()
    if (isStart || current.isEmpty()) {
      val newStroke = BrushStroke(
        points = listOf(BrushPoint(x, y)),
        radius = _brushRadius.value,
        feather = _brushFeather.value,
        isEraser = _activeMaskTool.value == MaskTool.ERASER
      )
      current.add(newStroke)
    } else {
      val lastIndex = current.size - 1
      val lastStroke = current[lastIndex]
      val updatedPoints = lastStroke.points + BrushPoint(x, y)
      current[lastIndex] = lastStroke.copy(points = updatedPoints)
    }
    _brushStrokes.value = current
    applyInpaintingToCurrentFrame()
  }

  fun clearMask() {
    _brushStrokes.value = emptyList()
    applyInpaintingToCurrentFrame()
  }

  fun undoLastStroke() {
    val current = _brushStrokes.value
    if (current.isNotEmpty()) {
      _brushStrokes.value = current.dropLast(1)
      applyInpaintingToCurrentFrame()
    }
  }

  fun setAutoTrack(enabled: Boolean) {
    _autoTrack.value = enabled
    applyInpaintingToCurrentFrame()
  }

  fun setInpaintingMode(mode: InpaintingEngineMode) {
    _inpaintingMode.value = mode
    applyInpaintingToCurrentFrame()
  }

  fun setSplitSliderPosition(pos: Float) {
    _splitSliderPosition.value = pos.coerceIn(0f, 1f)
  }

  fun setComparisonMode(mode: ComparisonMode) {
    _comparisonMode.value = mode
  }

  fun runAiAutoDetect() {
    viewModelScope.launch {
      val frames = _videoFrames.value
      val idx = _currentFrameIndex.value
      if (frames.isNotEmpty()) {
        _isProcessing.value = true
        _statusMessage.value = "AI scanning frame for dampness, litter & blemishes..."
        delay(350)
        val detected = InpaintingEngine.autoDetectBlemishPatch(frames[idx].originalBitmap)
        _cloneConfig.value = detected
        _activeMaskTool.value = MaskTool.CLONE_PATCH
        _isProcessing.value = false
        _statusMessage.value = "Object & clean patch detected automatically!"
        applyInpaintingToCurrentFrame()
      }
    }
  }

  fun executeTextInstruction(prompt: String) {
    if (prompt.isBlank()) return
    viewModelScope.launch {
      val frames = _videoFrames.value
      val idx = _currentFrameIndex.value
      if (frames.isNotEmpty()) {
        _isProcessingTextPrompt.value = true
        _statusMessage.value = "AI analyzing prompt: \"$prompt\"..."
        delay(400) // Brief animation buffer

        val result = InpaintingEngine.processTextInstruction(
          bitmap = frames[idx].originalBitmap,
          prompt = prompt,
          presetId = _selectedPresetId.value
        )

        _cloneConfig.value = result.patchConfig
        _activeMaskTool.value = MaskTool.CLONE_PATCH
        _textCommandResult.value = result
        _isProcessingTextPrompt.value = false
        _statusMessage.value = result.explanationHindi

        // Apply immediately to current frame and all frames
        applyInpaintingToCurrentFrame()
        applyInpaintingToAllFrames()
      }
    }
  }

  fun clearTextCommandResult() {
    _textCommandResult.value = null
  }

  fun applyInpaintingToCurrentFrame() {
    viewModelScope.launch(Dispatchers.Default) {
      val frames = _videoFrames.value
      val idx = _currentFrameIndex.value
      if (frames.isEmpty() || idx !in frames.indices) return@launch

      val frame = frames[idx]
      val trackShiftX = if (_autoTrack.value) frame.cameraShiftX else 0f
      val trackShiftY = if (_autoTrack.value) frame.cameraShiftY else 0f

      var cleaned = when (_activeMaskTool.value) {
        MaskTool.CLONE_PATCH -> InpaintingEngine.applyClonePatch(
          frame.originalBitmap,
          _cloneConfig.value,
          trackShiftX,
          trackShiftY
        )
        else -> InpaintingEngine.applyBrushInpainting(
          frame.originalBitmap,
          _brushStrokes.value,
          trackShiftX,
          trackShiftY
        )
      }

      if (_wallPaintConfig.value.enabled) {
        cleaned = InpaintingEngine.applyWallPaint(cleaned, _wallPaintConfig.value)
      }

      if (_decorItems.value.isNotEmpty()) {
        cleaned = InpaintingEngine.renderDecorOverlay(
          original = cleaned,
          decors = _decorItems.value,
          trackShiftX = trackShiftX,
          trackShiftY = trackShiftY,
          context = getApplication()
        )
      }

      frame.cleanedBitmap = cleaned
      withContext(Dispatchers.Main) {
        _videoFrames.value = frames.toList()
      }
    }
  }

  fun applyInpaintingToAllFrames() {
    viewModelScope.launch(Dispatchers.Default) {
      val frames = _videoFrames.value
      for (frame in frames) {
        val trackShiftX = if (_autoTrack.value) frame.cameraShiftX else 0f
        val trackShiftY = if (_autoTrack.value) frame.cameraShiftY else 0f

        var cleaned = when (_activeMaskTool.value) {
          MaskTool.CLONE_PATCH -> InpaintingEngine.applyClonePatch(
            frame.originalBitmap,
            _cloneConfig.value,
            trackShiftX,
            trackShiftY
          )
          else -> InpaintingEngine.applyBrushInpainting(
            frame.originalBitmap,
            _brushStrokes.value,
            trackShiftX,
            trackShiftY
          )
        }

        if (_wallPaintConfig.value.enabled) {
          cleaned = InpaintingEngine.applyWallPaint(cleaned, _wallPaintConfig.value)
        }

        if (_decorItems.value.isNotEmpty()) {
          cleaned = InpaintingEngine.renderDecorOverlay(
            original = cleaned,
            decors = _decorItems.value,
            trackShiftX = trackShiftX,
            trackShiftY = trackShiftY,
            context = getApplication()
          )
        }

        frame.cleanedBitmap = cleaned
      }
      withContext(Dispatchers.Main) {
        _videoFrames.value = frames.toList()
      }
    }
  }

  // --- Gemini Ultra Vision AI Conversational Actions ---
  fun sendGeminiChatMessage(userText: String) {
    if (userText.isBlank()) return

    // If an attachment was pinned to the chat box, handle it with the user's instructions
    val pinned = _pinnedAttachment.value
    val hadAttachment = pinned != null
    if (pinned != null) {
      if (pinned.presetId != null && pinned.presetId != _selectedPresetId.value) {
        loadPreset(pinned.presetId)
      }
      _pinnedAttachment.value = null
    }

    val userMsg = GeminiChatMessage(isUser = true, text = userText)
    _chatMessages.update { it + userMsg }

    val isHindi = userText.any { it in '\u0900'..'\u097F' }

    // Convert existing message history to turns
    val historyTurns = _chatMessages.value.takeLast(10).map { Pair(it.isUser, it.text) }

    viewModelScope.launch {
      _isChatAiThinking.value = true
      _statusMessage.value = if (isHindi) "Gemini उत्तर तैयार कर रहा है..." else "Gemini is thinking..."

      val apiKey = try {
        val field = Class.forName("com.example.BuildConfig").getField("GEMINI_API_KEY")
        field.get(null) as? String
      } catch (e: Exception) {
        null
      }

      val result = com.example.engine.GeminiUniversalBrain.processQuery(
        query = userText,
        context = getApplication(),
        apiKey = apiKey,
        hasAttachedVideo = hadAttachment,
        conversationHistory = historyTurns
      )

      _isChatAiThinking.value = false
      val newMsg = GeminiChatMessage(
        isUser = false,
        text = result.responseText,
        actionApplied = result.actionDescription,
        suggestedPrompts = emptyList(), // Replaced by 3-dots menu
        hasMedia = result.isVideoAction,
        mediaType = if (result.isVideoAction) "video" else null
      )
      _chatMessages.update { it + newMsg }
      if (result.actionDescription != null) {
        _statusMessage.value = result.actionDescription
      }

      if (result.isVideoAction) {
        // Ensure frames are loaded if user started on a clean screen
        if (_videoFrames.value.isEmpty()) {
          val lower = userText.lowercase().trim()
          val targetPreset = if (lower.contains("कचरा") || lower.contains("फर्श") || lower.contains("litter") || lower.contains("trash")) {
            "litter"
          } else {
            "dampness"
          }
          val preset = SampleVideoGenerator.PRESETS.find { it.id == targetPreset }
          val frames = SampleVideoGenerator.generatePresetFrames(
            context = getApplication(),
            presetId = targetPreset
          )
          _videoFrames.value = frames
          _selectedPresetId.value = targetPreset
          _currentFrameIndex.value = 0
          if (preset != null) {
            _cloneConfig.value = ClonePatchConfig(
              sourceX = preset.defaultSource.x,
              sourceY = preset.defaultSource.y,
              targetX = preset.defaultTarget.x,
              targetY = preset.defaultTarget.y,
              radius = preset.defaultRadius
            )
          }
        }

        if (result.clearDecor) {
          _wallPaintConfig.value = WallPaintConfig(enabled = false)
          _decorItems.value = emptyList()
        }

        result.wallPaintConfig?.let { paint ->
          _wallPaintConfig.value = paint
        }

        result.addedDecorItem?.let { decor ->
          _decorItems.update { current ->
            current.filter { it.type != decor.type } + decor
          }
        }

        result.patchConfig?.let { patch ->
          _cloneConfig.value = patch
          _activeMaskTool.value = MaskTool.CLONE_PATCH
        }

        // Re-render inpainting asynchronously in background so chat stays 100% smooth
        applyInpaintingToCurrentFrame()
        applyInpaintingToAllFrames()
      }

      // Auto-save this active chat session into Recent Chats ("हाल ही के")
      val currentTitle = _chatMessages.value.find { it.isUser }?.text?.take(28) ?: "Gemini चैट"
      val updatedSession = ChatSession(
        id = _currentSessionId.value,
        title = currentTitle,
        timestampMs = System.currentTimeMillis(),
        messages = _chatMessages.value,
        presetId = _selectedPresetId.value,
        wallPaintConfig = _wallPaintConfig.value,
        decorItems = _decorItems.value
      )
      _chatSessions.update { list ->
        val existingIdx = list.indexOfFirst { it.id == updatedSession.id }
        if (existingIdx >= 0) {
          list.toMutableList().apply { set(existingIdx, updatedSession) }
        } else {
          listOf(updatedSession) + list
        }
      }
    }
  }

  // --- Gemini Drawer & Session Management ---
  fun openDrawer() {
    _isDrawerOpen.value = true
  }

  fun closeDrawer() {
    _isDrawerOpen.value = false
  }

  fun openFullscreenMedia() {
    _fullscreenMediaVisible.value = true
  }

  fun closeFullscreenMedia() {
    _fullscreenMediaVisible.value = false
  }

  fun pinAttachment(
    title: String,
    subtitle: String = "घर का वीडियो",
    uri: Uri? = null,
    presetId: String? = null,
    thumbnail: android.graphics.Bitmap? = null
  ) {
    _pinnedAttachment.value = PinnedAttachment(
      title = title,
      subtitle = subtitle,
      uri = uri,
      presetId = presetId,
      thumbnailBitmap = thumbnail
    )
    _statusMessage.value = "$title चैट बॉक्स में पिन हो गया। अब अपना निर्देश लिखकर भेजें!"
  }

  fun unpinAttachment() {
    _pinnedAttachment.value = null
  }

  fun startNewChat() {
    val newId = UUID.randomUUID().toString()
    _currentSessionId.value = newId
    _chatMessages.value = listOf(
      GeminiChatMessage(
        isUser = false,
        text = "नमस्ते! नया चैट सेशन शुरू हो गया है। ✨\n\nघर का कोई भी वीडियो पिन करें और बताएं कि आप क्या बदलाव चाहते हैं!",
        suggestedPrompts = listOf(
          "दीवार से सीलन हटा दो",
          "दीवार पर रॉयल ब्लू पेंट लगाओ",
          "दीवार पर लग्जरी वॉल आर्ट फ्रेम लगाओ",
          "कमरे में इंडोर पौधा रखो"
        )
      )
    )
    _wallPaintConfig.value = WallPaintConfig(enabled = false)
    _decorItems.value = emptyList()
    _pinnedAttachment.value = null
    loadPreset("dampness")
    _statusMessage.value = "नया चैट शुरू किया गया"
  }

  fun loadChatSession(session: ChatSession) {
    _currentSessionId.value = session.id
    _selectedPresetId.value = session.presetId
    _wallPaintConfig.value = session.wallPaintConfig
    _decorItems.value = session.decorItems
    if (session.messages.isNotEmpty()) {
      _chatMessages.value = session.messages
    }
    loadPreset(session.presetId)
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
    _statusMessage.value = "चैट लोड किया गया: ${session.title}"
  }

  fun deleteChatSession(sessionId: String) {
    _chatSessions.update { it.filterNot { s -> s.id == sessionId } }
  }

  fun saveCleanResultToGallery(context: Context) {
    viewModelScope.launch {
      val frames = _videoFrames.value
      val currentIdx = _currentFrameIndex.value
      if (frames.isNotEmpty()) {
        val frame = frames.getOrNull(currentIdx)
        val bmp = frame?.cleanedBitmap ?: frame?.originalBitmap
        if (bmp != null) {
          _statusMessage.value = "गैलरी में सेव किया जा रहा है..."
          val uri = GalleryExporter.savePhotoToGallery(context, bmp, "Gemini_Home_Makeover")
          if (uri != null) {
            _statusMessage.value = "✅ गैलरी में सेव हो गया! (Pictures/GeminiMakeover)"
            Toast.makeText(context, "✅ फोटो गैलरी में सेव हो गया!", Toast.LENGTH_LONG).show()
          } else {
            Toast.makeText(context, "गैलरी में सुरक्षित हो गया", Toast.LENGTH_SHORT).show()
          }
        }
      }
    }
  }

  fun setWallPaint(colorHex: Long, nameHindi: String, nameEnglish: String) {
    _wallPaintConfig.value = WallPaintConfig(
      enabled = true,
      colorNameHindi = nameHindi,
      colorNameEnglish = nameEnglish,
      colorHex = colorHex,
      opacity = 0.48f
    )
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
    _statusMessage.value = "दीवार का रंग बदलकर $nameHindi किया गया"
  }

  fun toggleWallPaint(enabled: Boolean) {
    _wallPaintConfig.update { it.copy(enabled = enabled) }
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
  }

  fun addDecorItem(type: DecorType, nameHi: String, nameEn: String, x: Float = 0.5f, y: Float = 0.4f) {
    val item = DecorItem(
      id = "decor_${System.currentTimeMillis()}",
      type = type,
      nameHindi = nameHi,
      nameEnglish = nameEn,
      normalizedX = x,
      normalizedY = y
    )
    _decorItems.update { it + item }
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
    _statusMessage.value = "$nameHi जोड़ा गया"
  }

  fun removeDecorItem(id: String) {
    _decorItems.update { it.filterNot { d -> d.id == id } }
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
  }

  fun clearAllDecorations() {
    _wallPaintConfig.value = WallPaintConfig(enabled = false)
    _decorItems.value = emptyList()
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
    _statusMessage.value = "सभी डेकोरेशन रीसेट किए गए"
  }

  fun startExport(context: Context) {
    viewModelScope.launch {
      _exportState.value = ExportState(isExporting = true, statusMessage = "Preparing export pipeline...")
      val result = VideoExporter.exportCleanedVideo(
        context = context,
        frames = _videoFrames.value,
        tool = _activeMaskTool.value,
        cloneConfig = _cloneConfig.value,
        brushStrokes = _brushStrokes.value,
        autoTrack = _autoTrack.value,
        wallPaintConfig = _wallPaintConfig.value,
        decorItems = _decorItems.value,
        onProgress = { state ->
          _exportState.value = state
        }
      )
      _exportState.value = result
    }
  }

  fun dismissExportDialog() {
    _exportState.value = ExportState()
  }
}

