package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R

/**
 * Nexus AI Crystalline Emblem Logo.
 * Displays the user's custom 3D geometric blue-silver crystal star logo
 * with subtle breathing pulse, luminous cyber-blue glow border, and rounded shape.
 */
@Composable
fun NexusLogoIcon(
  modifier: Modifier = Modifier,
  size: Dp = 68.dp,
  animated: Boolean = true
) {
  val infiniteTransition = rememberInfiniteTransition(label = "nexus_pulse")
  val pulseScale by if (animated) {
    infiniteTransition.animateFloat(
      initialValue = 0.97f,
      targetValue = 1.03f,
      animationSpec = infiniteRepeatable(
        animation = tween(2400, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse
      ),
      label = "scale"
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
  }

  val cornerRadius = size * 0.24f
  Box(
    modifier = modifier
      .size(size)
      .scale(pulseScale),
    contentAlignment = Alignment.Center
  ) {
    Image(
      painter = painterResource(id = R.drawable.nexus_logo_1788608521249),
      contentDescription = "Nexus AI Logo",
      contentScale = ContentScale.Crop,
      modifier = Modifier
        .size(size)
        .shadow(elevation = 12.dp, shape = RoundedCornerShape(cornerRadius), ambientColor = Color(0xFF38BDF8), spotColor = Color(0xFF2563EB))
        .clip(RoundedCornerShape(cornerRadius))
        .border(
          width = 1.5.dp,
          brush = Brush.linearGradient(
            colors = listOf(
              Color(0xFF38BDF8),
              Color(0xFF818CF8),
              Color(0xFF1E3A8A)
            )
          ),
          shape = RoundedCornerShape(cornerRadius)
        )
    )
  }
}

/**
 * Compatibility wrapper: uses NexusLogoIcon
 */
@Composable
fun GeminiStarIcon(
  modifier: Modifier = Modifier,
  size: Dp = 54.dp,
  animated: Boolean = true
) {
  NexusLogoIcon(
    modifier = modifier,
    size = size,
    animated = animated
  )
}

