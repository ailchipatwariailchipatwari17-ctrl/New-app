package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkCanvas = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkSurfaceBorder = Color(0xFF334155)

val CyanPrimary = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF22D3EE)
val PurpleSecondary = Color(0xFF8B5CF6)
val AmberAccent = Color(0xFFF59E0B)
val EmeraldAccent = Color(0xFF10B981)
val RoseHighlight = Color(0xFFF43F5E)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val MaskBrushColor = Color(0xDDF43F5E)
val SourcePatchColor = Color(0xFF10B981)
val TargetPatchColor = Color(0xFFF59E0B)

