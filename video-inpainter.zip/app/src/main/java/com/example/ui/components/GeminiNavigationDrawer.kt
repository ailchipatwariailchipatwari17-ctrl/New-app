package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatSession

/**
 * Pixel-accurate Gemini Side Navigation Drawer matching the user's uploaded screenshot.
 * Includes:
 * - "Gemini" title with Close (X) button
 * - "नई चैट" (New Chat) button
 * - "चैट खोजें" (Search Chats) with live filter
 * - "वीडियो" & "लाइब्रेरी"
 * - "नोटबुक" (+ नई नोटबुक)
 * - "हाल ही के" (Recent chats auto-saved history)
 */
@Composable
fun GeminiNavigationDrawer(
  isOpen: Boolean,
  onClose: () -> Unit,
  sessions: List<ChatSession>,
  currentSessionId: String,
  onNewChat: () -> Unit,
  onSelectSession: (ChatSession) -> Unit,
  onDeleteSession: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var searchQuery by remember { mutableStateOf("") }
  var isSearchExpanded by remember { mutableStateOf(false) }

  val filteredSessions = if (searchQuery.isBlank()) {
    sessions
  } else {
    sessions.filter { it.title.contains(searchQuery, ignoreCase = true) }
  }

  if (isOpen) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .testTag("gemini_drawer_overlay")
    ) {
      // Backdrop Scrim
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = 0.65f))
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClose
          )
      )

      // Drawer Content Panel (Matches the black Android Gemini drawer screenshot)
      Surface(
        modifier = Modifier
          .fillMaxHeight()
          .width(320.dp)
          .align(Alignment.CenterStart)
          .testTag("gemini_drawer_panel"),
        color = Color(0xFF0D0E11), // Gemini deep dark canvas
        shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
          // 1. TOP HEADER: "Gemini" Title and Close "X" button
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 16.dp, top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Gemini",
              fontSize = 22.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color.White
            )

            IconButton(
              onClick = onClose,
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close Menu",
                tint = Color(0xFFCBD5E1),
                modifier = Modifier.size(24.dp)
              )
            }
          }

          // 2. PRIMARY BUTTON: "नई चैट" (New Chat) - rounded grey pill from screenshot
          Surface(
            onClick = {
              onNewChat()
              onClose()
            },
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF1E2430),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("btn_new_chat")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = null,
                tint = Color(0xFFE2E8F0),
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(14.dp))
              Text(
                text = "नई चैट",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 3. SEARCH CHATS: "चैट खोजें"
          Surface(
            onClick = { isSearchExpanded = !isSearchExpanded },
            shape = RoundedCornerShape(12.dp),
            color = Color.Transparent,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(16.dp))
              Text(
                text = "चैट खोजें",
                fontSize = 15.sp,
                color = Color(0xFFE2E8F0)
              )
            }
          }

          if (isSearchExpanded) {
            BasicTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
              cursorBrush = SolidColor(Color(0xFF38BDF8)),
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .background(Color(0xFF1E2430), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
              decorationBox = { innerTextField ->
                if (searchQuery.isEmpty()) {
                  Text("हाल ही की चैट में खोजें...", color = Color(0xFF64748B), fontSize = 13.sp)
                }
                innerTextField()
              }
            )
          }

          // 4. "वीडियो" Item
          Surface(
            onClick = { onClose() },
            shape = RoundedCornerShape(12.dp),
            color = Color.Transparent,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Movie,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(16.dp))
              Text(
                text = "वीडियो",
                fontSize = 15.sp,
                color = Color(0xFFE2E8F0)
              )
            }
          }

          // 5. "लाइब्रेरी" Item
          Surface(
            onClick = { onClose() },
            shape = RoundedCornerShape(12.dp),
            color = Color.Transparent,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.GridView,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(16.dp))
              Text(
                text = "लाइब्रेरी",
                fontSize = 15.sp,
                color = Color(0xFFE2E8F0)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // 6. "नोटबुक" SECTION
          Text(
            text = "नोटबुक",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
          )

          Surface(
            onClick = {
              onNewChat()
              onClose()
            },
            shape = RoundedCornerShape(12.dp),
            color = Color.Transparent,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 9.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(16.dp))
              Text(
                text = "नई नोटबुक",
                fontSize = 15.sp,
                color = Color(0xFFE2E8F0)
              )
            }
          }

          Spacer(modifier = Modifier.height(18.dp))

          // 7. "हाल ही के" (Recent Chats) - User highlighted with red lines in screenshot
          Text(
            text = "हाल ही के",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
          )

          // Scrollable List of Past Chats (Auto-saved)
          LazyColumn(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            if (filteredSessions.isEmpty()) {
              item {
                Text(
                  text = "कोई पूर्व चैट नहीं है",
                  fontSize = 13.sp,
                  color = Color(0xFF475569),
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)
                )
              }
            } else {
              items(filteredSessions, key = { it.id }) { session ->
                val isSelected = session.id == currentSessionId
                Surface(
                  onClick = {
                    onSelectSession(session)
                    onClose()
                  },
                  shape = RoundedCornerShape(12.dp),
                  color = if (isSelected) Color(0xFF1E293B) else Color.Transparent,
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("recent_chat_item_${session.id}")
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(horizontal = 10.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = session.title,
                      fontSize = 14.sp,
                      color = if (isSelected) Color(0xFF38BDF8) else Color(0xFFCBD5E1),
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                      modifier = Modifier.weight(1f)
                    )

                    IconButton(
                      onClick = { onDeleteSession(session.id) },
                      modifier = Modifier.size(24.dp)
                    ) {
                      Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Delete",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(14.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
