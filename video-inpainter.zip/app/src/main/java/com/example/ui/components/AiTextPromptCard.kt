package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TextCommandResult
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AiTextPromptCard(
  isProcessing: Boolean,
  textCommandResult: TextCommandResult?,
  onExecutePrompt: (String) -> Unit,
  onClearResult: () -> Unit,
  onViewInSplitPreview: () -> Unit,
  modifier: Modifier = Modifier
) {
  var promptInput by remember { mutableStateOf("") }
  val focusManager = LocalFocusManager.current
  val chipScrollState = rememberScrollState()

  val suggestionChips = listOf(
    "दीवार से सीलन हटा दो",
    "फर्श से कचरा हटा दो",
    "लाल निशान / दाग हटा दो",
    "Remove wall dampness & seepage",
    "Clean floor litter and trash",
    "Remove unwanted markings"
  )

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .border(
        width = 1.dp,
        brush = Brush.horizontalGradient(
          colors = listOf(
            CyanPrimary.copy(alpha = 0.5f),
            Color(0xFF8B5CF6).copy(alpha = 0.5f)
          )
        ),
        shape = RoundedCornerShape(16.dp)
      ),
    color = DarkSurfaceElevated,
    shape = RoundedCornerShape(16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      // Header with glowing badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(
                Brush.linearGradient(
                  colors = listOf(CyanPrimary, Color(0xFF8B5CF6))
                )
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = Color.Black,
              modifier = Modifier.size(18.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "AI Text Prompt / लिखकर हटाएं",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = "Hindi or English • Auto-detects & cleans object",
              fontSize = 11.sp,
              color = TextSecondary
            )
          }
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CyanPrimary.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Text(
            text = "AI 2.0",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = CyanPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Text Input Box + Execute Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = promptInput,
          onValueChange = { promptInput = it },
          placeholder = {
            Text(
              text = "उदा. 'इस वीडियो से सीलन हटा दो'...",
              fontSize = 13.sp,
              color = TextMuted
            )
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
          keyboardActions = KeyboardActions(
            onDone = {
              focusManager.clearFocus()
              if (promptInput.isNotBlank()) {
                onExecutePrompt(promptInput)
              }
            }
          ),
          trailingIcon = {
            if (promptInput.isNotEmpty()) {
              IconButton(onClick = { promptInput = "" }) {
                Icon(
                  imageVector = Icons.Default.Clear,
                  contentDescription = "Clear",
                  tint = TextMuted,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CyanPrimary,
            unfocusedBorderColor = DarkSurfaceBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedContainerColor = Color(0xFF141A24),
            unfocusedContainerColor = Color(0xFF141A24)
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("ai_prompt_input")
        )

        Spacer(modifier = Modifier.width(8.dp))

        Button(
          onClick = {
            focusManager.clearFocus()
            if (promptInput.isNotBlank()) {
              onExecutePrompt(promptInput)
            }
          },
          enabled = !isProcessing && promptInput.isNotBlank(),
          colors = ButtonDefaults.buttonColors(
            containerColor = CyanPrimary,
            contentColor = Color.Black,
            disabledContainerColor = DarkSurfaceBorder,
            disabledContentColor = TextMuted
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .height(52.dp)
            .testTag("btn_execute_prompt")
        ) {
          if (isProcessing) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              color = Color.Black,
              strokeWidth = 2.dp
            )
          } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "हटाएं",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Suggestion quick chips in Hindi & English
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(chipScrollState),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        suggestionChips.forEach { suggestion ->
          FilterChip(
            selected = promptInput == suggestion,
            onClick = {
              promptInput = suggestion
              onExecutePrompt(suggestion)
            },
            label = {
              Text(
                text = suggestion,
                fontSize = 11.sp,
                color = if (promptInput == suggestion) CyanPrimary else TextSecondary
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              containerColor = Color(0xFF18202C),
              selectedContainerColor = CyanPrimary.copy(alpha = 0.15f)
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = promptInput == suggestion,
              borderColor = DarkSurfaceBorder,
              selectedBorderColor = CyanPrimary
            ),
            shape = RoundedCornerShape(8.dp)
          )
        }
      }

      // Result Feedback Card (Shows what the AI detected & did)
      AnimatedVisibility(
        visible = textCommandResult != null,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically()
      ) {
        textCommandResult?.let { result ->
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .border(1.dp, Color(0xFF10B981).copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
            color = Color(0xFF0D251D)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = result.detectedCategory,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF10B981)
                  )
                }

                Text(
                  text = "${(result.confidence * 100).toInt()}% Match",
                  fontSize = 10.sp,
                  color = TextMuted
                )
              }

              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = result.explanationHindi,
                fontSize = 12.sp,
                color = TextPrimary
              )

              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = result.explanationEnglish,
                fontSize = 11.sp,
                color = TextSecondary
              )

              Spacer(modifier = Modifier.height(8.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Button(
                  onClick = onViewInSplitPreview,
                  colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981),
                    contentColor = Color.Black
                  ),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.height(34.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Compare,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "Before / After तुलना देखें",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
