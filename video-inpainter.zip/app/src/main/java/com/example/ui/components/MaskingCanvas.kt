package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrushStroke
import com.example.model.ClonePatchConfig
import com.example.model.MaskTool
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.MaskBrushColor
import com.example.ui.theme.SourcePatchColor
import com.example.ui.theme.TargetPatchColor
import kotlin.math.hypot
import kotlin.math.min

@Composable
fun MaskingCanvas(
  bitmap: Bitmap?,
  tool: MaskTool,
  brushStrokes: List<BrushStroke>,
  cloneConfig: ClonePatchConfig,
  autoTrack: Boolean,
  cameraShiftX: Float,
  cameraShiftY: Float,
  onAddBrushPoint: (x: Float, y: Float, isStart: Boolean) -> Unit,
  onUpdateCloneConfig: ((ClonePatchConfig) -> ClonePatchConfig) -> Unit,
  modifier: Modifier = Modifier
) {
  if (bitmap == null) return

  var draggingTarget by remember { mutableStateOf(false) }
  var draggingSource by remember { mutableStateOf(false) }

  Box(
    modifier = modifier
      .fillMaxWidth()
      .aspectRatio(4f / 3f)
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
      .background(Color.Black)
      .testTag("masking_canvas_container")
  ) {
    // 1. Base Video Frame
    Image(
      bitmap = bitmap.asImageBitmap(),
      contentDescription = "Video Frame",
      contentScale = ContentScale.Fit,
      modifier = Modifier.fillMaxSize()
    )

    // 2. Interactive Annotation / Mask Overlay Canvas
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .testTag("mask_interactive_canvas")
        .pointerInput(tool, cloneConfig) {
          detectDragGestures(
            onDragStart = { offset ->
              val w = size.width.toFloat()
              val h = size.height.toFloat()

              if (tool == MaskTool.CLONE_PATCH) {
                val shiftX = if (autoTrack) cameraShiftX else 0f
                val shiftY = if (autoTrack) cameraShiftY else 0f

                val targetPx = Offset(cloneConfig.targetX * w + shiftX, cloneConfig.targetY * h + shiftY)
                val sourcePx = Offset(cloneConfig.sourceX * w + shiftX, cloneConfig.sourceY * h + shiftY)
                val handleRadius = 40.dp.toPx()

                val distToTarget = hypot((offset.x - targetPx.x).toDouble(), (offset.y - targetPx.y).toDouble())
                val distToSource = hypot((offset.x - sourcePx.x).toDouble(), (offset.y - sourcePx.y).toDouble())

                if (distToTarget < handleRadius) {
                  draggingTarget = true
                  draggingSource = false
                } else if (distToSource < handleRadius) {
                  draggingSource = true
                  draggingTarget = false
                } else {
                  // If tapped outside, set target to tap position
                  draggingTarget = true
                  draggingSource = false
                  val newNormX = (offset.x - shiftX) / w
                  val newNormY = (offset.y - shiftY) / h
                  onUpdateCloneConfig { it.copy(targetX = newNormX.coerceIn(0.05f, 0.95f), targetY = newNormY.coerceIn(0.05f, 0.95f)) }
                }
              } else {
                onAddBrushPoint(offset.x, offset.y, true)
              }
            },
            onDrag = { change, _ ->
              change.consume()
              val w = size.width.toFloat()
              val h = size.height.toFloat()

              if (tool == MaskTool.CLONE_PATCH) {
                val shiftX = if (autoTrack) cameraShiftX else 0f
                val shiftY = if (autoTrack) cameraShiftY else 0f

                val normX = ((change.position.x - shiftX) / w).coerceIn(0.05f, 0.95f)
                val normY = ((change.position.y - shiftY) / h).coerceIn(0.05f, 0.95f)

                if (draggingTarget) {
                  onUpdateCloneConfig { it.copy(targetX = normX, targetY = normY) }
                } else if (draggingSource) {
                  onUpdateCloneConfig { it.copy(sourceX = normX, sourceY = normY) }
                }
              } else {
                onAddBrushPoint(change.position.x, change.position.y, false)
              }
            },
            onDragEnd = {
              draggingTarget = false
              draggingSource = false
            },
            onDragCancel = {
              draggingTarget = false
              draggingSource = false
            }
          )
        }
    ) {
      val w = size.width
      val h = size.height
      val shiftX = if (autoTrack) cameraShiftX else 0f
      val shiftY = if (autoTrack) cameraShiftY else 0f

      // Draw Brush Strokes
      if (brushStrokes.isNotEmpty()) {
        for (stroke in brushStrokes) {
          if (stroke.points.size < 2) continue
          val path = Path()
          val p0 = stroke.points[0]
          path.moveTo(p0.x + shiftX, p0.y + shiftY)
          for (i in 1 until stroke.points.size) {
            val p = stroke.points[i]
            path.lineTo(p.x + shiftX, p.y + shiftY)
          }

          drawPath(
            path = path,
            color = if (stroke.isEraser) Color.Black.copy(alpha = 0.5f) else MaskBrushColor.copy(alpha = stroke.opacity),
            style = Stroke(
              width = stroke.radius * 2f,
              cap = StrokeCap.Round,
              join = StrokeJoin.Round
            )
          )
        }
      }

      // Draw Clone Patch Source & Target handles if CLONE_PATCH tool is active
      if (tool == MaskTool.CLONE_PATCH) {
        val targetPx = Offset(cloneConfig.targetX * w + shiftX, cloneConfig.targetY * h + shiftY)
        val sourcePx = Offset(cloneConfig.sourceX * w + shiftX, cloneConfig.sourceY * h + shiftY)
        val radiusPx = cloneConfig.radius * min(w, h)
        val innerRadiusPx = radiusPx * (1f - cloneConfig.featherRatio)

        // Dotted connector line between source (clean wall) and target (dampness/litter)
        val dottedEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)
        drawLine(
          color = CyanGlow.copy(alpha = 0.8f),
          start = sourcePx,
          end = targetPx,
          strokeWidth = 2.dp.toPx(),
          pathEffect = dottedEffect
        )

        // Target: Dampness / Trash Area (Amber / Rose)
        // Outer radius ring (feather boundary)
        drawCircle(
          color = TargetPatchColor.copy(alpha = 0.9f),
          radius = radiusPx,
          center = targetPx,
          style = Stroke(width = 2.dp.toPx(), pathEffect = dottedEffect)
        )
        // Inner radius ring (solid core)
        drawCircle(
          color = TargetPatchColor.copy(alpha = 0.25f),
          radius = innerRadiusPx,
          center = targetPx
        )
        // Center Pin
        drawCircle(
          color = TargetPatchColor,
          radius = 7.dp.toPx(),
          center = targetPx
        )

        // Source: Clean Wall / Floor Reference (Emerald Green)
        drawCircle(
          color = SourcePatchColor.copy(alpha = 0.9f),
          radius = radiusPx,
          center = sourcePx,
          style = Stroke(width = 2.dp.toPx())
        )
        drawCircle(
          color = SourcePatchColor.copy(alpha = 0.2f),
          radius = radiusPx,
          center = sourcePx
        )
        // Center Pin
        drawCircle(
          color = SourcePatchColor,
          radius = 7.dp.toPx(),
          center = sourcePx
        )
      }
    }

    // Top Badges (Auto-Track indicator, Tool Badge)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      // Tool badge
      Box(
        modifier = Modifier
          .align(Alignment.TopStart)
          .clip(RoundedCornerShape(6.dp))
          .background(Color.Black.copy(alpha = 0.65f))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text(
          text = if (tool == MaskTool.CLONE_PATCH) "Clean Wall Patch Mode" else "Brush Mask Mode",
          color = if (tool == MaskTool.CLONE_PATCH) TargetPatchColor else MaskBrushColor,
          fontSize = 11.sp
        )
      }

      // Auto-track badge
      if (autoTrack) {
        Box(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF10B981).copy(alpha = 0.85f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "Auto-Track: Active",
            color = Color.White,
            fontSize = 11.sp
          )
        }
      }
    }
  }
}
