package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.WaterDamage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.engine.SampleVideoGenerator
import com.example.model.SampleVideoPreset
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.RoseHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun VideoImportCard(
  selectedPresetId: String,
  onSelectPreset: (String) -> Unit,
  onImportCustomVideo: (Uri) -> Unit,
  onContinueToMasking: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  // Modern zero-permission visual media picker (MP4, MOV, WebM)
  val pickMediaLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      onImportCustomVideo(uri)
    }
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("video_import_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "VIDEO SOURCE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Select Video to Inpaint & Clean",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }

        // Upload custom video button
        Button(
          onClick = {
            pickMediaLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
            )
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = CyanPrimary,
            contentColor = Color.Black
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.testTag("btn_pick_custom_video")
        ) {
          Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Pick Video", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Or choose a sample scenario to test inpainting instantly:",
        fontSize = 12.sp,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Preset cards list
      SampleVideoGenerator.PRESETS.forEach { preset ->
        val isSelected = selectedPresetId == preset.id
        PresetItem(
          preset = preset,
          isSelected = isSelected,
          onSelect = { onSelectPreset(preset.id) }
        )
        Spacer(modifier = Modifier.height(8.dp))
      }

      Spacer(modifier = Modifier.height(6.dp))

      Button(
        onClick = onContinueToMasking,
        colors = ButtonDefaults.buttonColors(
          containerColor = CyanPrimary,
          contentColor = Color.Black
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(46.dp)
          .testTag("btn_continue_to_mask")
      ) {
        Text("Continue to Mask & Clean-up →", fontSize = 13.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun PresetItem(
  preset: SampleVideoPreset,
  isSelected: Boolean,
  onSelect: () -> Unit
) {
  val icon = when (preset.id) {
    "litter" -> Icons.Default.Delete
    "object_tag" -> Icons.Default.FormatPaint
    else -> Icons.Default.WaterDamage
  }

  val accentColor = when (preset.id) {
    "litter" -> AmberAccent
    "object_tag" -> RoseHighlight
    else -> CyanGlow
  }

  Surface(
    onClick = onSelect,
    shape = RoundedCornerShape(12.dp),
    color = if (isSelected) CyanPrimary.copy(alpha = 0.12f) else Color.Black.copy(alpha = 0.25f),
    border = BorderStroke(
      width = if (isSelected) 1.5.dp else 1.dp,
      color = if (isSelected) CyanPrimary else DarkSurfaceBorder
    ),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("preset_${preset.id}")
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(20.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(preset.titleRes),
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = if (isSelected) CyanGlow else TextPrimary
        )
        Text(
          text = stringResource(preset.descRes),
          fontSize = 11.sp,
          color = TextMuted
        )
      }

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(DarkSurfaceElevated)
          .padding(horizontal = 6.dp, vertical = 3.dp)
      ) {
        Text(
          text = "${preset.frameCount} frames",
          fontSize = 10.sp,
          color = TextSecondary
        )
      }
    }
  }
}
