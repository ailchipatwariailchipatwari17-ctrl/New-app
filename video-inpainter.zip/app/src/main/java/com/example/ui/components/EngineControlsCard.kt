package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClonePatchConfig
import com.example.model.InpaintingEngineMode
import com.example.model.MaskTool
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PurpleSecondary
import com.example.ui.theme.RoseHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun EngineControlsCard(
  activeTool: MaskTool,
  inpaintingMode: InpaintingEngineMode,
  autoTrack: Boolean,
  brushRadius: Float,
  brushFeather: Float,
  cloneConfig: ClonePatchConfig,
  isProcessing: Boolean,
  onToolSelected: (MaskTool) -> Unit,
  onInpaintingModeChanged: (InpaintingEngineMode) -> Unit,
  onAutoTrackToggled: (Boolean) -> Unit,
  onBrushRadiusChanged: (Float) -> Unit,
  onBrushFeatherChanged: (Float) -> Unit,
  onCloneRadiusChanged: (Float) -> Unit,
  onCloneFeatherChanged: (Float) -> Unit,
  onClearMask: () -> Unit,
  onUndoStroke: () -> Unit,
  onAiAutoDetect: () -> Unit,
  onApplyCleanUp: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("engine_controls_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      // Mode Selection Tabs (Mode B: Local Freeze Patch vs Mode A: Free Cloud AI)
      Text(
        text = "INPAINTING ENGINE",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = TextMuted,
        letterSpacing = 1.sp
      )

      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(Color.Black.copy(alpha = 0.3f))
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Mode B: Local Patching
        val isLocal = inpaintingMode == InpaintingEngineMode.LOCAL_FREEZE_PATCH
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isLocal) CyanPrimary else Color.Transparent)
            .clickable { onInpaintingModeChanged(InpaintingEngineMode.LOCAL_FREEZE_PATCH) }
            .padding(vertical = 8.dp, horizontal = 6.dp)
            .testTag("mode_tab_local"),
          contentAlignment = Alignment.Center
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.OfflineBolt,
              contentDescription = "Offline Mode",
              tint = if (isLocal) Color.Black else CyanGlow,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(
                text = "Mode B: Local Patch",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isLocal) Color.Black else TextPrimary
              )
              Text(
                text = "100% Offline • Zero Cost",
                fontSize = 9.sp,
                color = if (isLocal) Color.Black.copy(alpha = 0.8f) else TextMuted
              )
            }
          }
        }

        // Mode A: Cloud AI Pipeline
        val isCloud = inpaintingMode == InpaintingEngineMode.FREE_CLOUD_AI
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isCloud) PurpleSecondary else Color.Transparent)
            .clickable { onInpaintingModeChanged(InpaintingEngineMode.FREE_CLOUD_AI) }
            .padding(vertical = 8.dp, horizontal = 6.dp)
            .testTag("mode_tab_cloud"),
          contentAlignment = Alignment.Center
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Cloud,
              contentDescription = "Cloud AI",
              tint = if (isCloud) Color.White else PurpleSecondary,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(
                text = "Mode A: Free Cloud AI",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isCloud) Color.White else TextPrimary
              )
              Text(
                text = "HuggingFace & Gemini",
                fontSize = 9.sp,
                color = if (isCloud) Color.White.copy(alpha = 0.8f) else TextMuted
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Tool Selector Buttons (Clean Wall Patch, Brush, Eraser, Clear, Undo)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // Clean Wall Patch Tool
          ToolButton(
            icon = Icons.Default.CropFree,
            label = "Clean Patch",
            isSelected = activeTool == MaskTool.CLONE_PATCH,
            tag = "btn_tool_clone",
            onClick = { onToolSelected(MaskTool.CLONE_PATCH) }
          )

          // Brush Tool
          ToolButton(
            icon = Icons.Default.Brush,
            label = "Brush Mask",
            isSelected = activeTool == MaskTool.BRUSH,
            tag = "btn_tool_brush",
            onClick = { onToolSelected(MaskTool.BRUSH) }
          )
        }

        // Undo & Clear Actions
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(
            onClick = onUndoStroke,
            modifier = Modifier.size(36.dp).testTag("btn_undo_mask")
          ) {
            Icon(
              imageVector = Icons.Default.Undo,
              contentDescription = "Undo",
              tint = TextSecondary,
              modifier = Modifier.size(18.dp)
            )
          }

          IconButton(
            onClick = onClearMask,
            modifier = Modifier.size(36.dp).testTag("btn_clear_mask")
          ) {
            Icon(
              imageVector = Icons.Default.DeleteSweep,
              contentDescription = "Clear Mask",
              tint = RoseHighlight,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Parameter Sliders: Patch/Brush Size and Soft Edge Feathering
      if (activeTool == MaskTool.CLONE_PATCH) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Patch Size", fontSize = 12.sp, color = TextSecondary)
          Text("${(cloneConfig.radius * 100).toInt()}%", fontSize = 12.sp, color = CyanGlow, fontWeight = FontWeight.Bold)
        }
        Slider(
          value = cloneConfig.radius,
          onValueChange = onCloneRadiusChanged,
          valueRange = 0.06f..0.35f,
          colors = SliderDefaults.colors(thumbColor = CyanPrimary, activeTrackColor = CyanPrimary),
          modifier = Modifier.height(30.dp).testTag("slider_patch_size")
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Feather Softness (Seamless Edge)", fontSize = 12.sp, color = TextSecondary)
          Text("${(cloneConfig.featherRatio * 100).toInt()}%", fontSize = 12.sp, color = CyanGlow, fontWeight = FontWeight.Bold)
        }
        Slider(
          value = cloneConfig.featherRatio,
          onValueChange = onCloneFeatherChanged,
          valueRange = 0.1f..0.85f,
          colors = SliderDefaults.colors(thumbColor = CyanPrimary, activeTrackColor = CyanPrimary),
          modifier = Modifier.height(30.dp).testTag("slider_feather_ratio")
        )
      } else {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Brush Thickness", fontSize = 12.sp, color = TextSecondary)
          Text("${brushRadius.toInt()} px", fontSize = 12.sp, color = CyanGlow, fontWeight = FontWeight.Bold)
        }
        Slider(
          value = brushRadius,
          onValueChange = onBrushRadiusChanged,
          valueRange = 8f..60f,
          colors = SliderDefaults.colors(thumbColor = CyanPrimary, activeTrackColor = CyanPrimary),
          modifier = Modifier.height(30.dp).testTag("slider_brush_radius")
        )
      }

      // Auto-Track Switch Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(Color.Black.copy(alpha = 0.25f))
          .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.TrackChanges,
            contentDescription = "Auto-track",
            tint = if (autoTrack) Color(0xFF10B981) else TextMuted,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "Auto-Track Across Frames",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = TextPrimary
            )
            Text(
              text = "Follows camera movement automatically",
              fontSize = 10.sp,
              color = TextMuted
            )
          }
        }

        Switch(
          checked = autoTrack,
          onCheckedChange = onAutoTrackToggled,
          colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = Color(0xFF10B981),
            uncheckedThumbColor = TextMuted,
            uncheckedTrackColor = DarkSurfaceBorder
          ),
          modifier = Modifier.testTag("switch_auto_track")
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action Buttons: AI Auto-Detect & Apply Clean-Up
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // AI Auto-Detect Button
        Button(
          onClick = onAiAutoDetect,
          enabled = !isProcessing,
          colors = ButtonDefaults.buttonColors(
            containerColor = PurpleSecondary,
            contentColor = Color.White
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .weight(1f)
            .height(46.dp)
            .testTag("btn_ai_auto_detect")
        ) {
          if (isProcessing) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("AI Auto-Detect", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }

        // Apply Clean-Up Button
        Button(
          onClick = onApplyCleanUp,
          enabled = !isProcessing,
          colors = ButtonDefaults.buttonColors(
            containerColor = CyanPrimary,
            contentColor = Color.Black
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .weight(1.2f)
            .height(46.dp)
            .testTag("btn_apply_cleanup")
        ) {
          Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Apply Clean-Up", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun ToolButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  isSelected: Boolean,
  tag: String,
  onClick: () -> Unit
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(10.dp),
    color = if (isSelected) CyanPrimary else DarkSurfaceBorder.copy(alpha = 0.5f),
    border = BorderStroke(1.dp, if (isSelected) CyanGlow else DarkSurfaceBorder),
    modifier = Modifier.testTag(tag)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = if (isSelected) Color.Black else TextPrimary,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = label,
        fontSize = 12.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = if (isSelected) Color.Black else TextPrimary
      )
    }
  }
}
