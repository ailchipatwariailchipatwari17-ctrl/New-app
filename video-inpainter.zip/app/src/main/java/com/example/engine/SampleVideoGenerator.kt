package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.R
import com.example.model.SampleVideoPreset
import com.example.model.VideoFrame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin

object SampleVideoGenerator {

  val PRESETS = listOf(
    SampleVideoPreset(
      id = "dampness",
      titleRes = R.string.sample_dampness_title,
      descRes = R.string.sample_dampness_desc,
      frameCount = 30,
      durationMs = 2000L,
      defaultSource = androidx.compose.ui.geometry.Offset(0.25f, 0.28f),
      defaultTarget = androidx.compose.ui.geometry.Offset(0.68f, 0.52f),
      defaultRadius = 0.17f
    ),
    SampleVideoPreset(
      id = "litter",
      titleRes = R.string.sample_litter_title,
      descRes = R.string.sample_litter_desc,
      frameCount = 30,
      durationMs = 2000L,
      defaultSource = androidx.compose.ui.geometry.Offset(0.30f, 0.30f),
      defaultTarget = androidx.compose.ui.geometry.Offset(0.55f, 0.65f),
      defaultRadius = 0.14f
    ),
    SampleVideoPreset(
      id = "object_tag",
      titleRes = R.string.sample_object_title,
      descRes = R.string.sample_object_desc,
      frameCount = 30,
      durationMs = 2000L,
      defaultSource = androidx.compose.ui.geometry.Offset(0.20f, 0.50f),
      defaultTarget = androidx.compose.ui.geometry.Offset(0.70f, 0.40f),
      defaultRadius = 0.13f
    )
  )

  suspend fun generatePresetFrames(
    context: Context? = null,
    presetId: String,
    width: Int = 480,
    height: Int = 360
  ): List<VideoFrame> =
    withContext(Dispatchers.Default) {
      val frames = mutableListOf<VideoFrame>()
      val totalFrames = 30
      val frameIntervalMs = 66L

      for (i in 0 until totalFrames) {
        val t = i / totalFrames.toFloat()
        val panX = sin(t * Math.PI.toFloat()) * 20f
        val panY = cos(t * Math.PI.toFloat()) * 10f

        val bitmap = when (presetId) {
          "litter" -> createFloorLitterFrame(context, i, totalFrames, width, height, panX, panY)
          "object_tag" -> createWallGraffitiFrame(i, totalFrames, width, height, panX, panY)
          else -> createWallDampnessFrame(context, i, totalFrames, width, height, panX, panY)
        }

        frames.add(
          VideoFrame(
            index = i,
            timestampMs = i * frameIntervalMs,
            originalBitmap = bitmap,
            cleanedBitmap = null,
            cameraShiftX = panX,
            cameraShiftY = panY
          )
        )
      }
      frames
    }

  suspend fun extractFramesFromUri(
    context: Context,
    uri: Uri,
    maxFrames: Int = 30,
    targetWidth: Int = 480,
    targetHeight: Int = 360
  ): List<VideoFrame> = withContext(Dispatchers.IO) {
    val frames = mutableListOf<VideoFrame>()
    val retriever = MediaMetadataRetriever()
    try {
      retriever.setDataSource(context, uri)
      val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
      val durationMs = durationStr?.toLongOrNull() ?: 3000L
      val stepMs = durationMs / maxFrames.coerceAtLeast(1)

      for (i in 0 until maxFrames) {
        val timeUs = (i * stepMs * 1000L)
        val rawBitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        if (rawBitmap != null) {
          val scaledBitmap = Bitmap.createScaledBitmap(rawBitmap, targetWidth, targetHeight, true)
          frames.add(
            VideoFrame(
              index = i,
              timestampMs = i * stepMs,
              originalBitmap = scaledBitmap,
              cleanedBitmap = null,
              cameraShiftX = 0f,
              cameraShiftY = 0f
            )
          )
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    } finally {
      try {
        retriever.release()
      } catch (_: Exception) {}
    }

    if (frames.isEmpty()) {
      generatePresetFrames(
        context = context,
        presetId = "dampness",
        width = targetWidth,
        height = targetHeight
      )
    } else {
      frames
    }
  }

  private fun createWallDampnessFrame(
    context: Context?,
    frameIndex: Int,
    totalFrames: Int,
    w: Int,
    h: Int,
    panX: Float,
    panY: Float
  ): Bitmap {
    val realPhoto = context?.let {
      try {
        BitmapFactory.decodeResource(it.resources, R.drawable.img_room_wall_dampness_1788517525183)
      } catch (e: Exception) {
        null
      }
    }

    if (realPhoto != null) {
      val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(bitmap)
      val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
      // Draw with subtle parallax camera pan
      val destRect = RectF(panX, panY, w.toFloat() + panX, h.toFloat() + panY)
      canvas.drawBitmap(realPhoto, null, destRect, paint)
      return bitmap
    }

    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Base plaster wall paint
    paint.color = Color.rgb(238, 233, 222)
    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)

    // Plaster subtle texture noise & subtle wall gradient
    val random = Random(42)
    paint.color = Color.rgb(226, 220, 208)
    for (y in 0 until h step 6) {
      for (x in 0 until w step 6) {
        if (random.nextInt(3) == 0) {
          canvas.drawPoint(x.toFloat(), y.toFloat(), paint)
        }
      }
    }

    // Top ceiling molding / corner line with camera pan
    paint.color = Color.rgb(180, 175, 165)
    paint.strokeWidth = 3f
    val ceilingY = 40f + panY * 0.3f
    canvas.drawLine(0f, ceilingY, w.toFloat(), ceilingY, paint)

    // Baseboard at bottom
    paint.color = Color.rgb(205, 198, 185)
    paint.style = Paint.Style.FILL
    val baseboardY = h - 35f + panY * 0.3f
    canvas.drawRect(0f, baseboardY, w.toFloat(), h.toFloat(), paint)
    paint.color = Color.rgb(160, 155, 145)
    paint.strokeWidth = 2f
    canvas.drawLine(0f, baseboardY, w.toFloat(), baseboardY, paint)

    // Moisture / Dampness seepage mark on the wall
    // Position shifts slightly with camera pan
    val dampCenterX = (w * 0.68f) + panX
    val dampCenterY = (h * 0.52f) + panY

    // Dark moisture water seepage gradient
    val dampRadius = 55f
    val dampShader = RadialGradient(
      dampCenterX,
      dampCenterY,
      dampRadius,
      intArrayOf(
        Color.argb(220, 110, 95, 75),  // Darkest water stain center
        Color.argb(175, 145, 128, 105), // Mid seepage
        Color.argb(90, 180, 165, 145),  // Damp ring edge
        Color.TRANSPARENT
      ),
      floatArrayOf(0.0f, 0.45f, 0.85f, 1.0f),
      Shader.TileMode.CLAMP
    )
    val dampPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    dampPaint.shader = dampShader
    canvas.drawCircle(dampCenterX, dampCenterY, dampRadius, dampPaint)

    // Secondary moisture droplet seepage tails
    dampPaint.shader = null
    dampPaint.color = Color.argb(160, 120, 105, 85)
    val path = Path()
    path.moveTo(dampCenterX - 15f, dampCenterY + 20f)
    path.quadTo(dampCenterX - 10f, dampCenterY + 50f, dampCenterX - 12f, dampCenterY + 68f)
    path.quadTo(dampCenterX, dampCenterY + 45f, dampCenterX + 12f, dampCenterY + 30f)
    path.close()
    canvas.drawPath(path, dampPaint)

    return bitmap
  }

  private fun createFloorLitterFrame(
    context: Context?,
    frameIndex: Int,
    totalFrames: Int,
    w: Int,
    h: Int,
    panX: Float,
    panY: Float
  ): Bitmap {
    val realFloorPhoto = context?.let {
      try {
        BitmapFactory.decodeResource(it.resources, R.drawable.img_floor_litter_room_1788517544741)
      } catch (e: Exception) {
        null
      }
    }

    if (realFloorPhoto != null) {
      val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(bitmap)
      val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
      val destRect = RectF(panX, panY, w.toFloat() + panX, h.toFloat() + panY)
      canvas.drawBitmap(realFloorPhoto, null, destRect, paint)
      return bitmap
    }

    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Tiled floor background
    paint.color = Color.rgb(215, 218, 222)
    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)

    // Floor tile grid lines with pan
    paint.color = Color.rgb(180, 184, 190)
    paint.strokeWidth = 2f
    val tileSize = 70f
    var startX = (panX % tileSize)
    while (startX < w) {
      canvas.drawLine(startX, 0f, startX, h.toFloat(), paint)
      startX += tileSize
    }
    var startY = (panY % tileSize)
    while (startY < h) {
      canvas.drawLine(0f, startY, w.toFloat(), startY, paint)
      startY += tileSize
    }

    // Litter / Trash object (crumpled plastic cup & wrapper) on floor
    val trashX = (w * 0.55f) + panX
    val trashY = (h * 0.65f) + panY

    // Shadow of the litter
    paint.color = Color.argb(90, 40, 45, 55)
    paint.style = Paint.Style.FILL
    canvas.drawOval(trashX - 25f, trashY + 8f, trashX + 28f, trashY + 22f, paint)

    // Crumpled red and white soda can / trash cup
    paint.color = Color.rgb(225, 45, 45) // bright red can body
    canvas.drawRoundRect(trashX - 20f, trashY - 18f, trashX + 18f, trashY + 12f, 6f, 6f, paint)

    paint.color = Color.rgb(240, 240, 245) // white stripe / label
    canvas.drawRect(trashX - 8f, trashY - 18f, trashX + 6f, trashY + 12f, paint)

    paint.color = Color.rgb(170, 175, 185) // metal tab / rim
    paint.strokeWidth = 3f
    paint.style = Paint.Style.STROKE
    canvas.drawCircle(trashX + 12f, trashY - 6f, 7f, paint)

    // Discarded plastic wrapper nearby
    paint.style = Paint.Style.FILL
    paint.color = Color.argb(200, 255, 215, 0) // yellow wrapper
    val wrapPath = Path()
    wrapPath.moveTo(trashX + 22f, trashY + 2f)
    wrapPath.lineTo(trashX + 38f, trashY - 8f)
    wrapPath.lineTo(trashX + 32f, trashY + 10f)
    wrapPath.close()
    canvas.drawPath(wrapPath, paint)

    return bitmap
  }

  private fun createWallGraffitiFrame(
    frameIndex: Int,
    totalFrames: Int,
    w: Int,
    h: Int,
    panX: Float,
    panY: Float
  ): Bitmap {
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Soft teal-gray painted wall
    paint.color = Color.rgb(220, 228, 230)
    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)

    // Wall texture
    paint.color = Color.rgb(208, 218, 220)
    val random = Random(99)
    for (i in 0..400) {
      canvas.drawCircle(
        random.nextFloat() * w,
        random.nextFloat() * h,
        1.5f,
        paint
      )
    }

    // Unwanted wall marker graffiti tag / scuff mark
    val objX = (w * 0.70f) + panX
    val objY = (h * 0.40f) + panY

    paint.color = Color.rgb(220, 38, 38) // dark red spray/marker
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = 6f
    val markPath = Path()
    markPath.moveTo(objX - 25f, objY - 20f)
    markPath.quadTo(objX - 5f, objY - 35f, objX + 20f, objY - 15f)
    markPath.lineTo(objX + 5f, objY + 18f)
    markPath.quadTo(objX - 18f, objY + 28f, objX + 22f, objY + 25f)
    canvas.drawPath(markPath, paint)

    // Smudge
    paint.color = Color.argb(120, 60, 60, 60)
    paint.strokeWidth = 3f
    canvas.drawLine(objX - 20f, objY + 10f, objX - 8f, objY + 32f, paint)

    return bitmap
  }
}
