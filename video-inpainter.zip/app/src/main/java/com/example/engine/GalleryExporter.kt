package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object GalleryExporter {

  /**
   * Saves a clean transformed photo directly into the Android device's public Gallery (Pictures/GeminiHomeMakeover)
   */
  suspend fun savePhotoToGallery(context: Context, bitmap: Bitmap, title: String = "Gemini_Makeover"): Uri? =
    withContext(Dispatchers.IO) {
      val filename = "${title}_${System.currentTimeMillis()}.jpg"
      var fos: OutputStream? = null
      var imageUri: Uri? = null

      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          val resolver = context.contentResolver
          val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GeminiMakeover")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
          }
          val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
          if (uri != null) {
            imageUri = uri
            fos = resolver.openOutputStream(uri)
            if (fos != null) {
              bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos)
            }
            contentValues.clear()
            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, contentValues, null, null)
          }
        } else {
          val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
          val subDir = File(imagesDir, "GeminiMakeover")
          if (!subDir.exists()) subDir.mkdirs()
          val imageFile = File(subDir, filename)
          fos = FileOutputStream(imageFile)
          bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos)
          imageUri = Uri.fromFile(imageFile)
        }
      } catch (e: Exception) {
        e.printStackTrace()
      } finally {
        fos?.close()
      }

      imageUri
    }

  /**
   * Saves a clean transformed video frame sequence or video file to Movies/GeminiMakeover
   */
  suspend fun saveVideoToGallery(context: Context, sourceFile: File, title: String = "Gemini_Clean_Video"): Uri? =
    withContext(Dispatchers.IO) {
      val filename = "${title}_${System.currentTimeMillis()}.mp4"
      var fos: OutputStream? = null
      var videoUri: Uri? = null

      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          val resolver = context.contentResolver
          val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/GeminiMakeover")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
          }
          val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
          if (uri != null) {
            videoUri = uri
            fos = resolver.openOutputStream(uri)
            if (fos != null) {
              sourceFile.inputStream().use { input ->
                input.copyTo(fos)
              }
            }
            contentValues.clear()
            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, contentValues, null, null)
          }
        } else {
          val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
          val subDir = File(moviesDir, "GeminiMakeover")
          if (!subDir.exists()) subDir.mkdirs()
          val videoFile = File(subDir, filename)
          sourceFile.copyTo(videoFile, overwrite = true)
          videoUri = Uri.fromFile(videoFile)
        }
      } catch (e: Exception) {
        e.printStackTrace()
      } finally {
        fos?.close()
      }

      videoUri
    }

  /**
   * Open the saved photo or video in the system viewer
   */
  fun openMediaInSystemViewer(context: Context, uri: Uri, isVideo: Boolean) {
    try {
      val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, if (isVideo) "video/*" else "image/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      Toast.makeText(context, "गैलरी ऐप में देखने के लिए Photos या Video ऐप खोलें", Toast.LENGTH_SHORT).show()
    }
  }
}
