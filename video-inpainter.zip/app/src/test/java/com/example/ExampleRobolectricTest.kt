package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Video Inpainter", appName)
  }

  @Test
  fun `clone patch inpainting executes and produces non-null bitmap`() {
    val bitmap = android.graphics.Bitmap.createBitmap(100, 100, android.graphics.Bitmap.Config.ARGB_8888)
    val config = com.example.model.ClonePatchConfig()
    val cleaned = com.example.engine.InpaintingEngine.applyClonePatch(bitmap, config)
    org.junit.Assert.assertNotNull(cleaned)
    assertEquals(100, cleaned.width)
    assertEquals(100, cleaned.height)
  }

  @Test
  fun `text instruction in Hindi recognizes dampness and configures patch`() = kotlinx.coroutines.test.runTest {
    val bitmap = android.graphics.Bitmap.createBitmap(120, 120, android.graphics.Bitmap.Config.ARGB_8888)
    val result = com.example.engine.InpaintingEngine.processTextInstruction(
      bitmap = bitmap,
      prompt = "इस वीडियो में से दीवार की सीलन हटा दो एकदम प्रॉपर तरीके से"
    )
    org.junit.Assert.assertNotNull(result)
    org.junit.Assert.assertTrue(result.detectedCategory.contains("सीलन") || result.detectedCategory.contains("Dampness"))
    org.junit.Assert.assertTrue(result.confidence > 0.9f)
    org.junit.Assert.assertTrue(result.explanationHindi.isNotEmpty())
  }

  @Test
  fun `text instruction in English recognizes floor litter`() = kotlinx.coroutines.test.runTest {
    val bitmap = android.graphics.Bitmap.createBitmap(120, 120, android.graphics.Bitmap.Config.ARGB_8888)
    val result = com.example.engine.InpaintingEngine.processTextInstruction(
      bitmap = bitmap,
      prompt = "Please remove floor litter and trash from this video"
    )
    org.junit.Assert.assertNotNull(result)
    org.junit.Assert.assertTrue(result.detectedCategory.contains("कचरा") || result.detectedCategory.contains("Litter"))
    org.junit.Assert.assertTrue(result.confidence > 0.9f)
  }

  @Test
  fun `wall paint applies seamlessly with color blending`() {
    val bitmap = android.graphics.Bitmap.createBitmap(80, 80, android.graphics.Bitmap.Config.ARGB_8888)
    val config = com.example.model.WallPaintConfig(
      enabled = true,
      colorHex = 0xFF1E3A8A,
      opacity = 0.5f
    )
    val painted = com.example.engine.InpaintingEngine.applyWallPaint(bitmap, config)
    org.junit.Assert.assertNotNull(painted)
    assertEquals(80, painted.width)
    assertEquals(80, painted.height)
  }

  @Test
  fun `decor overlay renders wall art and plant onto video frame`() {
    val bitmap = android.graphics.Bitmap.createBitmap(100, 100, android.graphics.Bitmap.Config.ARGB_8888)
    val items = listOf(
      com.example.model.DecorItem(
        id = "1",
        type = com.example.model.DecorType.WALL_ART_FRAME,
        nameHindi = "वॉल आर्ट",
        nameEnglish = "Art",
        normalizedX = 0.5f,
        normalizedY = 0.4f
      ),
      com.example.model.DecorItem(
        id = "2",
        type = com.example.model.DecorType.INDOOR_PLANT,
        nameHindi = "पौधा",
        nameEnglish = "Plant",
        normalizedX = 0.2f,
        normalizedY = 0.6f
      )
    )
    val decorated = com.example.engine.InpaintingEngine.renderDecorOverlay(bitmap, items)
    org.junit.Assert.assertNotNull(decorated)
    assertEquals(100, decorated.width)
  }
}

