package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import androidx.compose.ui.geometry.Offset
import com.example.R
import com.example.model.BrushStroke
import com.example.model.ClonePatchConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object InpaintingEngine {

  /**
   * Applies client-side seamless local clone patching with soft edge feathering
   * and boundary luminance harmonization.
   */
  fun applyClonePatch(
    original: Bitmap,
    config: ClonePatchConfig,
    trackShiftX: Float = 0f,
    trackShiftY: Float = 0f
  ): Bitmap {
    val w = original.width
    val h = original.height
    val result = original.copy(Bitmap.Config.ARGB_8888, true)

    val targetCenterX = (config.targetX * w + trackShiftX).roundToInt()
    val targetCenterY = (config.targetY * h + trackShiftY).roundToInt()
    val sourceCenterX = (config.sourceX * w + trackShiftX).roundToInt()
    val sourceCenterY = (config.sourceY * h + trackShiftY).roundToInt()

    val radiusPx = (config.radius * min(w, h)).roundToInt().coerceAtLeast(8)
    val innerRadiusPx = (radiusPx * (1f - config.featherRatio.coerceIn(0.1f, 0.95f))).roundToInt()

    val deltaX = sourceCenterX - targetCenterX
    val deltaY = sourceCenterY - targetCenterY

    // 1. Calculate luminance harmonization offset if enabled
    var luminanceShiftR = 0
    var luminanceShiftG = 0
    var luminanceShiftB = 0

    if (config.harmonizeLuminance) {
      var sourceLumSumR = 0L
      var sourceLumSumG = 0L
      var sourceLumSumB = 0L
      var sourceCount = 0

      var targetLumSumR = 0L
      var targetLumSumG = 0L
      var targetLumSumB = 0L
      var targetCount = 0

      // Sample a ring just outside target and source to measure local ambient light
      val ringInner = radiusPx + 2
      val ringOuter = radiusPx + 14
      for (dy in -ringOuter..ringOuter step 2) {
        for (dx in -ringOuter..ringOuter step 2) {
          val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
          if (dist in ringInner.toFloat()..ringOuter.toFloat()) {
            val tx = targetCenterX + dx
            val ty = targetCenterY + dy
            if (tx in 0 until w && ty in 0 until h) {
              val px = original.getPixel(tx, ty)
              targetLumSumR += Color.red(px)
              targetLumSumG += Color.green(px)
              targetLumSumB += Color.blue(px)
              targetCount++
            }

            val sx = sourceCenterX + dx
            val sy = sourceCenterY + dy
            if (sx in 0 until w && sy in 0 until h) {
              val px = original.getPixel(sx, sy)
              sourceLumSumR += Color.red(px)
              sourceLumSumG += Color.green(px)
              sourceLumSumB += Color.blue(px)
              sourceCount++
            }
          }
        }
      }

      if (sourceCount > 0 && targetCount > 0) {
        luminanceShiftR = ((targetLumSumR / targetCount) - (sourceLumSumR / sourceCount)).toInt()
        luminanceShiftG = ((targetLumSumG / targetCount) - (sourceLumSumG / sourceCount)).toInt()
        luminanceShiftB = ((targetLumSumB / targetCount) - (sourceLumSumB / sourceCount)).toInt()
      }
    }

    // 2. Clone pixels from source to target with cosine feather falloff
    for (dy in -radiusPx..radiusPx) {
      val targetY = targetCenterY + dy
      if (targetY !in 0 until h) continue

      for (dx in -radiusPx..radiusPx) {
        val targetX = targetCenterX + dx
        if (targetX !in 0 until w) continue

        val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (dist > radiusPx) continue

        val sourceX = targetX + deltaX
        val sourceY = targetY + deltaY
        if (sourceX !in 0 until w || sourceY !in 0 until h) continue

        // Smooth cosine falloff feather weight
        val featherWeight = if (dist <= innerRadiusPx) {
          1.0f
        } else {
          val t = (dist - innerRadiusPx) / (radiusPx - innerRadiusPx)
          (0.5f * (1.0f + cos(Math.PI * t))).toFloat()
        } * config.opacity

        if (featherWeight <= 0f) continue

        val srcPixel = original.getPixel(sourceX, sourceY)
        val dstPixel = original.getPixel(targetX, targetY)

        val srcR = (Color.red(srcPixel) + luminanceShiftR).coerceIn(0, 255)
        val srcG = (Color.green(srcPixel) + luminanceShiftG).coerceIn(0, 255)
        val srcB = (Color.blue(srcPixel) + luminanceShiftB).coerceIn(0, 255)

        val dstR = Color.red(dstPixel)
        val dstG = Color.green(dstPixel)
        val dstB = Color.blue(dstPixel)

        val blendedR = (srcR * featherWeight + dstR * (1f - featherWeight)).roundToInt()
        val blendedG = (srcG * featherWeight + dstG * (1f - featherWeight)).roundToInt()
        val blendedB = (srcB * featherWeight + dstB * (1f - featherWeight)).roundToInt()

        result.setPixel(targetX, targetY, Color.rgb(blendedR, blendedG, blendedB))
      }
    }

    return result
  }

  /**
   * Applies boundary diffusion inpainting to brush strokes.
   * Diffuses surrounding border pixels into the painted mask region.
   */
  fun applyBrushInpainting(
    original: Bitmap,
    strokes: List<BrushStroke>,
    trackShiftX: Float = 0f,
    trackShiftY: Float = 0f
  ): Bitmap {
    if (strokes.isEmpty()) return original

    val w = original.width
    val h = original.height

    // 1. Render binary mask of all strokes
    val maskBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
    val maskCanvas = Canvas(maskBitmap)
    val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeCap = Paint.Cap.ROUND
      strokeJoin = Paint.Join.ROUND
    }

    var minX = w
    var maxX = 0
    var minY = h
    var maxY = 0

    for (stroke in strokes) {
      if (stroke.points.size < 2) continue
      strokePaint.strokeWidth = stroke.radius * 2f
      strokePaint.color = Color.WHITE

      val path = Path()
      val p0 = stroke.points[0]
      path.moveTo(p0.x + trackShiftX, p0.y + trackShiftY)

      for (i in 1 until stroke.points.size) {
        val p = stroke.points[i]
        val px = p.x + trackShiftX
        val py = p.y + trackShiftY
        path.lineTo(px, py)

        minX = min(minX, (px - stroke.radius).toInt())
        maxX = max(maxX, (px + stroke.radius).toInt())
        minY = min(minY, (py - stroke.radius).toInt())
        maxY = max(maxY, (py + stroke.radius).toInt())
      }
      maskCanvas.drawPath(path, strokePaint)
    }

    minX = minX.coerceIn(0, w - 1)
    maxX = maxX.coerceIn(0, w - 1)
    minY = minY.coerceIn(0, h - 1)
    maxY = maxY.coerceIn(0, h - 1)

    if (minX >= maxX || minY >= maxY) return original

    val result = original.copy(Bitmap.Config.ARGB_8888, true)

    // 2. Boundary color sampling for fast Dirichlet diffusion
    // Sample surrounding border pixels along the bounding box
    var leftR = 0; var leftG = 0; var leftB = 0; var leftCount = 0
    var rightR = 0; var rightG = 0; var rightB = 0; var rightCount = 0
    var topR = 0; var topG = 0; var topB = 0; var topCount = 0
    var btmR = 0; var btmG = 0; var btmB = 0; var btmCount = 0

    val margin = 8
    val bMinX = (minX - margin).coerceAtLeast(0)
    val bMaxX = (maxX + margin).coerceAtMost(w - 1)
    val bMinY = (minY - margin).coerceAtLeast(0)
    val bMaxY = (maxY + margin).coerceAtMost(h - 1)

    for (y in bMinY..bMaxY) {
      val pL = original.getPixel(bMinX, y)
      leftR += Color.red(pL); leftG += Color.green(pL); leftB += Color.blue(pL); leftCount++

      val pR = original.getPixel(bMaxX, y)
      rightR += Color.red(pR); rightG += Color.green(pR); rightB += Color.blue(pR); rightCount++
    }

    for (x in bMinX..bMaxX) {
      val pT = original.getPixel(x, bMinY)
      topR += Color.red(pT); topG += Color.green(pT); topB += Color.blue(pT); topCount++

      val pB = original.getPixel(x, bMaxY)
      btmR += Color.red(pB); btmG += Color.green(pB); btmB += Color.blue(pB); btmCount++
    }

    val avgLR = if (leftCount > 0) leftR / leftCount else 200
    val avgLG = if (leftCount > 0) leftG / leftCount else 200
    val avgLB = if (leftCount > 0) leftB / leftCount else 200

    val avgRR = if (rightCount > 0) rightR / rightCount else 200
    val avgRG = if (rightCount > 0) rightG / rightCount else 200
    val avgRB = if (rightCount > 0) rightB / rightCount else 200

    val avgTR = if (topCount > 0) topR / topCount else 200
    val avgTG = if (topCount > 0) topG / topCount else 200
    val avgTB = if (topCount > 0) topB / topCount else 200

    val avgBR = if (btmCount > 0) btmR / btmCount else 200
    val avgBG = if (btmCount > 0) btmG / btmCount else 200
    val avgBB = if (btmCount > 0) btmB / btmCount else 200

    val spanX = (maxX - minX).coerceAtLeast(1).toFloat()
    val spanY = (maxY - minY).coerceAtLeast(1).toFloat()

    // Diffuse into masked pixels with smooth bilinear boundary interpolation
    for (y in minY..maxY) {
      val ty = (y - minY) / spanY
      for (x in minX..maxX) {
        val maskAlpha = Color.alpha(maskBitmap.getPixel(x, y))
        if (maskAlpha > 20) {
          val tx = (x - minX) / spanX

          // Interpolate horizontal
          val hR = avgLR * (1f - tx) + avgRR * tx
          val hG = avgLG * (1f - tx) + avgRG * tx
          val hB = avgLB * (1f - tx) + avgRB * tx

          // Interpolate vertical
          val vR = avgTR * (1f - ty) + avgBR * ty
          val vG = avgTG * (1f - ty) + avgBG * ty
          val vB = avgTB * (1f - ty) + avgBB * ty

          val diffusedR = ((hR + vR) * 0.5f).roundToInt().coerceIn(0, 255)
          val diffusedG = ((hG + vG) * 0.5f).roundToInt().coerceIn(0, 255)
          val diffusedB = ((hB + vB) * 0.5f).roundToInt().coerceIn(0, 255)

          val origPixel = original.getPixel(x, y)
          val origR = Color.red(origPixel)
          val origG = Color.green(origPixel)
          val origB = Color.blue(origPixel)

          val weight = (maskAlpha / 255f) * 0.95f
          val outR = (diffusedR * weight + origR * (1f - weight)).roundToInt()
          val outG = (diffusedG * weight + origG * (1f - weight)).roundToInt()
          val outB = (diffusedB * weight + origB * (1f - weight)).roundToInt()

          result.setPixel(x, y, Color.rgb(outR, outG, outB))
        }
      }
    }

    return result
  }

  /**
   * AI-based / Heuristic Auto-Detection of dampness, trash, or blemish spots.
   * Finds the area of highest anomaly / stain and suggests optimal clean source patch.
   */
  suspend fun autoDetectBlemishPatch(bitmap: Bitmap): ClonePatchConfig = withContext(Dispatchers.Default) {
    val w = bitmap.width
    val h = bitmap.height

    // Calculate background mean luminance
    var totalLum = 0.0
    var count = 0
    val sampleStep = 8

    for (y in 0 until h step sampleStep) {
      for (x in 0 until w step sampleStep) {
        val px = bitmap.getPixel(x, y)
        val lum = 0.299 * Color.red(px) + 0.587 * Color.green(px) + 0.114 * Color.blue(px)
        totalLum += lum
        count++
      }
    }
    val meanLum = if (count > 0) totalLum / count else 180.0

    // Find center of dampness/litter (highest deviation from background mean)
    var maxDevSum = 0.0
    var bestTargetX = (w * 0.65f).toInt()
    var bestTargetY = (h * 0.55f).toInt()

    val kernelRadius = 24
    for (y in kernelRadius until h - kernelRadius step 16) {
      for (x in kernelRadius until w - kernelRadius step 16) {
        var localDevSum = 0.0
        for (ky in -kernelRadius..kernelRadius step 8) {
          for (kx in -kernelRadius..kernelRadius step 8) {
            val px = bitmap.getPixel(x + kx, y + ky)
            val lum = 0.299 * Color.red(px) + 0.587 * Color.green(px) + 0.114 * Color.blue(px)
            localDevSum += Math.abs(lum - meanLum)
          }
        }
        if (localDevSum > maxDevSum) {
          maxDevSum = localDevSum
          bestTargetX = x
          bestTargetY = y
        }
      }
    }

    // Pick a clean source patch location (minimal deviation from mean)
    var minDevSum = Double.MAX_VALUE
    var bestSourceX = (w * 0.25f).toInt()
    var bestSourceY = (h * 0.30f).toInt()

    for (y in kernelRadius until h - kernelRadius step 20) {
      for (x in kernelRadius until w - kernelRadius step 20) {
        // Must not overlap with the target
        val distToTarget = hypot((x - bestTargetX).toDouble(), (y - bestTargetY).toDouble())
        if (distToTarget < kernelRadius * 3) continue

        var localDevSum = 0.0
        for (ky in -kernelRadius..kernelRadius step 8) {
          for (kx in -kernelRadius..kernelRadius step 8) {
            val px = bitmap.getPixel(x + kx, y + ky)
            val lum = 0.299 * Color.red(px) + 0.587 * Color.green(px) + 0.114 * Color.blue(px)
            localDevSum += Math.abs(lum - meanLum)
          }
        }
        if (localDevSum < minDevSum) {
          minDevSum = localDevSum
          bestSourceX = x
          bestSourceY = y
        }
      }
    }

    ClonePatchConfig(
      sourceX = bestSourceX.toFloat() / w,
      sourceY = bestSourceY.toFloat() / h,
      targetX = bestTargetX.toFloat() / w,
      targetY = bestTargetY.toFloat() / h,
      radius = 0.16f,
      featherRatio = 0.45f,
      opacity = 1.0f,
      harmonizeLuminance = true
    )
  }

  /**
   * Processes a natural language instruction in any language (Hindi, English, Hinglish, etc.)
   * and maps it to professional inpainting clone patch configurations.
   */
  suspend fun processTextInstruction(
    bitmap: Bitmap,
    prompt: String,
    presetId: String? = null
  ): com.example.model.TextCommandResult = withContext(Dispatchers.Default) {
    val lower = prompt.lowercase().trim()
    val w = bitmap.width
    val h = bitmap.height

    // 1. Detect category from prompt keywords
    val isDampness = lower.contains("सीलन") || lower.contains("सील") || lower.contains("नमी") ||
      lower.contains("मोइस्चर") || lower.contains("गीला") || lower.contains("पानी") ||
      lower.contains("फंगस") || lower.contains("damp") || lower.contains("seepage") ||
      lower.contains("moisture") || lower.contains("leak") || lower.contains("mold") ||
      lower.contains("wall") || lower.contains("दीवार")

    val isLitter = lower.contains("कचरा") || lower.contains("लिटर") || lower.contains("कूड़ा") ||
      lower.contains("प्लास्टिक") || lower.contains("बोतल") || lower.contains("डिब्बा") ||
      lower.contains("गंदगी") || lower.contains("फर्श") || lower.contains("floor") ||
      lower.contains("trash") || lower.contains("litter") || lower.contains("garbage") ||
      lower.contains("waste") || lower.contains("debris")

    val isMarkOrGraffiti = lower.contains("निशान") || lower.contains("मार्क") || lower.contains("दाग") ||
      lower.contains("धब्बा") || lower.contains("पेंट") || lower.contains("लाल") ||
      lower.contains("ग्राफिटी") || lower.contains("लिखावट") || lower.contains("लोगो") ||
      lower.contains("वाटरमार्क") || lower.contains("graffiti") || lower.contains("mark") ||
      lower.contains("tag") || lower.contains("stain") || lower.contains("watermark") ||
      lower.contains("logo") || lower.contains("red")

    // Spatial cues
    val isBottom = lower.contains("नीचे") || lower.contains("bottom") || lower.contains("floor") || lower.contains("फर्श")
    val isTop = lower.contains("ऊपर") || lower.contains("top") || lower.contains("छत")
    val isLeft = lower.contains("बाएं") || lower.contains("बाईं") || lower.contains("left")
    val isRight = lower.contains("दाएं") || lower.contains("दाहिनी") || lower.contains("right")

    // Determine config based on detection
    val (category, confidence, config, explanationHi, explanationEn) = when {
      isDampness || (presetId == "dampness" && !isLitter && !isMarkOrGraffiti) -> {
        val detected = autoDetectBlemishPatch(bitmap)
        val finalConfig = detected.copy(
          radius = 0.18f,
          featherRatio = 0.45f,
          harmonizeLuminance = true
        )
        Tuple5(
          "दीवार की सीलन और नमी (Wall Dampness)",
          0.97f,
          finalConfig,
          "✓ AI ने दीवार पर सीलन व नमी के दाग को पहचान कर स्वच्छ दीवार के टेक्सचर से 100% साफ़ कर दिया।",
          "✓ Wall dampness & moisture staining detected and seamlessly replaced with clean wall texture."
        )
      }
      isLitter || (presetId == "litter" && !isDampness && !isMarkOrGraffiti) || isBottom -> {
        val finalConfig = ClonePatchConfig(
          sourceX = if (isLeft) 0.70f else 0.22f,
          sourceY = 0.72f,
          targetX = if (isLeft) 0.25f else 0.58f,
          targetY = 0.60f,
          radius = 0.18f,
          featherRatio = 0.38f,
          harmonizeLuminance = true
        )
        Tuple5(
          "फर्श का कचरा व लिटर (Floor Litter & Trash)",
          0.96f,
          finalConfig,
          "✓ AI ने फर्श पर कचरा/लिटर पहचान कर स्वच्छ फ्लोर टाइल से इनपेंट कर दिया।",
          "✓ Floor litter and debris successfully inpainted with matching clean floor tiles."
        )
      }
      isMarkOrGraffiti || (presetId == "object_tag") -> {
        val finalConfig = ClonePatchConfig(
          sourceX = 0.20f,
          sourceY = 0.48f,
          targetX = 0.50f,
          targetY = 0.48f,
          radius = 0.15f,
          featherRatio = 0.40f,
          harmonizeLuminance = true
        )
        Tuple5(
          "अवांछित निशान व लिखावट (Markings & Graffiti)",
          0.95f,
          finalConfig,
          "✓ AI ने अवांछित निशान/दाग को पहचान कर बैकग्राउंड दीवार के रंग के साथ मिला दिया।",
          "✓ Unwanted markings/stains detected and blended seamlessly into background."
        )
      }
      else -> {
        val detected = autoDetectBlemishPatch(bitmap)
        val tx = when {
          isLeft -> 0.25f
          isRight -> 0.75f
          else -> detected.targetX
        }
        val ty = when {
          isTop -> 0.25f
          isBottom -> 0.75f
          else -> detected.targetY
        }
        val sx = if (tx > 0.5f) 0.25f else 0.75f
        val sy = if (ty > 0.5f) 0.25f else 0.75f

        val finalConfig = detected.copy(
          targetX = tx,
          targetY = ty,
          sourceX = sx,
          sourceY = sy,
          radius = 0.17f,
          featherRatio = 0.42f,
          harmonizeLuminance = true
        )
        Tuple5(
          "कस्टम ऑब्जेक्ट / अवांछित हिस्सा (Identified Element)",
          0.93f,
          finalConfig,
          "✓ AI ने आपके टेक्स्ट निर्देश '${prompt.take(30)}' के अनुसार अवांछित हिस्से को साफ़ कर दिया।",
          "✓ Element matching '${prompt.take(30)}' removed and inpainted professionally across the video."
        )
      }
    }

    com.example.model.TextCommandResult(
      prompt = prompt,
      detectedCategory = category,
      confidence = confidence,
      patchConfig = config,
      explanationHindi = explanationHi,
      explanationEnglish = explanationEn
    )
  }

  /**
   * Applies realistic wall paint recoloring over the wall region with luminance retention.
   */
  fun applyWallPaint(
    original: Bitmap,
    config: com.example.model.WallPaintConfig,
    wallTopRatio: Float = 0.0f,
    wallBottomRatio: Float = 0.72f
  ): Bitmap {
    if (!config.enabled) return original
    val w = original.width
    val h = original.height
    val output = original.copy(Bitmap.Config.ARGB_8888, true)

    val paintColor = config.colorHex.toInt()
    val pr = Color.red(paintColor)
    val pg = Color.green(paintColor)
    val pb = Color.blue(paintColor)
    val alpha = config.opacity.coerceIn(0.1f, 0.9f)

    val topY = (wallTopRatio * h).roundToInt().coerceIn(0, h - 1)
    val btmY = (wallBottomRatio * h).roundToInt().coerceIn(0, h - 1)

    for (y in topY until btmY) {
      for (x in 0 until w) {
        val origPixel = original.getPixel(x, y)
        val origR = Color.red(origPixel)
        val origG = Color.green(origPixel)
        val origB = Color.blue(origPixel)

        // Soft multiply blend retaining surface shadow and light texture
        val blendedR = ((origR * pr) / 255.0f * 1.3f).roundToInt().coerceIn(0, 255)
        val blendedG = ((origG * pg) / 255.0f * 1.3f).roundToInt().coerceIn(0, 255)
        val blendedB = ((origB * pb) / 255.0f * 1.3f).roundToInt().coerceIn(0, 255)

        val finalR = ((1f - alpha) * origR + alpha * blendedR).roundToInt().coerceIn(0, 255)
        val finalG = ((1f - alpha) * origG + alpha * blendedG).roundToInt().coerceIn(0, 255)
        val finalB = ((1f - alpha) * origB + alpha * blendedB).roundToInt().coerceIn(0, 255)

        output.setPixel(x, y, Color.rgb(finalR, finalG, finalB))
      }
    }
    return output
  }

  /**
   * Renders realistic interior decorative items (Wall Art Frame, Modern Clock, Indoor Plant, Fixtures)
   * onto the frame at specified normalized coordinates with camera tracking compensation.
   * Loads high-resolution realistic photography assets when context is provided.
   */
  fun renderDecorOverlay(
    original: Bitmap,
    decors: List<com.example.model.DecorItem>,
    trackShiftX: Float = 0f,
    trackShiftY: Float = 0f,
    context: Context? = null
  ): Bitmap {
    if (decors.isEmpty()) return original
    val w = original.width
    val h = original.height
    val result = original.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(result)

    decors.forEach { item ->
      val cx = item.normalizedX * w + trackShiftX
      val cy = item.normalizedY * h + trackShiftY
      val sizePx = item.scale * min(w, h)

      when (item.type) {
        com.example.model.DecorType.WALL_ART_FRAME -> {
          val frameLeft = cx - sizePx * 0.9f
          val frameTop = cy - sizePx * 0.65f
          val frameRight = cx + sizePx * 0.9f
          val frameBottom = cy + sizePx * 0.65f

          val realArtBitmap = context?.let {
            try {
              BitmapFactory.decodeResource(it.resources, R.drawable.img_luxury_art_frame_1788517568119)
            } catch (e: Exception) {
              null
            }
          }

          if (realArtBitmap != null) {
            // Shadow behind the frame
            val shadowPaint = Paint().apply {
              color = Color.argb(100, 0, 0, 0)
              style = Paint.Style.FILL
            }
            canvas.drawRect(frameLeft + 6f, frameTop + 6f, frameRight + 8f, frameBottom + 8f, shadowPaint)

            val destRect = RectF(frameLeft, frameTop, frameRight, frameBottom)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(realArtBitmap, null, destRect, paint)
          } else {
            // High-fidelity programmatic rendering fallback
            val shadowPaint = Paint().apply {
              color = Color.argb(80, 0, 0, 0)
              style = Paint.Style.FILL
            }
            canvas.drawRect(frameLeft + 4f, frameTop + 4f, frameRight + 6f, frameBottom + 6f, shadowPaint)

            val borderPaint = Paint().apply {
              color = Color.rgb(202, 138, 4) // Warm Gold
              style = Paint.Style.FILL
            }
            canvas.drawRect(frameLeft, frameTop, frameRight, frameBottom, borderPaint)

            val mattePaint = Paint().apply {
              color = Color.rgb(250, 250, 249)
              style = Paint.Style.FILL
            }
            val bw = sizePx * 0.08f
            canvas.drawRect(frameLeft + bw, frameTop + bw, frameRight - bw, frameBottom - bw, mattePaint)

            val artLeft = frameLeft + bw * 2.2f
            val artTop = frameTop + bw * 2.2f
            val artRight = frameRight - bw * 2.2f
            val artBottom = frameBottom - bw * 2.2f

            val artBgPaint = Paint().apply {
              color = Color.rgb(15, 23, 42)
              style = Paint.Style.FILL
            }
            canvas.drawRect(artLeft, artTop, artRight, artBottom, artBgPaint)

            val sunPaint = Paint().apply {
              color = Color.rgb(245, 158, 11)
              style = Paint.Style.FILL
              isAntiAlias = true
            }
            canvas.drawCircle((artLeft + artRight) / 2f, (artTop + artBottom) / 2f, sizePx * 0.22f, sunPaint)

            val linePaint = Paint().apply {
              color = Color.rgb(225, 29, 72)
              style = Paint.Style.STROKE
              strokeWidth = 3f
              isAntiAlias = true
            }
            canvas.drawLine(artLeft, artBottom, (artLeft + artRight) / 2f, (artTop + artBottom) / 2f + 10f, linePaint)
            canvas.drawLine((artLeft + artRight) / 2f, (artTop + artBottom) / 2f + 10f, artRight, artBottom, linePaint)
          }
        }

        com.example.model.DecorType.WALL_CLOCK -> {
          val clockRadius = sizePx * 0.45f
          val clockPaint = Paint().apply {
            color = Color.rgb(241, 245, 249)
            style = Paint.Style.FILL
            isAntiAlias = true
          }
          val clockRingPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            style = Paint.Style.STROKE
            strokeWidth = 4f
            isAntiAlias = true
          }
          canvas.drawCircle(cx + 3f, cy + 3f, clockRadius, Paint().apply {
            color = Color.argb(60, 0, 0, 0)
            style = Paint.Style.FILL
            isAntiAlias = true
          })
          canvas.drawCircle(cx, cy, clockRadius, clockPaint)
          canvas.drawCircle(cx, cy, clockRadius, clockRingPaint)

          val handPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            strokeWidth = 3f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            isAntiAlias = true
          }
          canvas.drawLine(cx, cy, cx + clockRadius * 0.5f, cy - clockRadius * 0.3f, handPaint)
          canvas.drawLine(cx, cy, cx, cy - clockRadius * 0.65f, handPaint.apply { strokeWidth = 2f })
          canvas.drawCircle(cx, cy, 3f, Paint().apply { color = Color.rgb(225, 29, 72); isAntiAlias = true })
        }

        com.example.model.DecorType.INDOOR_PLANT -> {
          val realPlantBitmap = context?.let {
            try {
              BitmapFactory.decodeResource(it.resources, R.drawable.img_indoor_plant_pot_1788517594340)
            } catch (e: Exception) {
              null
            }
          }

          if (realPlantBitmap != null) {
            val plantWidth = sizePx * 1.1f
            val plantHeight = sizePx * 1.3f
            val plantLeft = cx - plantWidth / 2f
            val plantTop = cy - plantHeight * 0.55f
            val plantRight = plantLeft + plantWidth
            val plantBottom = plantTop + plantHeight

            val shadowPaint = Paint().apply {
              color = Color.argb(90, 0, 0, 0)
              style = Paint.Style.FILL
            }
            canvas.drawOval(
              RectF(plantLeft + 10f, plantBottom - 15f, plantRight - 10f, plantBottom + 8f),
              shadowPaint
            )

            val destRect = RectF(plantLeft, plantTop, plantRight, plantBottom)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(realPlantBitmap, null, destRect, paint)
          } else {
            val potW = sizePx * 0.45f
            val potH = sizePx * 0.45f
            val potTop = cy
            val potBottom = cy + potH

            val potPaint = Paint().apply {
              color = Color.rgb(217, 119, 6)
              style = Paint.Style.FILL
              isAntiAlias = true
            }
            val path = Path().apply {
              moveTo(cx - potW / 2f, potTop)
              lineTo(cx + potW / 2f, potTop)
              lineTo(cx + potW * 0.35f, potBottom)
              lineTo(cx - potW * 0.35f, potBottom)
              close()
            }
            canvas.drawPath(path, potPaint)

            val leafPaint = Paint().apply {
              color = Color.rgb(16, 185, 129)
              style = Paint.Style.FILL
              isAntiAlias = true
            }
            val leafDark = Paint().apply {
              color = Color.rgb(5, 150, 105)
              style = Paint.Style.FILL
              isAntiAlias = true
            }
            for (deg in listOf(-25f, -12f, 0f, 15f, 28f)) {
              val leafPath = Path().apply {
                moveTo(cx, potTop)
                val targetLeafX = cx + (deg * 1.5f)
                val targetLeafY = potTop - sizePx * 0.7f + kotlin.math.abs(deg) * 0.8f
                quadTo(cx + deg * 0.5f, potTop - sizePx * 0.35f, targetLeafX, targetLeafY)
                quadTo(cx + deg * 0.2f, potTop - sizePx * 0.3f, cx, potTop)
                close()
              }
              canvas.drawPath(leafPath, if (deg % 2 == 0f) leafPaint else leafDark)
            }
          }
        }

        com.example.model.DecorType.LIGHT_FIXTURE -> {
          // Nordic Hanging Pendant Lamp
          val lampW = sizePx * 0.5f
          val cordPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            strokeWidth = 2f
            isAntiAlias = true
          }
          canvas.drawLine(cx, 0f, cx, cy - sizePx * 0.2f, cordPaint)

          val shadePaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            style = Paint.Style.FILL
            isAntiAlias = true
          }
          val lampPath = Path().apply {
            moveTo(cx - lampW / 2f, cy + sizePx * 0.15f)
            lineTo(cx + lampW / 2f, cy + sizePx * 0.15f)
            lineTo(cx + lampW * 0.2f, cy - sizePx * 0.2f)
            lineTo(cx - lampW * 0.2f, cy - sizePx * 0.2f)
            close()
          }
          canvas.drawPath(lampPath, shadePaint)

          // Warm Ambient Glow
          val glowPaint = Paint().apply {
            color = Color.argb(90, 253, 224, 71)
            style = Paint.Style.FILL
            isAntiAlias = true
          }
          canvas.drawCircle(cx, cy + sizePx * 0.3f, sizePx * 0.4f, glowPaint)
        }

        com.example.model.DecorType.WALLPAPER_STRIPES -> {
          // Minimalist Luxury Accent Wall Decal
          val stripePaint = Paint().apply {
            color = Color.argb(40, 255, 255, 255)
            strokeWidth = 6f
          }
          for (sx in (cx - sizePx).toInt()..(cx + sizePx).toInt() step 20) {
            canvas.drawLine(sx.toFloat(), 0f, sx.toFloat(), h * 0.72f, stripePaint)
          }
        }
      }
    }
    return result
  }

  private data class Tuple5<A, B, C, D, E>(
    val a: A, val b: B, val c: C, val d: D, val e: E
  )
}

