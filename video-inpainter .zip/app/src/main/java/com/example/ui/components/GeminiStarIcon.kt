package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Authentic 4-pointed Google Gemini Sparkle Star icon
 * with rich multi-color gradient (Cyan, Electric Blue, Violet, Magenta, Amber/Yellow)
 * and subtle breathing scale pulse.
 */
@Composable
fun GeminiStarIcon(
  modifier: Modifier = Modifier,
  size: Dp = 54.dp,
  animated: Boolean = true
) {
  val infiniteTransition = rememberInfiniteTransition(label = "gemini_sparkle")
  val pulseScale by if (animated) {
    infiniteTransition.animateFloat(
      initialValue = 0.96f,
      targetValue = 1.04f,
      animationSpec = infiniteRepeatable(
        animation = tween(2200, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse
      ),
      label = "scale"
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
  }

  val rotationDeg by if (animated) {
    infiniteTransition.animateFloat(
      initialValue = -2f,
      targetValue = 2f,
      animationSpec = infiniteRepeatable(
        animation = tween(3000, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse
      ),
      label = "rotation"
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
  }

  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val cy = h / 2f

    scale(pulseScale) {
      rotate(rotationDeg, pivot = Offset(cx, cy)) {
        // Construct the 4-pointed hypo-cycloid star of Gemini
        val path = Path().apply {
          moveTo(cx, 0f) // Top tip
          // Curve to Right tip
          cubicTo(
            cx + w * 0.10f, cy - h * 0.10f,
            cx + w * 0.10f, cy - h * 0.10f,
            w, cy
          )
          // Curve to Bottom tip
          cubicTo(
            cx + w * 0.10f, cy + h * 0.10f,
            cx + w * 0.10f, cy + h * 0.10f,
            cx, h
          )
          // Curve to Left tip
          cubicTo(
            cx - w * 0.10f, cy + h * 0.10f,
            cx - w * 0.10f, cy + h * 0.10f,
            0f, cy
          )
          // Curve back to Top tip
          cubicTo(
            cx - w * 0.10f, cy - h * 0.10f,
            cx - w * 0.10f, cy - h * 0.10f,
            cx, 0f
          )
          close()
        }

        // Gemini trademark gradient: Cyan (top/left), Royal Blue (center),
        // Violet/Pink (right), Coral/Yellow (bottom/tip)
        val gradient = Brush.linearGradient(
          colors = listOf(
            Color(0xFF38BDF8), // Cyan Light
            Color(0xFF4285F4), // Google Blue
            Color(0xFF8B5CF6), // Violet
            Color(0xFFEC4899), // Pink
            Color(0xFFFB923C)  // Peach/Orange
          ),
          start = Offset(0f, 0f),
          end = Offset(w, h)
        )

        drawPath(path = path, brush = gradient)
      }
    }
  }
}
