package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ExportState
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.RoseHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.io.File

@Composable
fun ExportDialog(
  exportState: ExportState,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  Dialog(onDismissRequest = { if (!exportState.isExporting) onDismiss() }) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = DarkSurfaceElevated,
      border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
      modifier = modifier
        .fillMaxWidth()
        .testTag("export_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        if (exportState.isExporting) {
          // In-Progress Rendering State
          Box(
            modifier = Modifier
              .size(56.dp)
              .clip(CircleShape)
              .background(CyanPrimary.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            CircularProgressIndicator(
              color = CyanPrimary,
              strokeWidth = 3.dp,
              modifier = Modifier.size(36.dp)
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "Exporting Cleaned Video",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "Rendering frames without watermarks (720p/1080p MP4)",
            fontSize = 12.sp,
            color = TextMuted,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(18.dp))

          // Real-time Progress Bar
          LinearProgressIndicator(
            progress = { exportState.progress },
            color = CyanPrimary,
            trackColor = DarkSurfaceBorder,
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp))
              .testTag("export_progress_bar")
          )

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = exportState.statusMessage,
              fontSize = 12.sp,
              color = TextSecondary
            )
            Text(
              text = "${(exportState.progress * 100).toInt()}%",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = CyanGlow
            )
          }
        } else if (exportState.isComplete) {
          // Success State
          Box(
            modifier = Modifier
              .size(56.dp)
              .clip(CircleShape)
              .background(Color(0xFF10B981).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "Success",
              tint = Color(0xFF10B981),
              modifier = Modifier.size(36.dp)
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "Cleaned Video Ready!",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "All dampness, litter, and unwanted objects have been removed seamlessly. Zero watermarks.",
            fontSize = 12.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(18.dp))

          // Share and Done Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = {
                val sendIntent = Intent().apply {
                  action = Intent.ACTION_SEND
                  putExtra(Intent.EXTRA_TEXT, "Cleaned video produced with Video Inpainter AI!")
                  type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Share Cleaned Video"))
              },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f).testTag("btn_share_export")
            ) {
              Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Share", fontSize = 13.sp)
            }

            Button(
              onClick = onDismiss,
              colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = Color.Black),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f).testTag("btn_done_export")
            ) {
              Text("Done", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
          }
        } else if (exportState.error != null) {
          // Error State
          Icon(Icons.Default.Error, contentDescription = null, tint = RoseHighlight, modifier = Modifier.size(40.dp))
          Spacer(modifier = Modifier.height(10.dp))
          Text(text = "Export Error", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = exportState.error, fontSize = 12.sp, color = TextMuted, textAlign = TextAlign.Center)
          Spacer(modifier = Modifier.height(16.dp))
          Button(onClick = onDismiss, shape = RoundedCornerShape(10.dp)) {
            Text("Close")
          }
        }
      }
    }
  }
}
