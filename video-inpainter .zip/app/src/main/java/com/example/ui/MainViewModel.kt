package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.InpaintingEngine
import com.example.engine.SampleVideoGenerator
import com.example.engine.VideoExporter
import com.example.model.BrushPoint
import com.example.model.BrushStroke
import com.example.model.ClonePatchConfig
import com.example.model.DecorItem
import com.example.model.DecorType
import com.example.model.ExportState
import com.example.model.GeminiChatMessage
import com.example.model.InpaintingEngineMode
import com.example.model.MaskTool
import com.example.model.TextCommandResult
import com.example.model.VideoFrame
import com.example.model.WallPaintConfig
import com.example.model.WorkflowStep

import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ComparisonMode {
  SPLIT_SLIDER,
  SIDE_BY_SIDE,
  CLEANED_ONLY,
  ORIGINAL_ONLY
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val _workflowStep = MutableStateFlow(WorkflowStep.IMPORT)
  val workflowStep: StateFlow<WorkflowStep> = _workflowStep.asStateFlow()

  private val _videoFrames = MutableStateFlow<List<VideoFrame>>(emptyList())
  val videoFrames: StateFlow<List<VideoFrame>> = _videoFrames.asStateFlow()

  private val _currentFrameIndex = MutableStateFlow(0)
  val currentFrameIndex: StateFlow<Int> = _currentFrameIndex.asStateFlow()

  private val _isPlaying = MutableStateFlow(false)
  val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

  private val _playbackSpeed = MutableStateFlow(1.0f)
  val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

  private val _activeMaskTool = MutableStateFlow(MaskTool.CLONE_PATCH)
  val activeMaskTool: StateFlow<MaskTool> = _activeMaskTool.asStateFlow()

  private val _brushStrokes = MutableStateFlow<List<BrushStroke>>(emptyList())
  val brushStrokes: StateFlow<List<BrushStroke>> = _brushStrokes.asStateFlow()

  private val _brushRadius = MutableStateFlow(24f)
  val brushRadius: StateFlow<Float> = _brushRadius.asStateFlow()

  private val _brushFeather = MutableStateFlow(0.5f)
  val brushFeather: StateFlow<Float> = _brushFeather.asStateFlow()

  private val _cloneConfig = MutableStateFlow(ClonePatchConfig())
  val cloneConfig: StateFlow<ClonePatchConfig> = _cloneConfig.asStateFlow()

  private val _inpaintingMode = MutableStateFlow(InpaintingEngineMode.LOCAL_FREEZE_PATCH)
  val inpaintingMode: StateFlow<InpaintingEngineMode> = _inpaintingMode.asStateFlow()

  private val _autoTrack = MutableStateFlow(true)
  val autoTrack: StateFlow<Boolean> = _autoTrack.asStateFlow()

  private val _splitSliderPosition = MutableStateFlow(0.5f)
  val splitSliderPosition: StateFlow<Float> = _splitSliderPosition.asStateFlow()

  private val _comparisonMode = MutableStateFlow(ComparisonMode.SPLIT_SLIDER)
  val comparisonMode: StateFlow<ComparisonMode> = _comparisonMode.asStateFlow()

  private val _exportState = MutableStateFlow(ExportState())
  val exportState: StateFlow<ExportState> = _exportState.asStateFlow()

  private val _isProcessing = MutableStateFlow(false)
  val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

  private val _statusMessage = MutableStateFlow<String?>(null)
  val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

  private val _textCommandResult = MutableStateFlow<TextCommandResult?>(null)
  val textCommandResult: StateFlow<TextCommandResult?> = _textCommandResult.asStateFlow()

  private val _isProcessingTextPrompt = MutableStateFlow(false)
  val isProcessingTextPrompt: StateFlow<Boolean> = _isProcessingTextPrompt.asStateFlow()

  private val _selectedPresetId = MutableStateFlow("dampness")
  val selectedPresetId: StateFlow<String> = _selectedPresetId.asStateFlow()

  // Gemini AI Chat & Home Makeover states
  private val _wallPaintConfig = MutableStateFlow(WallPaintConfig())
  val wallPaintConfig: StateFlow<WallPaintConfig> = _wallPaintConfig.asStateFlow()

  private val _decorItems = MutableStateFlow<List<DecorItem>>(emptyList())
  val decorItems: StateFlow<List<DecorItem>> = _decorItems.asStateFlow()

  private val _chatMessages = MutableStateFlow<List<GeminiChatMessage>>(
    listOf(
      GeminiChatMessage(
        isUser = false,
        text = "नमस्ते! मैं आपका Gemini AI Home Designer और Video Inpainter हूँ। ✨\n\nआप इस वीडियो में अपने घर को जैसा चाहें बदल और सजा सकते हैं:\n• दीवार की सीलन/नमी या फर्श का कचरा साफ़ करवाएं\n• दीवार पर नया पेंट (रॉयल ब्लू, सेज ग्रीन, टेराकोटा आदि) लगाएं\n• सुंदर वॉल आर्ट फ्रेम, आधुनिक घड़ी या इंडोर पौधे लगाएं\n\nमुझसे चैट में बताएं आप क्या बदलाव करना चाहते हैं!",
        suggestedPrompts = listOf(
          "दीवार पर रॉयल ब्लू पेंट लगाओ",
          "दीवार की सीलन हटा दो",
          "दीवार पर सुंदर वॉल आर्ट फ्रेम लगाओ",
          "दीवार पर आधुनिक घड़ी लगाओ",
          "कमरे में इंडोर पौधा रखो",
          "सेज ग्रीन पेंट और वॉल आर्ट लगाओ"
        )
      )
    )
  )
  val chatMessages: StateFlow<List<GeminiChatMessage>> = _chatMessages.asStateFlow()

  private val _isChatAiThinking = MutableStateFlow(false)
  val isChatAiThinking: StateFlow<Boolean> = _isChatAiThinking.asStateFlow()

  private var playbackJob: Job? = null


  init {
    loadPreset("dampness")
  }

  fun setWorkflowStep(step: WorkflowStep) {
    _workflowStep.value = step
    if (step == WorkflowStep.PREVIEW_EXPORT) {
      applyInpaintingToAllFrames()
    }
  }

  fun loadPreset(presetId: String) {
    viewModelScope.launch {
      _isProcessing.value = true
      _selectedPresetId.value = presetId
      val preset = SampleVideoGenerator.PRESETS.find { it.id == presetId }
      val frames = SampleVideoGenerator.generatePresetFrames(
        context = getApplication(),
        presetId = presetId
      )
      _videoFrames.value = frames
      _currentFrameIndex.value = 0

      if (preset != null) {
        _cloneConfig.value = ClonePatchConfig(
          sourceX = preset.defaultSource.x,
          sourceY = preset.defaultSource.y,
          targetX = preset.defaultTarget.x,
          targetY = preset.defaultTarget.y,
          radius = preset.defaultRadius
        )
      }
      _isProcessing.value = false
      applyInpaintingToCurrentFrame()
    }
  }

  fun importVideo(context: Context, uri: Uri) {
    viewModelScope.launch {
      _isProcessing.value = true
      _statusMessage.value = "Extracting video frames..."
      val frames = SampleVideoGenerator.extractFramesFromUri(context, uri)
      _videoFrames.value = frames
      _currentFrameIndex.value = 0
      _isProcessing.value = false
      _statusMessage.value = "Video imported: ${frames.size} frames loaded"

      // Trigger AI Auto-Detection for the imported video
      if (frames.isNotEmpty()) {
        val detected = InpaintingEngine.autoDetectBlemishPatch(frames[0].originalBitmap)
        _cloneConfig.value = detected
        applyInpaintingToCurrentFrame()
      }
    }
  }

  fun setCurrentFrame(index: Int) {
    val frames = _videoFrames.value
    if (frames.isNotEmpty()) {
      _currentFrameIndex.value = index.coerceIn(0, frames.size - 1)
      applyInpaintingToCurrentFrame()
    }
  }

  fun stepFrame(delta: Int) {
    val frames = _videoFrames.value
    if (frames.isNotEmpty()) {
      val next = (_currentFrameIndex.value + delta + frames.size) % frames.size
      setCurrentFrame(next)
    }
  }

  fun togglePlayPause() {
    val playing = !_isPlaying.value
    _isPlaying.value = playing
    if (playing) {
      startPlayback()
    } else {
      playbackJob?.cancel()
    }
  }

  private fun startPlayback() {
    playbackJob?.cancel()
    playbackJob = viewModelScope.launch {
      while (_isPlaying.value) {
        val frames = _videoFrames.value
        if (frames.isEmpty()) break
        val interval = (66f / _playbackSpeed.value).toLong().coerceAtLeast(16L)
        delay(interval)
        val next = (_currentFrameIndex.value + 1) % frames.size
        _currentFrameIndex.value = next
      }
    }
  }

  fun setPlaybackSpeed(speed: Float) {
    _playbackSpeed.value = speed
    if (_isPlaying.value) {
      startPlayback()
    }
  }

  fun setMaskTool(tool: MaskTool) {
    _activeMaskTool.value = tool
  }

  fun setBrushRadius(radius: Float) {
    _brushRadius.value = radius
  }

  fun setBrushFeather(feather: Float) {
    _brushFeather.value = feather
  }

  fun updateCloneConfig(update: (ClonePatchConfig) -> ClonePatchConfig) {
    _cloneConfig.update(update)
    applyInpaintingToCurrentFrame()
  }

  fun addBrushPoint(x: Float, y: Float, isStart: Boolean) {
    val current = _brushStrokes.value.toMutableList()
    if (isStart || current.isEmpty()) {
      val newStroke = BrushStroke(
        points = listOf(BrushPoint(x, y)),
        radius = _brushRadius.value,
        feather = _brushFeather.value,
        isEraser = _activeMaskTool.value == MaskTool.ERASER
      )
      current.add(newStroke)
    } else {
      val lastIndex = current.size - 1
      val lastStroke = current[lastIndex]
      val updatedPoints = lastStroke.points + BrushPoint(x, y)
      current[lastIndex] = lastStroke.copy(points = updatedPoints)
    }
    _brushStrokes.value = current
    applyInpaintingToCurrentFrame()
  }

  fun clearMask() {
    _brushStrokes.value = emptyList()
    applyInpaintingToCurrentFrame()
  }

  fun undoLastStroke() {
    val current = _brushStrokes.value
    if (current.isNotEmpty()) {
      _brushStrokes.value = current.dropLast(1)
      applyInpaintingToCurrentFrame()
    }
  }

  fun setAutoTrack(enabled: Boolean) {
    _autoTrack.value = enabled
    applyInpaintingToCurrentFrame()
  }

  fun setInpaintingMode(mode: InpaintingEngineMode) {
    _inpaintingMode.value = mode
    applyInpaintingToCurrentFrame()
  }

  fun setSplitSliderPosition(pos: Float) {
    _splitSliderPosition.value = pos.coerceIn(0f, 1f)
  }

  fun setComparisonMode(mode: ComparisonMode) {
    _comparisonMode.value = mode
  }

  fun runAiAutoDetect() {
    viewModelScope.launch {
      val frames = _videoFrames.value
      val idx = _currentFrameIndex.value
      if (frames.isNotEmpty()) {
        _isProcessing.value = true
        _statusMessage.value = "AI scanning frame for dampness, litter & blemishes..."
        delay(350)
        val detected = InpaintingEngine.autoDetectBlemishPatch(frames[idx].originalBitmap)
        _cloneConfig.value = detected
        _activeMaskTool.value = MaskTool.CLONE_PATCH
        _isProcessing.value = false
        _statusMessage.value = "Object & clean patch detected automatically!"
        applyInpaintingToCurrentFrame()
      }
    }
  }

  fun executeTextInstruction(prompt: String) {
    if (prompt.isBlank()) return
    viewModelScope.launch {
      val frames = _videoFrames.value
      val idx = _currentFrameIndex.value
      if (frames.isNotEmpty()) {
        _isProcessingTextPrompt.value = true
        _statusMessage.value = "AI analyzing prompt: \"$prompt\"..."
        delay(400) // Brief animation buffer

        val result = InpaintingEngine.processTextInstruction(
          bitmap = frames[idx].originalBitmap,
          prompt = prompt,
          presetId = _selectedPresetId.value
        )

        _cloneConfig.value = result.patchConfig
        _activeMaskTool.value = MaskTool.CLONE_PATCH
        _textCommandResult.value = result
        _isProcessingTextPrompt.value = false
        _statusMessage.value = result.explanationHindi

        // Apply immediately to current frame and all frames
        applyInpaintingToCurrentFrame()
        applyInpaintingToAllFrames()
      }
    }
  }

  fun clearTextCommandResult() {
    _textCommandResult.value = null
  }

  fun applyInpaintingToCurrentFrame() {
    val frames = _videoFrames.value
    val idx = _currentFrameIndex.value
    if (frames.isEmpty() || idx !in frames.indices) return

    val frame = frames[idx]
    val trackShiftX = if (_autoTrack.value) frame.cameraShiftX else 0f
    val trackShiftY = if (_autoTrack.value) frame.cameraShiftY else 0f

    var cleaned = when (_activeMaskTool.value) {
      MaskTool.CLONE_PATCH -> InpaintingEngine.applyClonePatch(
        frame.originalBitmap,
        _cloneConfig.value,
        trackShiftX,
        trackShiftY
      )
      else -> InpaintingEngine.applyBrushInpainting(
        frame.originalBitmap,
        _brushStrokes.value,
        trackShiftX,
        trackShiftY
      )
    }

    if (_wallPaintConfig.value.enabled) {
      cleaned = InpaintingEngine.applyWallPaint(cleaned, _wallPaintConfig.value)
    }

    if (_decorItems.value.isNotEmpty()) {
      cleaned = InpaintingEngine.renderDecorOverlay(
        original = cleaned,
        decors = _decorItems.value,
        trackShiftX = trackShiftX,
        trackShiftY = trackShiftY,
        context = getApplication()
      )
    }

    frame.cleanedBitmap = cleaned
  }

  fun applyInpaintingToAllFrames() {
    viewModelScope.launch {
      val frames = _videoFrames.value
      for (frame in frames) {
        val trackShiftX = if (_autoTrack.value) frame.cameraShiftX else 0f
        val trackShiftY = if (_autoTrack.value) frame.cameraShiftY else 0f

        var cleaned = when (_activeMaskTool.value) {
          MaskTool.CLONE_PATCH -> InpaintingEngine.applyClonePatch(
            frame.originalBitmap,
            _cloneConfig.value,
            trackShiftX,
            trackShiftY
          )
          else -> InpaintingEngine.applyBrushInpainting(
            frame.originalBitmap,
            _brushStrokes.value,
            trackShiftX,
            trackShiftY
          )
        }

        if (_wallPaintConfig.value.enabled) {
          cleaned = InpaintingEngine.applyWallPaint(cleaned, _wallPaintConfig.value)
        }

        if (_decorItems.value.isNotEmpty()) {
          cleaned = InpaintingEngine.renderDecorOverlay(
            original = cleaned,
            decors = _decorItems.value,
            trackShiftX = trackShiftX,
            trackShiftY = trackShiftY,
            context = getApplication()
          )
        }

        frame.cleanedBitmap = cleaned
      }
    }
  }

  // --- Gemini AI Chat Conversational Actions ---
  fun sendGeminiChatMessage(userText: String) {
    if (userText.isBlank()) return
    val userMsg = GeminiChatMessage(isUser = true, text = userText)
    _chatMessages.update { it + userMsg }

    viewModelScope.launch {
      _isChatAiThinking.value = true
      _statusMessage.value = "Gemini AI सोच रहा है और बदलाव लागू कर रहा है..."
      delay(600) // Realistic conversational thinking time

      val lower = userText.lowercase().trim()
      var actionDesc: String? = null
      val aiResponseText: String
      val nextSuggestions: List<String>

      when {
        // Wall Color / Paint commands
        lower.contains("पेंट") || lower.contains("रंग") || lower.contains("paint") || lower.contains("color") ||
          lower.contains("ब्लू") || lower.contains("नीला") || lower.contains("ग्रीन") || lower.contains("हरा") ||
          lower.contains("सफेद") || lower.contains("white") || lower.contains("blue") || lower.contains("green") ||
          lower.contains("दीवार") -> {

          val (colorNameHi, colorNameEn, colorHex) = when {
            lower.contains("ग्रीन") || lower.contains("हरा") || lower.contains("green") || lower.contains("सेज") ->
              Triple("सेज ग्रीन (Sage Green)", "Sage Botanical Green", 0xFF2D5A43)
            lower.contains("टेराकोटा") || lower.contains("नारंगी") || lower.contains("orange") || lower.contains("warm") ->
              Triple("वार्म टेराकोटा (Warm Terracotta)", "Warm Terracotta Accent", 0xFF9C4221)
            lower.contains("सफेद") || lower.contains("white") || lower.contains("क्रीम") || lower.contains("cream") ->
              Triple("प्रीमियम आइवरी क्रीम", "Premium Ivory Cream", 0xFFFDFBF7)
            lower.contains("ग्रे") || lower.contains("grey") || lower.contains("gray") ->
              Triple("मॉडर्न चारकोल ग्रे", "Modern Slate Grey", 0xFF334155)
            else ->
              Triple("रॉयल सफायर ब्लू (Royal Blue)", "Royal Sapphire Blue", 0xFF1E3A8A)
          }

          _wallPaintConfig.value = WallPaintConfig(
            enabled = true,
            colorNameHindi = colorNameHi,
            colorNameEnglish = colorNameEn,
            colorHex = colorHex,
            opacity = 0.50f
          )
          actionDesc = "दीवार का रंग $colorNameHi में बदल दिया गया"
          aiResponseText = "✓ मैंने आपके निर्देशानुसार वीडियो में कमरे की दीवार पर सुंदर **$colorNameHi** पेंट लागू कर दिया है!\n\nदीवार के टेक्सचर, रौशनी और परछाई को सुरक्षित रखते हुए यह रंग पूरे वीडियो में एक समान ब्लेंड हो गया है।"
          nextSuggestions = listOf(
            "दीवार पर एक मॉडर्न वॉल आर्ट फ्रेम लगाओ",
            "दीवार पर घड़ी लगा दो",
            "दीवार से सीलन भी साफ़ कर दो",
            "सेज ग्रीन पेंट ट्राई करो"
          )
        }

        // Decor: Wall Art Frame
        lower.contains("फ्रेम") || lower.contains("आर्ट") || lower.contains("पेंटिंग") ||
          lower.contains("frame") || lower.contains("art") || lower.contains("painting") -> {
          val newItem = DecorItem(
            id = "art_${System.currentTimeMillis()}",
            type = DecorType.WALL_ART_FRAME,
            nameHindi = "लक्ज़री गोल्डन वॉल आर्ट फ्रेम",
            nameEnglish = "Luxury Minimal Wall Art Frame",
            normalizedX = 0.48f,
            normalizedY = 0.35f,
            scale = 0.26f
          )
          _decorItems.update { it.filter { d -> d.type != DecorType.WALL_ART_FRAME } + newItem }
          actionDesc = "दीवार पर लग्जरी वॉल आर्ट फ्रेम लगाया गया"
          aiResponseText = "✓ दीवार के केंद्र में एक मॉडर्न **लक्ज़री सनसेट वॉल आर्ट फ्रेम** जोड़ दिया गया है!\n\nयह फ्रेम कैमरे के मूवमेंट के साथ रियल-टाइम में लॉक रहेगा।"
          nextSuggestions = listOf(
            "दीवार पर एक आधुनिक घड़ी भी लगाओ",
            "दीवार पर रॉयल ब्लू पेंट लगाओ",
            "कमरे में इनडोर प्लांट रखो",
            "Before / After तुलना दिखाओ"
          )
        }

        // Decor: Wall Clock
        lower.contains("घड़ी") || lower.contains("clock") || lower.contains("वॉच") -> {
          val newItem = DecorItem(
            id = "clock_${System.currentTimeMillis()}",
            type = DecorType.WALL_CLOCK,
            nameHindi = "मिनिमलिस्ट वॉल क्लॉक",
            nameEnglish = "Minimalist Wall Clock",
            normalizedX = 0.78f,
            normalizedY = 0.28f,
            scale = 0.18f
          )
          _decorItems.update { it.filter { d -> d.type != DecorType.WALL_CLOCK } + newItem }
          actionDesc = "दीवार पर आधुनिक घड़ी लगाई गई"
          aiResponseText = "✓ दीवार के ऊपरी हिस्से पर एक स्लीक **मिनिमलिस्ट वॉल क्लॉक** लगा दी गई है।"
          nextSuggestions = listOf(
            "कमरे में इंडोर पौधा भी रखो",
            "दीवार पर पेंट बदलो",
            "पूरी दीवार को साफ़ करके सजाओ"
          )
        }

        // Decor: Indoor Plant
        lower.contains("पौधा") || lower.contains("प्लांट") || lower.contains("गमला") || lower.contains("plant") -> {
          val newItem = DecorItem(
            id = "plant_${System.currentTimeMillis()}",
            type = DecorType.INDOOR_PLANT,
            nameHindi = "इनडोर मॉन्स्टेरा ग्रीन प्लांट",
            nameEnglish = "Indoor Potted Monstera Plant",
            normalizedX = 0.18f,
            normalizedY = 0.58f,
            scale = 0.30f
          )
          _decorItems.update { it.filter { d -> d.type != DecorType.INDOOR_PLANT } + newItem }
          actionDesc = "कमरे में इनडोर प्लांट सजाया गया"
          aiResponseText = "✓ कमरे के कोने में एक सुंदर **इनडोर ग्रीन प्लांट (टेराकोटा पॉट)** रख दिया गया है। इससे रूम को नेचुरल और ताज़ा लुक मिल रहा है।"
          nextSuggestions = listOf(
            "दीवार पर सेज ग्रीन पेंट लगाओ",
            "दीवार पर वॉल आर्ट लगाओ",
            "साफ़ वीडियो एक्सपोर्ट करो"
          )
        }

        // Decor: Pendant Light
        lower.contains("लाइट") || lower.contains("लैंप") || lower.contains("light") || lower.contains("lamp") -> {
          val newItem = DecorItem(
            id = "lamp_${System.currentTimeMillis()}",
            type = DecorType.LIGHT_FIXTURE,
            nameHindi = "नॉर्डिक हैंगिंग पेंडेंट लैंप",
            nameEnglish = "Nordic Hanging Pendant Lamp",
            normalizedX = 0.50f,
            normalizedY = 0.22f,
            scale = 0.24f
          )
          _decorItems.update { it.filter { d -> d.type != DecorType.LIGHT_FIXTURE } + newItem }
          actionDesc = "कमरे में हैंगिंग लैंप लगाया गया"
          aiResponseText = "✓ छत से एक स्टाइलिश **नॉर्डिक हैंगिंग पेंडेंट लैंप (वार्म ग्लो)** लगा दिया गया है।"
          nextSuggestions = listOf(
            "दीवार पर रॉयल ब्लू पेंट लगाओ",
            "दीवार की सीलन हटा दो",
            "Before / After तुलना देखें"
          )
        }

        // Inpaint / Clean commands (Dampness, Seepage, Litter, Dirt)
        lower.contains("सीलन") || lower.contains("सील") || lower.contains("कचरा") ||
          lower.contains("दाग") || lower.contains("साफ़") || lower.contains("clean") ||
          lower.contains("damp") || lower.contains("trash") || lower.contains("remove") ||
          lower.contains("हटा") -> {

          val frames = _videoFrames.value
          val idx = _currentFrameIndex.value
          if (frames.isNotEmpty()) {
            val result = InpaintingEngine.processTextInstruction(
              bitmap = frames[idx].originalBitmap,
              prompt = userText,
              presetId = _selectedPresetId.value
            )
            _cloneConfig.value = result.patchConfig
            _activeMaskTool.value = MaskTool.CLONE_PATCH
            _textCommandResult.value = result
          }
          actionDesc = "अवांछित सीलन/कचरे को AI ने इनपेंट कर साफ़ किया"
          aiResponseText = "✓ मैंने वीडियो में सीलन, पानी के दाग और अवांछित निशान पहचान कर उन्हें स्वच्छ दीवार के टेक्सचर से 100% साफ़ कर दिया है!\n\nअब आप चाहें तो इस साफ़ दीवार पर नया पेंट लगा सकते हैं या कोई वॉल आर्ट जोड़ सकते हैं।"
          nextSuggestions = listOf(
            "दीवार पर रॉयल ब्लू पेंट लगाओ",
            "दीवार पर एक सुंदर वॉल आर्ट फ्रेम लगाओ",
            "कमरे में इंडोर प्लांट रखो",
            "साफ़ वीडियो एक्सपोर्ट करो"
          )
        }

        // Reset / Clear decor
        lower.contains("हटा दो सब") || lower.contains("reset") || lower.contains("clear decor") || lower.contains("रीसेट") -> {
          _wallPaintConfig.value = WallPaintConfig(enabled = false)
          _decorItems.value = emptyList()
          actionDesc = "सभी सजावटी आइटम्स रीसेट कर दिए गए"
          aiResponseText = "✓ सभी वॉल पेंट और डेकोरेशन आइटम्स हटा दिए गए हैं। केवल मूल साफ़ किया हुआ वीडियो एक्टिव है।"
          nextSuggestions = listOf(
            "दीवार पर नया पेंट लगाओ",
            "दीवार की सीलन साफ़ करो",
            "वॉल आर्ट फ्रेम लगाओ"
          )
        }

        // General / Conversational fallback
        else -> {
          // Check if it's general makeover request
          _wallPaintConfig.value = WallPaintConfig(
            enabled = true,
            colorNameHindi = "रॉयल ब्लू",
            colorNameEnglish = "Royal Sapphire Blue",
            colorHex = 0xFF1E3A8A,
            opacity = 0.48f
          )
          val newItem = DecorItem(
            id = "art_${System.currentTimeMillis()}",
            type = DecorType.WALL_ART_FRAME,
            nameHindi = "लक्ज़री वॉल आर्ट",
            nameEnglish = "Luxury Wall Art",
            normalizedX = 0.50f,
            normalizedY = 0.35f,
            scale = 0.24f
          )
          _decorItems.update { listOf(newItem) }
          actionDesc = "कमरे का पूरा मेकओवर (पेंट + आर्ट फ्रेम)"
          aiResponseText = "✓ बिल्कुल! मैंने आपके कमरे का संपूर्ण मेकओवर शुरू कर दिया है:\n1. दीवार पर फ्रेश पेंट लगाया गया\n2. केंद्र में एक सुंदर वॉल आर्ट फ्रेम सजाया गया\n\nआप मुझे बता सकते हैं: 'दीवार का रंग हरा करो', 'घड़ी लगाओ', या 'सीलन हटा दो'!"
          nextSuggestions = listOf(
            "दीवार का रंग हरा (Sage Green) करो",
            "दीवार पर घड़ी लगाओ",
            "कमरे में पौधा रखो",
            "Before / After तुलना दिखाओ"
          )
        }
      }

      // Re-render current frame and full video with updates
      applyInpaintingToCurrentFrame()
      applyInpaintingToAllFrames()

      _isChatAiThinking.value = false
      _chatMessages.update {
        it + GeminiChatMessage(
          isUser = false,
          text = aiResponseText,
          actionApplied = actionDesc,
          suggestedPrompts = nextSuggestions
        )
      }
      if (actionDesc != null) {
        _statusMessage.value = actionDesc
      }
    }
  }

  fun setWallPaint(colorHex: Long, nameHindi: String, nameEnglish: String) {
    _wallPaintConfig.value = WallPaintConfig(
      enabled = true,
      colorNameHindi = nameHindi,
      colorNameEnglish = nameEnglish,
      colorHex = colorHex,
      opacity = 0.48f
    )
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
    _statusMessage.value = "दीवार का रंग बदलकर $nameHindi किया गया"
  }

  fun toggleWallPaint(enabled: Boolean) {
    _wallPaintConfig.update { it.copy(enabled = enabled) }
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
  }

  fun addDecorItem(type: DecorType, nameHi: String, nameEn: String, x: Float = 0.5f, y: Float = 0.4f) {
    val item = DecorItem(
      id = "decor_${System.currentTimeMillis()}",
      type = type,
      nameHindi = nameHi,
      nameEnglish = nameEn,
      normalizedX = x,
      normalizedY = y
    )
    _decorItems.update { it + item }
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
    _statusMessage.value = "$nameHi जोड़ा गया"
  }

  fun removeDecorItem(id: String) {
    _decorItems.update { it.filterNot { d -> d.id == id } }
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
  }

  fun clearAllDecorations() {
    _wallPaintConfig.value = WallPaintConfig(enabled = false)
    _decorItems.value = emptyList()
    applyInpaintingToCurrentFrame()
    applyInpaintingToAllFrames()
    _statusMessage.value = "सभी डेकोरेशन रीसेट किए गए"
  }

  fun startExport(context: Context) {
    viewModelScope.launch {
      _exportState.value = ExportState(isExporting = true, statusMessage = "Preparing export pipeline...")
      val result = VideoExporter.exportCleanedVideo(
        context = context,
        frames = _videoFrames.value,
        tool = _activeMaskTool.value,
        cloneConfig = _cloneConfig.value,
        brushStrokes = _brushStrokes.value,
        autoTrack = _autoTrack.value,
        wallPaintConfig = _wallPaintConfig.value,
        decorItems = _decorItems.value,
        onProgress = { state ->
          _exportState.value = state
        }
      )
      _exportState.value = result
    }
  }

  fun dismissExportDialog() {
    _exportState.value = ExportState()
  }
}

