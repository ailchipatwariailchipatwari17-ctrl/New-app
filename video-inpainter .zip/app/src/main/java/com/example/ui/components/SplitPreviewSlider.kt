package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ComparisonMode
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.RoseHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlin.math.roundToInt

@Composable
fun SplitPreviewSlider(
  originalBitmap: Bitmap?,
  cleanedBitmap: Bitmap?,
  sliderPosition: Float,
  comparisonMode: ComparisonMode,
  onSliderPositionChanged: (Float) -> Unit,
  onComparisonModeChanged: (ComparisonMode) -> Unit,
  modifier: Modifier = Modifier
) {
  if (originalBitmap == null) return
  val effectiveCleaned = cleanedBitmap ?: originalBitmap

  Column(
    modifier = modifier
      .fillMaxWidth()
      .testTag("split_preview_container")
  ) {
    // Mode Switcher Bar (Split Slider, Side-by-Side, Cleaned Only, Original Only)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(DarkSurfaceElevated)
        .padding(4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      listOf(
        ComparisonMode.SPLIT_SLIDER to "Split Slider",
        ComparisonMode.SIDE_BY_SIDE to "Side by Side",
        ComparisonMode.CLEANED_ONLY to "Cleaned",
        ComparisonMode.ORIGINAL_ONLY to "Original"
      ).forEach { (mode, label) ->
        val isSelected = comparisonMode == mode
        Surface(
          onClick = { onComparisonModeChanged(mode) },
          shape = RoundedCornerShape(8.dp),
          color = if (isSelected) CyanPrimary else Color.Transparent,
          modifier = Modifier.weight(1f).testTag("mode_${mode.name.lowercase()}")
        ) {
          Box(
            modifier = Modifier.padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = label,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.Black else TextMuted
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    when (comparisonMode) {
      ComparisonMode.SPLIT_SLIDER -> {
        BoxWithConstraints(
          modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(4f / 3f)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
            .background(Color.Black)
            .testTag("split_slider_view")
        ) {
          val boxWidth = maxWidth
          val boxHeight = maxHeight

          // Bottom Layer: Cleaned Video Frame
          Image(
            bitmap = effectiveCleaned.asImageBitmap(),
            contentDescription = "Cleaned Video Frame",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
          )

          // Top Layer: Original Frame clipped to the left of sliderPosition
          Image(
            bitmap = originalBitmap.asImageBitmap(),
            contentDescription = "Original Video Frame",
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .fillMaxSize()
              .drawWithContent {
                val clipWidth = size.width * sliderPosition
                val path = Path().apply {
                  addRect(Rect(0f, 0f, clipWidth, size.height))
                }
                clipPath(path, clipOp = ClipOp.Intersect) {
                  this@drawWithContent.drawContent()
                }
              }
          )

          // Draggable Vertical Divider Line
          Box(
            modifier = Modifier
              .fillMaxHeight()
              .width(2.dp)
              .offset { IntOffset((sliderPosition * (boxWidth.toPx())).roundToInt(), 0) }
              .background(Color.White)
          )

          // Interactive Draggable Handle in the Center
          Box(
            modifier = Modifier
              .size(44.dp)
              .align(Alignment.CenterStart)
              .offset {
                IntOffset(
                  (sliderPosition * (boxWidth.toPx()) - 22.dp.toPx()).roundToInt(),
                  0
                )
              }
              .clip(CircleShape)
              .background(CyanPrimary)
              .border(2.dp, Color.White, CircleShape)
              .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                  change.consume()
                  val newPos = (sliderPosition + dragAmount.x / (boxWidth.toPx())).coerceIn(0.02f, 0.98f)
                  onSliderPositionChanged(newPos)
                }
              }
              .testTag("split_slider_handle"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.SwapHoriz,
              contentDescription = "Drag to compare",
              tint = Color.Black,
              modifier = Modifier.size(24.dp)
            )
          }

          // Top Badges
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp)
          ) {
            Box(
              modifier = Modifier
                .align(Alignment.TopStart)
                .clip(RoundedCornerShape(6.dp))
                .background(RoseHighlight.copy(alpha = 0.85f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "BEFORE (Dampness)",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }

            Box(
              modifier = Modifier
                .align(Alignment.TopEnd)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF10B981).copy(alpha = 0.85f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "AFTER (Cleaned)",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      ComparisonMode.SIDE_BY_SIDE -> {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 7f)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            Image(
              bitmap = originalBitmap.asImageBitmap(),
              contentDescription = "Original Frame",
              contentScale = ContentScale.Fit,
              modifier = Modifier.fillMaxSize()
            )
            Text(
              text = "ORIGINAL",
              color = Color.White,
              fontSize = 10.sp,
              modifier = Modifier
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            Image(
              bitmap = effectiveCleaned.asImageBitmap(),
              contentDescription = "Cleaned Frame",
              contentScale = ContentScale.Fit,
              modifier = Modifier.fillMaxSize()
            )
            Text(
              text = "INPAINTED",
              color = CyanGlow,
              fontSize = 10.sp,
              modifier = Modifier
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }

      ComparisonMode.CLEANED_ONLY -> {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(4f / 3f)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
            .background(Color.Black)
        ) {
          Image(
            bitmap = effectiveCleaned.asImageBitmap(),
            contentDescription = "Cleaned Video Frame",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
          )
          Text(
            text = "CLEANED VIDEO (NO WATERMARK)",
            color = CyanGlow,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(8.dp)
              .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
              .padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }
      }

      ComparisonMode.ORIGINAL_ONLY -> {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(4f / 3f)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
            .background(Color.Black)
        ) {
          Image(
            bitmap = originalBitmap.asImageBitmap(),
            contentDescription = "Original Video Frame",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
          )
          Text(
            text = "ORIGINAL VIDEO (WITH BLEMISHES)",
            color = RoseHighlight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(8.dp)
              .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
              .padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }
      }
    }
  }
}
